--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Debian 16.3-1.pgdg120+1)
-- Dumped by pg_dump version 16.3 (Debian 16.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ag_catalog; Type: SCHEMA; Schema: -; Owner: dst_graph_designer
--

CREATE SCHEMA ag_catalog;


ALTER SCHEMA ag_catalog OWNER TO dst_graph_designer;

--
-- Name: flight_routes; Type: SCHEMA; Schema: -; Owner: dst_graph_designer
--

CREATE SCHEMA flight_routes;


ALTER SCHEMA flight_routes OWNER TO dst_graph_designer;

--
-- Name: l3; Type: SCHEMA; Schema: -; Owner: dst_graph_designer
--

CREATE SCHEMA l3;


ALTER SCHEMA l3 OWNER TO dst_graph_designer;

--
-- Name: age; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS age WITH SCHEMA ag_catalog;


--
-- Name: EXTENSION age; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION age IS 'AGE database extension';


--
-- Name: autoload_scheduled_routes(); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.autoload_scheduled_routes() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
	airport_code varchar;
	vertex int := 0;
	edge int := 0;
BEGIN
	LOAD 'age';
	SET search_path = ag_catalog, "$user", public;

	FOREACH airport_code IN ARRAY ARRAY[NEW.departure_airport_code, NEW.arrival_airport_code]
	LOOP
		vertex := 0;
		select count(*) INTO vertex FROM flight_routes.query_vertex_in_graph_db(airport_code);
		IF vertex = 0 THEN
			PERFORM flight_routes.create_vertex(airport_code);
		END IF;
	END LOOP;
	SELECT count(*) INTO edge FROM flight_routes.query_routes_in_graph_db(NEW.departure_airport_code, NEW.arrival_airport_code, 1);
	IF edge = 0 THEN
		PERFORM flight_routes.create_edge(NEW.departure_airport_code, NEW.arrival_airport_code, NEW.avg_flight_duration_hours);
	ELSE
		PERFORM flight_routes.update_edge_property(NEW.departure_airport_code, NEW.arrival_airport_code, NEW.avg_flight_duration_hours);
	END IF;
	RETURN NULL;
END;
$_$;


ALTER FUNCTION flight_routes.autoload_scheduled_routes() OWNER TO dst_graph_designer;

--
-- Name: create_edges(text, text, double precision); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.create_edges(departure_code text, arrival_code text, duration_hours double precision) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
    load 'age';
    SET search_path TO ag_catalog;
	sql := format('
		SELECT *
		FROM cypher(''flight_routes'', $$
			    MATCH (a:Airport), (b:Airport)
			    WHERE a.code = "%1$s" AND b.code = "%2$s"
			    CREATE (a)-[:ROUTE {duration: %3$s, route:"%1$s -> %2$s"}]->(b)
		$$) AS (e agtype);
	', departure_code, arrival_code, duration_hours);
	EXECUTE sql;
END
$_$;


ALTER FUNCTION flight_routes.create_edges(departure_code text, arrival_code text, duration_hours double precision) OWNER TO dst_graph_designer;

--
-- Name: create_vertex(text); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.create_vertex(airport_code text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
    load 'age';
    SET search_path TO ag_catalog;
	sql := format('
		SELECT *
		FROM cypher(''flight_routes'', $$
			CREATE (:Airport {code:"%1$s"})
		$$) AS (v agtype);
	', airport_code);
	EXECUTE sql;
END
$_$;


ALTER FUNCTION flight_routes.create_vertex(airport_code text) OWNER TO dst_graph_designer;

--
-- Name: query_routes_between_airports(character varying, character varying, integer); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.query_routes_between_airports(departure_code character varying, arrival_code character varying, number_flights integer) RETURNS TABLE(num_flights integer, route character varying, duration_hours double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN
	RETURN QUERY 
		with graph_query as (
			SELECT * FROM flight_routes.query_routes_in_graph_db(departure_code, arrival_code, number_flights)
		),
		routes_text as (
			select
				row_number() over(order by routes) as idx,
				cast(routes as varchar) as routes
				from graph_query
		),
		nodes_splitted as (
			select idx, regexp_matches(routes, '(?:{\"route\": \"([A-Z\->\s]*))', 'g') as node,
				regexp_matches(routes, '(?:\"duration\": ([0-9\.]*))', 'g') as duration_hours
				from routes_text
		),
		routes_formatted as (
			select  count(*)::int as num_flights, 
				string_agg(node[1], ' || ') as route,
				sum(cast(a.duration_hours[1] as float)) as duration_hours
				from nodes_splitted as a
				group by idx
		)
		select distinct a.num_flights::int, a.route::varchar, a.duration_hours::float
			from routes_formatted as a
			where regexp_count(a.route, departure_code) = 1 and regexp_count(a.route, arrival_code) = 1
			order by a.duration_hours asc, a.num_flights asc;
END
$$;


ALTER FUNCTION flight_routes.query_routes_between_airports(departure_code character varying, arrival_code character varying, number_flights integer) OWNER TO dst_graph_designer;

--
-- Name: query_routes_in_graph_db(character varying, character varying, integer); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.query_routes_in_graph_db(departure_code character varying, arrival_code character varying, number_flights integer) RETURNS TABLE(routes ag_catalog.agtype)
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
        load 'age';
        SET search_path TO ag_catalog;
        sql := format('
			SELECT *
			FROM cypher(''flight_routes'', $$
			    MATCH p = (:Airport {code: "%1$s"})-[*..%3$s]->(:Airport {code: "%2$s"})
			    RETURN relationships(p)
			$$) as (routes agtype);
		', departure_code, arrival_code, number_flights);
        RETURN QUERY EXECUTE sql;

END
$_$;


ALTER FUNCTION flight_routes.query_routes_in_graph_db(departure_code character varying, arrival_code character varying, number_flights integer) OWNER TO dst_graph_designer;

--
-- Name: query_vertex_in_graph_db(character varying); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.query_vertex_in_graph_db(airport_code character varying) RETURNS TABLE(code ag_catalog.agtype)
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
        load 'age';
        SET search_path TO ag_catalog;
        sql := format('
			SELECT *
			FROM cypher(''flight_routes'', $$
			    MATCH (n:Airport {code: "%1$s"})
			    RETURN n
			$$) as (code agtype);
		', airport_code);
        RETURN QUERY EXECUTE sql;
END
$_$;


ALTER FUNCTION flight_routes.query_vertex_in_graph_db(airport_code character varying) OWNER TO dst_graph_designer;

--
-- Name: update_edge_property(text, text, double precision); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.update_edge_property(departure_code text, arrival_code text, duration_hours double precision) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
    load 'age';
    SET search_path TO ag_catalog;
	sql := format('
		SELECT * 
			FROM cypher(''flight_routes'', $$
				MATCH (:Airport {code: "%1$s"})-[e:ROUTE]->(:Airport {code: "%2$s"})
				SET e.duration = %3$s
				RETURN e
				$$) as (e agtype);
	', departure_code, arrival_code, duration_hours);
	EXECUTE sql;
END
$_$;


ALTER FUNCTION flight_routes.update_edge_property(departure_code text, arrival_code text, duration_hours double precision) OWNER TO dst_graph_designer;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _ag_label_vertex; Type: TABLE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE TABLE flight_routes._ag_label_vertex (
    id ag_catalog.graphid NOT NULL,
    properties ag_catalog.agtype DEFAULT ag_catalog.agtype_build_map() NOT NULL
);


ALTER TABLE flight_routes._ag_label_vertex OWNER TO dst_graph_designer;

--
-- Name: Airport; Type: TABLE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE TABLE flight_routes."Airport" (
)
INHERITS (flight_routes._ag_label_vertex);


ALTER TABLE flight_routes."Airport" OWNER TO dst_graph_designer;

--
-- Name: Airport_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes."Airport_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 281474976710655
    CACHE 1;


ALTER SEQUENCE flight_routes."Airport_id_seq" OWNER TO dst_graph_designer;

--
-- Name: Airport_id_seq; Type: SEQUENCE OWNED BY; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER SEQUENCE flight_routes."Airport_id_seq" OWNED BY flight_routes."Airport".id;


--
-- Name: _ag_label_edge; Type: TABLE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE TABLE flight_routes._ag_label_edge (
    id ag_catalog.graphid NOT NULL,
    start_id ag_catalog.graphid NOT NULL,
    end_id ag_catalog.graphid NOT NULL,
    properties ag_catalog.agtype DEFAULT ag_catalog.agtype_build_map() NOT NULL
);


ALTER TABLE flight_routes._ag_label_edge OWNER TO dst_graph_designer;

--
-- Name: ROUTE; Type: TABLE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE TABLE flight_routes."ROUTE" (
)
INHERITS (flight_routes._ag_label_edge);


ALTER TABLE flight_routes."ROUTE" OWNER TO dst_graph_designer;

--
-- Name: ROUTE_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes."ROUTE_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 281474976710655
    CACHE 1;


ALTER SEQUENCE flight_routes."ROUTE_id_seq" OWNER TO dst_graph_designer;

--
-- Name: ROUTE_id_seq; Type: SEQUENCE OWNED BY; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER SEQUENCE flight_routes."ROUTE_id_seq" OWNED BY flight_routes."ROUTE".id;


--
-- Name: _ag_label_edge_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes._ag_label_edge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 281474976710655
    CACHE 1;


ALTER SEQUENCE flight_routes._ag_label_edge_id_seq OWNER TO dst_graph_designer;

--
-- Name: _ag_label_edge_id_seq; Type: SEQUENCE OWNED BY; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER SEQUENCE flight_routes._ag_label_edge_id_seq OWNED BY flight_routes._ag_label_edge.id;


--
-- Name: _ag_label_vertex_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes._ag_label_vertex_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 281474976710655
    CACHE 1;


ALTER SEQUENCE flight_routes._ag_label_vertex_id_seq OWNER TO dst_graph_designer;

--
-- Name: _ag_label_vertex_id_seq; Type: SEQUENCE OWNED BY; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER SEQUENCE flight_routes._ag_label_vertex_id_seq OWNED BY flight_routes._ag_label_vertex.id;


--
-- Name: _label_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes._label_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 65535
    CACHE 1
    CYCLE;


ALTER SEQUENCE flight_routes._label_id_seq OWNER TO dst_graph_designer;

--
-- Name: scheduled_routes; Type: TABLE; Schema: l3; Owner: dst_graph_designer
--

CREATE TABLE l3.scheduled_routes (
    departure_airport_code character varying(50) NOT NULL,
    arrival_airport_code character varying(50) NOT NULL,
    avg_flight_duration_hours numeric
);


ALTER TABLE l3.scheduled_routes OWNER TO dst_graph_designer;

--
-- Name: scheduled_routes; Type: TABLE; Schema: public; Owner: dst_graph_designer
--

CREATE TABLE public.scheduled_routes (
    departure_airport_code character varying(50) NOT NULL,
    arrival_airport_code character varying(50) NOT NULL,
    avg_flight_duration_hours numeric
);


ALTER TABLE public.scheduled_routes OWNER TO dst_graph_designer;

--
-- Name: Airport id; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes."Airport" ALTER COLUMN id SET DEFAULT ag_catalog._graphid((ag_catalog._label_id('flight_routes'::name, 'Airport'::name))::integer, nextval('flight_routes."Airport_id_seq"'::regclass));


--
-- Name: Airport properties; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes."Airport" ALTER COLUMN properties SET DEFAULT ag_catalog.agtype_build_map();


--
-- Name: ROUTE id; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes."ROUTE" ALTER COLUMN id SET DEFAULT ag_catalog._graphid((ag_catalog._label_id('flight_routes'::name, 'ROUTE'::name))::integer, nextval('flight_routes."ROUTE_id_seq"'::regclass));


--
-- Name: ROUTE properties; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes."ROUTE" ALTER COLUMN properties SET DEFAULT ag_catalog.agtype_build_map();


--
-- Name: _ag_label_edge id; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes._ag_label_edge ALTER COLUMN id SET DEFAULT ag_catalog._graphid((ag_catalog._label_id('flight_routes'::name, '_ag_label_edge'::name))::integer, nextval('flight_routes._ag_label_edge_id_seq'::regclass));


--
-- Name: _ag_label_vertex id; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes._ag_label_vertex ALTER COLUMN id SET DEFAULT ag_catalog._graphid((ag_catalog._label_id('flight_routes'::name, '_ag_label_vertex'::name))::integer, nextval('flight_routes._ag_label_vertex_id_seq'::regclass));


--
-- Data for Name: ag_graph; Type: TABLE DATA; Schema: ag_catalog; Owner: dst_graph_designer
--

COPY ag_catalog.ag_graph (graphid, name, namespace) FROM stdin;
17040	flight_routes	flight_routes
\.


--
-- Data for Name: ag_label; Type: TABLE DATA; Schema: ag_catalog; Owner: dst_graph_designer
--

COPY ag_catalog.ag_label (name, graph, id, kind, relation, seq_name) FROM stdin;
_ag_label_vertex	17040	1	v	flight_routes._ag_label_vertex	_ag_label_vertex_id_seq
_ag_label_edge	17040	2	e	flight_routes._ag_label_edge	_ag_label_edge_id_seq
Airport	17040	3	v	flight_routes."Airport"	Airport_id_seq
ROUTE	17040	4	e	flight_routes."ROUTE"	ROUTE_id_seq
\.


--
-- Data for Name: Airport; Type: TABLE DATA; Schema: flight_routes; Owner: dst_graph_designer
--

COPY flight_routes."Airport" (id, properties) FROM stdin;
844424930131969	{"code": "GRU"}
844424930131970	{"code": "ATL"}
844424930131971	{"code": "CLT"}
844424930131972	{"code": "JFK"}
844424930131973	{"code": "MCO"}
844424930131974	{"code": "FRA"}
844424930131975	{"code": "EWR"}
844424930131976	{"code": "VIE"}
844424930131977	{"code": "LHR"}
844424930131978	{"code": "MUC"}
844424930131979	{"code": "SEA"}
844424930131980	{"code": "LAX"}
844424930131981	{"code": "LAS"}
844424930131982	{"code": "ATH"}
844424930131983	{"code": "DEN"}
844424930131984	{"code": "DXB"}
844424930131985	{"code": "MIA"}
844424930131986	{"code": "MAD"}
844424930131987	{"code": "ZRH"}
844424930131988	{"code": "DFW"}
844424930131989	{"code": "SFO"}
844424930131990	{"code": "BOG"}
844424930131991	{"code": "CAI"}
844424930131992	{"code": "MEX"}
844424930131993	{"code": "CDG"}
844424930131994	{"code": "ORD"}
844424930131995	{"code": "CMN"}
844424930131996	{"code": "OSL"}
844424930131997	{"code": "ARN"}
844424930131998	{"code": "AMS"}
844424930131999	{"code": "ONT"}
844424930132000	{"code": "LOS"}
844424930132001	{"code": "FCO"}
844424930132002	{"code": "DUB"}
844424930132003	{"code": "PVG"}
844424930132004	{"code": "BER"}
844424930132005	{"code": "LIS"}
844424930132006	{"code": "BKK"}
844424930132007	{"code": "AGY"}
844424930132008	{"code": "SAW"}
844424930132009	{"code": "PAE"}
844424930132010	{"code": "NLU"}
844424930132011	{"code": "MAN"}
844424930132012	{"code": "MRU"}
844424930132013	{"code": "HND"}
844424930132014	{"code": "DEL"}
844424930132015	{"code": "DMK"}
844424930132016	{"code": "WAW"}
844424930132017	{"code": "IST"}
844424930132018	{"code": "CPT"}
844424930132019	{"code": "SSH"}
844424930132020	{"code": "NBO"}
844424930132021	{"code": "NCE"}
844424930132022	{"code": "DMM"}
844424930132023	{"code": "PEK"}
844424930132024	{"code": "EKW"}
844424930132025	{"code": "AVT"}
844424930132026	{"code": "ALG"}
844424930132027	{"code": "ZMU"}
844424930132028	{"code": "DAL"}
844424930132029	{"code": "QPP"}
\.


--
-- Data for Name: ROUTE; Type: TABLE DATA; Schema: flight_routes; Owner: dst_graph_designer
--

COPY flight_routes."ROUTE" (id, start_id, end_id, properties) FROM stdin;
1125899906842934	844424930131994	844424930131973	{"route": "ORD -> MCO", "duration": 2.9314285714285715}
1125899906842999	844424930131970	844424930131971	{"route": "ATL -> CLT", "duration": 1.275609195402299}
1125899906842726	844424930131972	844424930131980	{"route": "JFK -> LAX", "duration": 6.379265106151334}
1125899906842930	844424930131981	844424930131989	{"route": "LAS -> SFO", "duration": 1.7617019607843136}
1125899906842994	844424930131984	844424930132014	{"route": "DXB -> DEL", "duration": 3.2168214285714285}
1125899906842849	844424930132023	844424930132006	{"route": "PEK -> BKK", "duration": 5.319764150943397}
1125899906842907	844424930131988	844424930131973	{"route": "DFW -> MCO", "duration": 2.656806451612903}
1125899906842777	844424930131980	844424930131988	{"route": "LAX -> DFW", "duration": 3.0950366568914958}
1125899906842905	844424930131979	844424930131989	{"route": "SEA -> SFO", "duration": 2.298772378516624}
1125899906843077	844424930131985	844424930131970	{"route": "MIA -> ATL", "duration": 2.1084358288770053}
1125899906842736	844424930131970	844424930131975	{"route": "ATL -> EWR", "duration": 2.2208773045136683}
1125899906842626	844424930131971	844424930131972	{"route": "CLT -> JFK", "duration": 1.9640993788819876}
1125899906843022	844424930131972	844424930131970	{"route": "JFK -> ATL", "duration": 2.6396708615682476}
1125899906842899	844424930131983	844424930131980	{"route": "DEN -> LAX", "duration": 2.632736179146256}
1125899906842764	844424930131972	844424930131981	{"route": "JFK -> LAS", "duration": 5.997402464065709}
1125899906842660	844424930131994	844424930131969	{"route": "ORD -> GRU", "duration": 10.25}
1125899906842687	844424930131994	844424930131993	{"route": "ORD -> CDG", "duration": 8.08}
1125899906842639	844424930131989	844424930131988	{"route": "SFO -> DFW", "duration": 3.600100908173562}
1125899906842651	844424930131974	844424930131985	{"route": "FRA -> MIA", "duration": 10.42}
1125899906842641	844424930131991	844424930131976	{"route": "CAI -> VIE", "duration": 3.75}
1125899906842677	844424930131981	844424930131994	{"route": "LAS -> ORD", "duration": 3.819625}
1125899906842647	844424930131976	844424930131994	{"route": "VIE -> ORD", "duration": 10.17}
1125899906842723	844424930131972	844424930131990	{"route": "JFK -> BOG", "duration": 5.896}
1125899906842700	844424930131990	844424930131970	{"route": "BOG -> ATL", "duration": 5.146107784431138}
1125899906842765	844424930131975	844424930131973	{"route": "EWR -> MCO", "duration": 3.06988241881299}
1125899906842951	844424930131980	844424930131994	{"route": "LAX -> ORD", "duration": 4.148085912823753}
1125899906842714	844424930131975	844424930132004	{"route": "EWR -> BER", "duration": 8.08}
1125899906842657	844424930131994	844424930131980	{"route": "ORD -> LAX", "duration": 4.638748427672956}
1125899906842674	844424930131974	844424930131981	{"route": "FRA -> LAS", "duration": 11.75}
1125899906842702	844424930131973	844424930131985	{"route": "MCO -> MIA", "duration": 2.710267441860465}
1125899906842679	844424930131970	844424930131994	{"route": "ATL -> ORD", "duration": 2.1616730917501927}
1125899906842631	844424930131971	844424930131981	{"route": "CLT -> LAS", "duration": 5.020639431616341}
1125899906842706	844424930131980	844424930132009	{"route": "LAX -> PAE", "duration": 2.9669642857142855}
1125899906842655	844424930131999	844424930131988	{"route": "ONT -> DFW", "duration": 2.9681663113006396}
1125899906842698	844424930131983	844424930131971	{"route": "DEN -> CLT", "duration": 3.2365573770491802}
1125899906842642	844424930131970	844424930131979	{"route": "ATL -> SEA", "duration": 5.747710674157303}
1125899906842633	844424930131983	844424930131977	{"route": "DEN -> LHR", "duration": 9.08}
1125899906842628	844424930131975	844424930131976	{"route": "EWR -> VIE", "duration": 8.100769230769231}
1125899906842682	844424930131973	844424930131992	{"route": "MCO -> MEX", "duration": 3.9314141414141415}
1125899906842644	844424930131992	844424930131969	{"route": "MEX -> GRU", "duration": 9.575894736842105}
1125899906842683	844424930131974	844424930132005	{"route": "FRA -> LIS", "duration": 3.220126582278481}
1125899906842697	844424930131978	844424930132003	{"route": "MUC -> PVG", "duration": 11.434594594594595}
1125899906842666	844424930131990	844424930131973	{"route": "BOG -> MCO", "duration": 4.270988372093023}
1125899906842638	844424930131988	844424930131979	{"route": "DFW -> SEA", "duration": 4.501757624398074}
1125899906842708	844424930131993	844424930131987	{"route": "CDG -> ZRH", "duration": 1.3112464589235127}
1125899906842678	844424930131988	844424930131990	{"route": "DFW -> BOG", "duration": 5.334891304347826}
1125899906842669	844424930131976	844424930132004	{"route": "VIE -> BER", "duration": 1.2521649484536082}
1125899906842712	844424930131978	844424930132006	{"route": "MUC -> BKK", "duration": 10.5}
1125899906842653	844424930131976	844424930131997	{"route": "VIE -> ARN", "duration": 2.25}
1125899906842670	844424930131981	844424930131972	{"route": "LAS -> JFK", "duration": 5.0053936170212765}
1125899906842675	844424930131978	844424930131994	{"route": "MUC -> ORD", "duration": 9.788536585365854}
1125899906842722	844424930131994	844424930131972	{"route": "ORD -> JFK", "duration": 2.361761744966443}
1125899906842673	844424930131987	844424930131994	{"route": "ZRH -> ORD", "duration": 10.08}
1125899906842635	844424930131978	844424930131984	{"route": "MUC -> DXB", "duration": 5.83}
1125899906842846	844424930131983	844424930131988	{"route": "DEN -> DFW", "duration": 2.0707340720221605}
1125899906842629	844424930131977	844424930131978	{"route": "LHR -> MUC", "duration": 1.83}
1125899906842716	844424930131973	844424930131990	{"route": "MCO -> BOG", "duration": 3.98937984496124}
1125899906842632	844424930131982	844424930131975	{"route": "ATH -> EWR", "duration": 11.17}
1125899906842634	844424930131983	844424930131972	{"route": "DEN -> JFK", "duration": 3.752279411764706}
1125899906842662	844424930131987	844424930131978	{"route": "ZRH -> MUC", "duration": 0.9335294117647058}
1125899906842717	844424930131977	844424930131976	{"route": "LHR -> VIE", "duration": 2.232608695652174}
1125899906842809	844424930131972	844424930131985	{"route": "JFK -> MIA", "duration": 3.3296728624535317}
1125899906842709	844424930132011	844424930131976	{"route": "MAN -> VIE", "duration": 2.42}
1125899906842754	844424930131985	844424930131972	{"route": "MIA -> JFK", "duration": 3.0710708898944192}
1125899906842692	844424930131975	844424930131970	{"route": "EWR -> ATL", "duration": 2.5506363636363636}
1125899906842990	844424930131988	844424930131970	{"route": "DFW -> ATL", "duration": 2.210457142857143}
1125899906842855	844424930131984	844424930131978	{"route": "DXB -> MUC", "duration": 6.75}
1125899906842680	844424930131981	844424930131983	{"route": "LAS -> DEN", "duration": 2.0038709677419355}
1125899906842668	844424930131970	844424930131972	{"route": "ATL -> JFK", "duration": 2.26624254473161}
1125899906842721	844424930132011	844424930131987	{"route": "MAN -> ZRH", "duration": 1.963743842364532}
1125899906842645	844424930131978	844424930131974	{"route": "MUC -> FRA", "duration": 1.08}
1125899906842640	844424930131990	844424930131985	{"route": "BOG -> MIA", "duration": 3.9487801516195726}
1125899906842676	844424930131980	844424930131989	{"route": "LAX -> SFO", "duration": 1.5081373172282262}
1125899906842689	844424930132008	844424930131974	{"route": "SAW -> FRA", "duration": 3.3775379939209724}
1125899906842665	844424930131994	844424930131983	{"route": "ORD -> DEN", "duration": 2.832296819787986}
1125899906842699	844424930131983	844424930131970	{"route": "DEN -> ATL", "duration": 2.9507809523809523}
1125899906842656	844424930131979	844424930131978	{"route": "SEA -> MUC", "duration": 10.08}
1125899906842630	844424930131979	844424930131980	{"route": "SEA -> LAX", "duration": 2.983057971014493}
1125899906842671	844424930131987	844424930131977	{"route": "ZRH -> LHR", "duration": 1.867142857142857}
1125899906842663	844424930131980	844424930131983	{"route": "LAX -> DEN", "duration": 2.454940014114326}
1125899906842652	844424930131996	844424930131978	{"route": "OSL -> MUC", "duration": 2.408093385214008}
1125899906842701	844424930132009	844424930131981	{"route": "PAE -> LAS", "duration": 2.5426490066225167}
1125899906842648	844424930131974	844424930131995	{"route": "FRA -> CMN", "duration": 3.75}
1125899906842696	844424930131970	844424930131992	{"route": "ATL -> MEX", "duration": 3.8900873362445414}
1125899906842718	844424930132013	844424930131974	{"route": "HND -> FRA", "duration": 14.674029850746269}
1125899906842720	844424930132014	844424930131978	{"route": "DEL -> MUC", "duration": 8.92}
1125899906842873	844424930131995	844424930132017	{"route": "CMN -> IST", "duration": 4.568859649122807}
1125899906842664	844424930131969	844424930131980	{"route": "GRU -> LAX", "duration": 12.33}
1125899906842661	844424930131987	844424930132002	{"route": "ZRH -> DUB", "duration": 2.4169767441860466}
1125899906842694	844424930131997	844424930131976	{"route": "ARN -> VIE", "duration": 2.25}
1125899906842685	844424930132007	844424930131974	{"route": "AGY -> FRA", "duration": 3.195675675675676}
1125899906842654	844424930131978	844424930131998	{"route": "MUC -> AMS", "duration": 1.67}
1125899906842667	844424930131974	844424930132003	{"route": "FRA -> PVG", "duration": 11.469268292682926}
1125899906842658	844424930132000	844424930131974	{"route": "LOS -> FRA", "duration": 6.58}
1125899906842693	844424930131979	844424930131971	{"route": "SEA -> CLT", "duration": 4.995098814229249}
1125899906842636	844424930131985	844424930131969	{"route": "MIA -> GRU", "duration": 8.323555900621118}
1125899906842705	844424930131971	844424930131970	{"route": "CLT -> ATL", "duration": 1.3943222308288148}
1125899906842715	844424930131989	844424930131981	{"route": "SFO -> LAS", "duration": 1.8370466717674063}
1125899906842643	844424930131973	844424930131981	{"route": "MCO -> LAS", "duration": 6.420481481481482}
1125899906842704	844424930131994	844424930132010	{"route": "ORD -> NLU", "duration": 4.25}
1125899906842719	844424930132010	844424930131994	{"route": "NLU -> ORD", "duration": 4.08}
1125899906842688	844424930131974	844424930132008	{"route": "FRA -> SAW", "duration": 3.117576687116564}
1125899906842711	844424930131987	844424930132012	{"route": "ZRH -> MRU", "duration": 11.75}
1125899906842681	844424930131989	844424930131971	{"route": "SFO -> CLT", "duration": 5.077682619647355}
1125899906842650	844424930131983	844424930131973	{"route": "DEN -> MCO", "duration": 3.9404830287206267}
1125899906842989	844424930131972	844424930131973	{"route": "JFK -> MCO", "duration": 3.0755913173652694}
1125899906842713	844424930131981	844424930131980	{"route": "LAS -> LAX", "duration": 1.3313852813852813}
1125899906842778	844424930131983	844424930131992	{"route": "DEN -> MEX", "duration": 3.9513432835820894}
1125899906842796	844424930131979	844424930131992	{"route": "SEA -> MEX", "duration": 5.552087912087912}
1125899906842752	844424930131975	844424930131969	{"route": "EWR -> GRU", "duration": 9.5}
1125899906842864	844424930131992	844424930131971	{"route": "MEX -> CLT", "duration": 3.7551111111111113}
1125899906842784	844424930131989	844424930131987	{"route": "SFO -> ZRH", "duration": 11.08}
1125899906842774	844424930131975	844424930131998	{"route": "EWR -> AMS", "duration": 7.17}
1125899906842820	844424930131976	844424930132003	{"route": "VIE -> PVG", "duration": 11.08}
1125899906842769	844424930132001	844424930131994	{"route": "FCO -> ORD", "duration": 10.33}
1125899906842789	844424930132005	844424930131986	{"route": "LIS -> MAD", "duration": 1.4111363636363636}
1125899906842740	844424930131976	844424930131972	{"route": "VIE -> JFK", "duration": 9.75}
1125899906842833	844424930131975	844424930132001	{"route": "EWR -> FCO", "duration": 8.58}
1125899906842828	844424930131975	844424930131978	{"route": "EWR -> MUC", "duration": 7.713472222222222}
1125899906842790	844424930131973	844424930132010	{"route": "MCO -> NLU", "duration": 3.42}
1125899906842794	844424930131999	844424930131994	{"route": "ONT -> ORD", "duration": 6.171578947368421}
1125899906842886	844424930131974	844424930131983	{"route": "FRA -> DEN", "duration": 10.588652482269504}
1125899906842798	844424930131983	844424930132010	{"route": "DEN -> NLU", "duration": 3.58}
1125899906842802	844424930131980	844424930132010	{"route": "LAX -> NLU", "duration": 3.67}
1125899906842763	844424930131975	844424930131974	{"route": "EWR -> FRA", "duration": 7.46045}
1125899906842879	844424930132003	844424930131987	{"route": "PVG -> ZRH", "duration": 14.33}
1125899906842878	844424930131975	844424930132005	{"route": "EWR -> LIS", "duration": 6.58}
1125899906842876	844424930131969	844424930131978	{"route": "GRU -> MUC", "duration": 11.58}
1125899906842826	844424930131969	844424930131973	{"route": "GRU -> MCO", "duration": 9}
1125899906842760	844424930131974	844424930132018	{"route": "FRA -> CPT", "duration": 11.67}
1125899906842776	844424930131975	844424930131992	{"route": "EWR -> MEX", "duration": 5.6596336996337}
1125899906842806	844424930131974	844424930132022	{"route": "FRA -> DMM", "duration": 7.58}
1125899906842887	844424930131981	844424930131974	{"route": "LAS -> FRA", "duration": 11}
1125899906842844	844424930131974	844424930132012	{"route": "FRA -> MRU", "duration": 11.25}
1125899906842863	844424930131985	844424930132010	{"route": "MIA -> NLU", "duration": 3.42}
1125899906842824	844424930131990	844424930131975	{"route": "BOG -> EWR", "duration": 6.0350909090909095}
1125899906842866	844424930131994	844424930132001	{"route": "ORD -> FCO", "duration": 8.92}
1125899906842867	844424930132010	844424930131973	{"route": "NLU -> MCO", "duration": 3.08}
1125899906842881	844424930131974	844424930131992	{"route": "FRA -> MEX", "duration": 12.33}
1125899906842762	844424930131974	844424930132013	{"route": "FRA -> HND", "duration": 13.013396226415095}
1125899906842811	844424930131988	844424930131974	{"route": "DFW -> FRA", "duration": 9.83}
1125899906842730	844424930131994	844424930131976	{"route": "ORD -> VIE", "duration": 8.75}
1125899906842869	844424930131980	844424930131974	{"route": "LAX -> FRA", "duration": 10.92}
1125899906842735	844424930131972	844424930131978	{"route": "JFK -> MUC", "duration": 7.5}
1125899906842860	844424930131971	844424930131999	{"route": "CLT -> ONT", "duration": 5.2092307692307696}
1125899906842856	844424930131974	844424930131973	{"route": "FRA -> MCO", "duration": 10.75}
1125899906842834	844424930131980	844424930131987	{"route": "LAX -> ZRH", "duration": 11.08}
1125899906842825	844424930131974	844424930131979	{"route": "FRA -> SEA", "duration": 10.83}
1125899906842847	844424930131998	844424930131975	{"route": "AMS -> EWR", "duration": 8.42}
1125899906842766	844424930131974	844424930131991	{"route": "FRA -> CAI", "duration": 4.152645739910314}
1125899906842756	844424930131974	844424930131972	{"route": "FRA -> JFK", "duration": 8.976434108527132}
1125899906842816	844424930131978	844424930132023	{"route": "MUC -> PEK", "duration": 9.915793103448276}
1125899906842821	844424930131978	844424930132002	{"route": "MUC -> DUB", "duration": 2.58}
1125899906842785	844424930131978	844424930131980	{"route": "MUC -> LAX", "duration": 12.215176470588235}
1125899906842872	844424930131978	844424930132011	{"route": "MUC -> MAN", "duration": 2.25}
1125899906842889	844424930131974	844424930132021	{"route": "FRA -> NCE", "duration": 1.58}
1125899906842743	844424930131978	844424930131979	{"route": "MUC -> SEA", "duration": 10.67}
1125899906842884	844424930131986	844424930131978	{"route": "MAD -> MUC", "duration": 2.58}
1125899906842772	844424930131997	844424930132004	{"route": "ARN -> BER", "duration": 1.58}
1125899906842749	844424930131976	844424930131982	{"route": "VIE -> ATH", "duration": 2.154018691588785}
1125899906842830	844424930132011	844424930131978	{"route": "MAN -> MUC", "duration": 1.92}
1125899906842787	844424930131978	844424930131997	{"route": "MUC -> ARN", "duration": 2.25}
1125899906842812	844424930131978	844424930131982	{"route": "MUC -> ATH", "duration": 2.4573614775725594}
1125899906842744	844424930131997	844424930131987	{"route": "ARN -> ZRH", "duration": 2.4440579710144927}
1125899906842854	844424930131976	844424930132001	{"route": "VIE -> FCO", "duration": 1.5824489795918366}
1125899906842732	844424930132016	844424930131987	{"route": "WAW -> ZRH", "duration": 2.085086956521739}
1125899906842814	844424930131997	844424930131996	{"route": "ARN -> OSL", "duration": 1.0254814814814814}
1125899906842759	844424930131982	844424930131978	{"route": "ATH -> MUC", "duration": 2.7126385224274405}
1125899906842733	844424930132001	844424930131974	{"route": "FCO -> FRA", "duration": 2}
1125899906842801	844424930131987	844424930132021	{"route": "ZRH -> NCE", "duration": 1.196959706959707}
1125899906842827	844424930132002	844424930131987	{"route": "DUB -> ZRH", "duration": 2.17}
1125899906842819	844424930132002	844424930131974	{"route": "DUB -> FRA", "duration": 2}
1125899906842731	844424930132003	844424930131976	{"route": "PVG -> VIE", "duration": 12.92}
1125899906842805	844424930131974	844424930132002	{"route": "FRA -> DUB", "duration": 2.17}
1125899906842724	844424930132015	844424930132003	{"route": "DMK -> PVG", "duration": 4.08}
1125899906842750	844424930132017	844424930132000	{"route": "IST -> LOS", "duration": 7.25}
1125899906842850	844424930132014	844424930131987	{"route": "DEL -> ZRH", "duration": 9.08}
1125899906842848	844424930132013	844424930131978	{"route": "HND -> MUC", "duration": 14.681363636363637}
1125899906842767	844424930131991	844424930131987	{"route": "CAI -> ZRH", "duration": 4.17}
1125899906842861	844424930132014	844424930132006	{"route": "DEL -> BKK", "duration": 3.9745328719723183}
1125899906842853	844424930131995	844424930132008	{"route": "CMN -> SAW", "duration": 4.776456692913386}
1125899906842799	844424930132012	844424930132020	{"route": "MRU -> NBO", "duration": 4.254848484848485}
1125899906842739	844424930131970	844424930131974	{"route": "ATL -> FRA", "duration": 8.75}
1125899906842883	844424930131985	844424930131987	{"route": "MIA -> ZRH", "duration": 9.077916666666667}
1125899906842877	844424930131994	844424930131974	{"route": "ORD -> FRA", "duration": 8.436219931271477}
1125899906842868	844424930131999	844424930131989	{"route": "ONT -> SFO", "duration": 1.57438202247191}
1125899906842808	844424930131985	844424930131979	{"route": "MIA -> SEA", "duration": 6.92916955017301}
1125899906842841	844424930131971	844424930131992	{"route": "CLT -> MEX", "duration": 4.441978021978022}
1125899906842838	844424930132012	844424930131976	{"route": "MRU -> VIE", "duration": 10.83}
1125899906842793	844424930132012	844424930131987	{"route": "MRU -> ZRH", "duration": 12.306666666666667}
1125899906842761	844424930131972	844424930131988	{"route": "JFK -> DFW", "duration": 4.234880174291939}
1125899906842885	844424930131980	844424930131992	{"route": "LAX -> MEX", "duration": 3.7379644588045235}
1125899906842779	844424930131971	844424930131979	{"route": "CLT -> SEA", "duration": 5.9299209486166005}
1125899906842748	844424930131979	844424930131985	{"route": "SEA -> MIA", "duration": 6.005909090909091}
1125899906842773	844424930131989	844424930131999	{"route": "SFO -> ONT", "duration": 1.4939}
1125899906842870	844424930131985	844424930131989	{"route": "MIA -> SFO", "duration": 6.785247311827957}
1125899906842782	844424930131972	844424930131976	{"route": "JFK -> VIE", "duration": 8.25}
1125899906842845	844424930131974	844424930132011	{"route": "FRA -> MAN", "duration": 1.83}
1125899906842837	844424930131972	844424930131979	{"route": "JFK -> SEA", "duration": 6.479084745762712}
1125899906842795	844424930131972	844424930131969	{"route": "JFK -> GRU", "duration": 9.57429149797571}
1125899906842758	844424930131992	844424930131970	{"route": "MEX -> ATL", "duration": 3.409690949227373}
1125899906842792	844424930131989	844424930131992	{"route": "SFO -> MEX", "duration": 4.392541666666666}
1125899906842780	844424930131974	844424930131993	{"route": "FRA -> CDG", "duration": 1.25}
1125899906842746	844424930132004	844424930131976	{"route": "BER -> VIE", "duration": 1.2525773195876289}
1125899906842725	844424930131992	844424930131980	{"route": "MEX -> LAX", "duration": 4.320392156862745}
1125899906842862	844424930131974	844424930131994	{"route": "FRA -> ORD", "duration": 9.495224913494809}
1125899906842829	844424930131981	844424930131971	{"route": "LAS -> CLT", "duration": 4.248309859154929}
1125899906842737	844424930131992	844424930131985	{"route": "MEX -> MIA", "duration": 3.248091068301226}
1125899906842859	844424930131969	844424930131972	{"route": "GRU -> JFK", "duration": 9.96022633744856}
1125899906842817	844424930131974	844424930132016	{"route": "FRA -> WAW", "duration": 1.699853249475891}
1125899906842823	844424930131974	844424930131982	{"route": "FRA -> ATH", "duration": 2.7821818181818183}
1125899906842843	844424930131999	844424930131971	{"route": "ONT -> CLT", "duration": 4.886567164179104}
1125899906842835	844424930132005	844424930131974	{"route": "LIS -> FRA", "duration": 3.1329583333333333}
1125899906842728	844424930131992	844424930131990	{"route": "MEX -> BOG", "duration": 4.556431535269709}
1125899906842874	844424930131974	844424930131987	{"route": "FRA -> ZRH", "duration": 0.9510668563300142}
1125899906842871	844424930131970	844424930131989	{"route": "ATL -> SFO", "duration": 5.444956647398844}
1125899906842727	844424930131983	844424930131985	{"route": "DEN -> MIA", "duration": 4.111301059001513}
1125899906842738	844424930131987	844424930131974	{"route": "ZRH -> FRA", "duration": 1.0916455696202532}
1125899906842851	844424930131980	844424930131971	{"route": "LAX -> CLT", "duration": 4.818252569750367}
1125899906842882	844424930131973	844424930132025	{"route": "MCO -> AVT", "duration": 3.0738645418326693}
1125899906842803	844424930131987	844424930132004	{"route": "ZRH -> BER", "duration": 1.472284263959391}
1125899906842729	844424930131988	844424930131975	{"route": "DFW -> EWR", "duration": 3.373606027987083}
1125899906842852	844424930131975	844424930131981	{"route": "EWR -> LAS", "duration": 5.737207872078721}
1125899906842857	844424930131973	844424930132024	{"route": "MCO -> EKW", "duration": 3.479039301310044}
1125899906842813	844424930131971	844424930131975	{"route": "CLT -> EWR", "duration": 1.907801724137931}
1125899906842875	844424930131989	844424930131994	{"route": "SFO -> ORD", "duration": 4.3521973929236495}
1125899906842788	844424930131989	844424930131983	{"route": "SFO -> DEN", "duration": 2.673780487804878}
1125899906842810	844424930131976	844424930131974	{"route": "VIE -> FRA", "duration": 1.492482690405539}
1125899906842770	844424930131974	844424930132004	{"route": "FRA -> BER", "duration": 1.17}
1125899906842768	844424930131994	844424930131971	{"route": "ORD -> CLT", "duration": 2.0695652173913044}
1125899906842775	844424930131981	844424930131970	{"route": "LAS -> ATL", "duration": 3.937844990548204}
1125899906842747	844424930131994	844424930131979	{"route": "ORD -> SEA", "duration": 4.841332644628099}
1125899906842742	844424930131985	844424930131994	{"route": "MIA -> ORD", "duration": 3.6398909395973154}
1125899906842880	844424930131979	844424930131988	{"route": "SEA -> DFW", "duration": 3.9503293172690763}
1125899906842836	844424930131973	844424930131988	{"route": "MCO -> DFW", "duration": 3.1469192751235586}
1125899906842964	844424930131973	844424930131972	{"route": "MCO -> JFK", "duration": 2.690568978955573}
1125899906842897	844424930132010	844424930131990	{"route": "NLU -> BOG", "duration": 4.5}
1125899906842902	844424930131988	844424930132010	{"route": "DFW -> NLU", "duration": 2.67}
1125899906842893	844424930131986	844424930131975	{"route": "MAD -> EWR", "duration": 8.92}
1125899906842936	844424930131992	844424930131978	{"route": "MEX -> MUC", "duration": 10.75}
1125899906842946	844424930131992	844424930131983	{"route": "MEX -> DEN", "duration": 3.9518045112781954}
1125899906842927	844424930131975	844424930131982	{"route": "EWR -> ATH", "duration": 9.5}
1125899906842932	844424930131974	844424930132000	{"route": "FRA -> LOS", "duration": 6.5}
1125899906842894	844424930131976	844424930131996	{"route": "VIE -> OSL", "duration": 2.33}
1125899906842928	844424930131976	844424930131991	{"route": "VIE -> CAI", "duration": 3.42}
1125899906843025	844424930132005	844424930131975	{"route": "LIS -> EWR", "duration": 8.17}
1125899906842957	844424930131989	844424930131993	{"route": "SFO -> CDG", "duration": 10.75}
1125899906843039	844424930131976	844424930132021	{"route": "VIE -> NCE", "duration": 1.75}
1125899906842963	844424930132004	844424930132021	{"route": "BER -> NCE", "duration": 2}
1125899906842960	844424930131976	844424930132012	{"route": "VIE -> MRU", "duration": 10.25}
1125899906843028	844424930131969	844424930131987	{"route": "GRU -> ZRH", "duration": 11.227142857142857}
1125899906842962	844424930131990	844424930131987	{"route": "BOG -> ZRH", "duration": 12.96}
1125899906843045	844424930131975	844424930131987	{"route": "EWR -> ZRH", "duration": 7.58}
1125899906842903	844424930131989	844424930131978	{"route": "SFO -> MUC", "duration": 11.127245508982035}
1125899906842992	844424930131989	844424930131977	{"route": "SFO -> LHR", "duration": 10.58}
1125899906843026	844424930131974	844424930131984	{"route": "FRA -> DXB", "duration": 6.42}
1125899906842896	844424930131974	844424930132026	{"route": "FRA -> ALG", "duration": 2.58}
1125899906842892	844424930131987	844424930131984	{"route": "ZRH -> DXB", "duration": 6.194347826086957}
1125899906842925	844424930131974	844424930131990	{"route": "FRA -> BOG", "duration": 11.5}
1125899906843049	844424930131974	844424930131988	{"route": "FRA -> DFW", "duration": 11.33}
1125899906842939	844424930131974	844424930132014	{"route": "FRA -> DEL", "duration": 7.864335260115607}
1125899906843038	844424930132026	844424930131995	{"route": "ALG -> CMN", "duration": 2}
1125899906843013	844424930131985	844424930131978	{"route": "MIA -> MUC", "duration": 9}
1125899906843031	844424930132019	844424930131987	{"route": "SSH -> ZRH", "duration": 4.876666666666667}
1125899906842985	844424930132020	844424930131974	{"route": "NBO -> FRA", "duration": 9.08}
1125899906842940	844424930131994	844424930131978	{"route": "ORD -> MUC", "duration": 8.458787878787879}
1125899906842984	844424930132028	844424930131979	{"route": "DAL -> SEA", "duration": 4.506835443037975}
1125899906843027	844424930131972	844424930131974	{"route": "JFK -> FRA", "duration": 7.693384615384615}
1125899906843046	844424930131985	844424930131974	{"route": "MIA -> FRA", "duration": 9}
1125899906842947	844424930131981	844424930131992	{"route": "LAS -> MEX", "duration": 3.803201581027668}
1125899906843020	844424930131974	844424930131980	{"route": "FRA -> LAX", "duration": 11.67}
1125899906842938	844424930131974	844424930132020	{"route": "FRA -> NBO", "duration": 8.5}
1125899906842901	844424930131978	844424930132014	{"route": "MUC -> DEL", "duration": 7.42}
1125899906843012	844424930131974	844424930131975	{"route": "FRA -> EWR", "duration": 8.75405}
1125899906842983	844424930131974	844424930131969	{"route": "FRA -> GRU", "duration": 12}
1125899906843002	844424930131974	844424930131986	{"route": "FRA -> MAD", "duration": 2.75}
1125899906842970	844424930131978	844424930132013	{"route": "MUC -> HND", "duration": 12.507816091954023}
1125899906842910	844424930131978	844424930131992	{"route": "MUC -> MEX", "duration": 13}
1125899906842944	844424930132004	844424930131975	{"route": "BER -> EWR", "duration": 9.33}
1125899906842943	844424930131978	844424930131975	{"route": "MUC -> EWR", "duration": 9.104027777777778}
1125899906843029	844424930131977	844424930131983	{"route": "LHR -> DEN", "duration": 9.83}
1125899906843019	844424930131977	844424930131989	{"route": "LHR -> SFO", "duration": 11.17}
1125899906842979	844424930131996	844424930131987	{"route": "OSL -> ZRH", "duration": 2.5972093023255813}
1125899906842969	844424930131978	844424930132021	{"route": "MUC -> NCE", "duration": 1.5}
1125899906842912	844424930132004	844424930131997	{"route": "BER -> ARN", "duration": 1.6966666666666668}
1125899906842924	844424930132001	844424930131976	{"route": "FCO -> VIE", "duration": 1.6595238095238094}
1125899906843044	844424930131982	844424930131987	{"route": "ATH -> ZRH", "duration": 2.907241379310345}
1125899906842993	844424930131987	844424930132018	{"route": "ZRH -> CPT", "duration": 11.459245283018868}
1125899906842916	844424930131987	844424930131989	{"route": "ZRH -> SFO", "duration": 12.17}
1125899906842978	844424930131976	844424930131998	{"route": "VIE -> AMS", "duration": 1.92}
1125899906843035	844424930131987	844424930131985	{"route": "ZRH -> MIA", "duration": 10.743411764705883}
1125899906842914	844424930131996	844424930131974	{"route": "OSL -> FRA", "duration": 2.33}
1125899906842890	844424930131987	844424930131969	{"route": "ZRH -> GRU", "duration": 11.964673913043478}
1125899906843054	844424930131976	844424930132016	{"route": "VIE -> WAW", "duration": 1.2514285714285713}
1125899906842973	844424930131976	844424930131993	{"route": "VIE -> CDG", "duration": 2.08}
1125899906842971	844424930131987	844424930131996	{"route": "ZRH -> OSL", "duration": 2.5}
1125899906842929	844424930131993	844424930131975	{"route": "CDG -> EWR", "duration": 8.5476}
1125899906843018	844424930131987	844424930131982	{"route": "ZRH -> ATH", "duration": 2.633103448275862}
1125899906843021	844424930131987	844424930131990	{"route": "ZRH -> BOG", "duration": 11.92}
1125899906843000	844424930131987	844424930131998	{"route": "ZRH -> AMS", "duration": 1.686}
1125899906843056	844424930132021	844424930131974	{"route": "NCE -> FRA", "duration": 1.67}
1125899906842987	844424930132022	844424930131974	{"route": "DMM -> FRA", "duration": 8.5}
1125899906842968	844424930132021	844424930131978	{"route": "NCE -> MUC", "duration": 1.42}
1125899906843042	844424930132021	844424930131987	{"route": "NCE -> ZRH", "duration": 1.245897435897436}
1125899906842895	844424930131984	844424930131974	{"route": "DXB -> FRA", "duration": 7.25}
1125899906842920	844424930131984	844424930132004	{"route": "DXB -> BER", "duration": 7}
1125899906842953	844424930131993	844424930131974	{"route": "CDG -> FRA", "duration": 1.33}
1125899906842991	844424930132003	844424930132015	{"route": "PVG -> DMK", "duration": 4.757518248175183}
1125899906842937	844424930131982	844424930131974	{"route": "ATH -> FRA", "duration": 3.1816179775280897}
1125899906842909	844424930132006	844424930131976	{"route": "BKK -> VIE", "duration": 11.58}
1125899906842898	844424930132008	844424930132019	{"route": "SAW -> SSH", "duration": 2.58}
1125899906843036	844424930132018	844424930131978	{"route": "CPT -> MUC", "duration": 11.25}
1125899906843040	844424930132023	844424930131974	{"route": "PEK -> FRA", "duration": 10.519909502262443}
1125899906842950	844424930131970	844424930131999	{"route": "ATL -> ONT", "duration": 4.840538116591929}
1125899906843016	844424930131994	844424930131998	{"route": "ORD -> AMS", "duration": 8.42}
1125899906843014	844424930131994	844424930131977	{"route": "ORD -> LHR", "duration": 8.08}
1125899906842959	844424930131999	844424930131970	{"route": "ONT -> ATL", "duration": 4.137777777777778}
1125899906842935	844424930131994	844424930131992	{"route": "ORD -> MEX", "duration": 4.636536082474227}
1125899906843024	844424930131988	844424930131992	{"route": "DFW -> MEX", "duration": 2.8475}
1125899906842996	844424930131974	844424930132023	{"route": "FRA -> PEK", "duration": 9.386986301369863}
1125899906843034	844424930131973	844424930131989	{"route": "MCO -> SFO", "duration": 6.502087378640777}
1125899906842926	844424930131985	844424930131992	{"route": "MIA -> MEX", "duration": 3.8449122807017546}
1125899906842919	844424930131971	844424930131989	{"route": "CLT -> SFO", "duration": 5.856971279373368}
1125899906842988	844424930131974	844424930132001	{"route": "FRA -> FCO", "duration": 1.83}
1125899906842900	844424930131992	844424930131989	{"route": "MEX -> SFO", "duration": 5.0126875}
1125899906842941	844424930131971	844424930131980	{"route": "CLT -> LAX", "duration": 5.4967220543806645}
1125899906843015	844424930131978	844424930131987	{"route": "MUC -> ZRH", "duration": 0.9354696132596685}
1125899906842955	844424930131992	844424930131972	{"route": "MEX -> JFK", "duration": 4.755779334500875}
1125899906842945	844424930131989	844424930131985	{"route": "SFO -> MIA", "duration": 5.508521939953811}
1125899906843007	844424930131990	844424930131972	{"route": "BOG -> JFK", "duration": 5.848}
1125899906843055	844424930131975	844424930131977	{"route": "EWR -> LHR", "duration": 7.274791666666666}
1125899906842906	844424930131974	844424930131998	{"route": "FRA -> AMS", "duration": 1.25}
1125899906843043	844424930131978	844424930132016	{"route": "MUC -> WAW", "duration": 1.5683030303030303}
1125899906843032	844424930131974	844424930132029	{"route": "FRA -> QPP", "duration": 4.418061749571184}
1125899906843041	844424930131990	844424930131992	{"route": "BOG -> MEX", "duration": 4.872544951590594}
1125899906843008	844424930131977	844424930131987	{"route": "LHR -> ZRH", "duration": 1.796335403726708}
1125899906842998	844424930131977	844424930131975	{"route": "LHR -> EWR", "duration": 8.510206022187004}
1125899906842931	844424930131974	844424930132027	{"route": "FRA -> ZMU", "duration": 3.477359413202934}
1125899906842915	844424930132027	844424930131974	{"route": "ZMU -> FRA", "duration": 3.4778381795195954}
1125899906842965	844424930131976	844424930131987	{"route": "VIE -> ZRH", "duration": 1.3844668587896254}
1125899906843005	844424930131978	844424930131977	{"route": "MUC -> LHR", "duration": 2.08}
1125899906842956	844424930131985	844424930131980	{"route": "MIA -> LAX", "duration": 6.190499419279907}
1125899906842972	844424930131980	844424930131985	{"route": "LAX -> MIA", "duration": 4.936471935853379}
1125899906843030	844424930131980	844424930131973	{"route": "LAX -> MCO", "duration": 5.472754182754183}
1125899906842977	844424930131989	844424930131975	{"route": "SFO -> EWR", "duration": 5.458590998043053}
1125899906843050	844424930131973	844424930131980	{"route": "MCO -> LAX", "duration": 6.013715846994535}
1125899906842918	844424930132024	844424930131973	{"route": "EKW -> MCO", "duration": 3.4636496350364965}
1125899906843001	844424930131971	844424930131985	{"route": "CLT -> MIA", "duration": 2.1812252964426877}
1125899906842982	844424930132025	844424930131973	{"route": "AVT -> MCO", "duration": 3.143809523809524}
1125899906843033	844424930131971	844424930131988	{"route": "CLT -> DFW", "duration": 3.047683615819209}
1125899906842923	844424930131974	844424930131976	{"route": "FRA -> VIE", "duration": 1.405025025025025}
1125899906843053	844424930131974	844424930131977	{"route": "FRA -> LHR", "duration": 1.75}
1125899906842891	844424930131977	844424930131974	{"route": "LHR -> FRA", "duration": 1.58}
1125899906842922	844424930131981	844424930131975	{"route": "LAS -> EWR", "duration": 5.0187234042553195}
1125899906842917	844424930131985	844424930131988	{"route": "MIA -> DFW", "duration": 3.5133389261744967}
1125899906843061	844424930131996	844424930131997	{"route": "OSL -> ARN", "duration": 1.1348979591836734}
1125899906843062	844424930132014	844424930132013	{"route": "DEL -> HND", "duration": 7.5}
1125899906843071	844424930132010	844424930131988	{"route": "NLU -> DFW", "duration": 2.75}
1125899906843181	844424930131998	844424930131994	{"route": "AMS -> ORD", "duration": 9.42}
1125899906843108	844424930132010	844424930131980	{"route": "NLU -> LAX", "duration": 3.92}
1125899906843110	844424930132022	844424930132008	{"route": "DMM -> SAW", "duration": 4.36}
1125899906843148	844424930131974	844424930131970	{"route": "FRA -> ATL", "duration": 10.5}
1125899906843160	844424930131971	844424930131978	{"route": "CLT -> MUC", "duration": 8.42}
1125899906843098	844424930131992	844424930131975	{"route": "MEX -> EWR", "duration": 4.772344322344322}
1125899906843178	844424930131981	844424930131985	{"route": "LAS -> MIA", "duration": 4.716431623931624}
1125899906843173	844424930131983	844424930131978	{"route": "DEN -> MUC", "duration": 9.65785046728972}
1125899906843188	844424930132009	844424930131989	{"route": "PAE -> SFO", "duration": 2.2039240506329114}
1125899906843136	844424930131981	844424930131999	{"route": "LAS -> ONT", "duration": 1.1335678391959798}
1125899906843096	844424930131975	844424930131990	{"route": "EWR -> BOG", "duration": 5.83}
1125899906843068	844424930131969	844424930131994	{"route": "GRU -> ORD", "duration": 10.67}
1125899906843126	844424930131975	844424930131986	{"route": "EWR -> MAD", "duration": 7.42}
1125899906843176	844424930131983	844424930131974	{"route": "DEN -> FRA", "duration": 9.617692307692307}
1125899906843119	844424930131969	844424930131975	{"route": "GRU -> EWR", "duration": 9.83}
1125899906843169	844424930131978	844424930132018	{"route": "MUC -> CPT", "duration": 11.25}
1125899906843088	844424930131978	844424930131983	{"route": "MUC -> DEN", "duration": 10.75}
1125899906843152	844424930131989	844424930131974	{"route": "SFO -> FRA", "duration": 10.980717703349283}
1125899906843150	844424930132012	844424930131974	{"route": "MRU -> FRA", "duration": 12}
1125899906843142	844424930131977	844424930131980	{"route": "LHR -> LAX", "duration": 11.33}
1125899906843154	844424930131969	844424930131974	{"route": "GRU -> FRA", "duration": 11.5}
1125899906843063	844424930131978	844424930131972	{"route": "MUC -> JFK", "duration": 8.83}
1125899906843147	844424930131975	844424930132002	{"route": "EWR -> DUB", "duration": 6.736111111111111}
1125899906843167	844424930131978	844424930131985	{"route": "MUC -> MIA", "duration": 11.08}
1125899906843065	844424930131974	844424930131989	{"route": "FRA -> SFO", "duration": 11.602809523809524}
1125899906843070	844424930131996	844424930131976	{"route": "OSL -> VIE", "duration": 2.33}
1125899906843165	844424930131978	844424930131971	{"route": "MUC -> CLT", "duration": 10}
1125899906843101	844424930131990	844424930131994	{"route": "BOG -> ORD", "duration": 6.25}
1125899906843140	844424930131989	844424930131973	{"route": "SFO -> MCO", "duration": 5.356641221374046}
1125899906843074	844424930132011	844424930131974	{"route": "MAN -> FRA", "duration": 1.75}
1125899906843158	844424930131976	844424930132011	{"route": "VIE -> MAN", "duration": 2.58}
1125899906843106	844424930132005	844424930131987	{"route": "LIS -> ZRH", "duration": 2.8015841584158414}
1125899906843149	844424930131978	844424930132001	{"route": "MUC -> FCO", "duration": 1.5}
1125899906843075	844424930131974	844424930131997	{"route": "FRA -> ARN", "duration": 2.17}
1125899906843155	844424930132001	844424930131978	{"route": "FCO -> MUC", "duration": 1.58}
1125899906843162	844424930131998	844424930131987	{"route": "AMS -> ZRH", "duration": 1.4702608695652175}
1125899906843141	844424930131978	844424930131993	{"route": "MUC -> CDG", "duration": 1.67}
1125899906843118	844424930131978	844424930131969	{"route": "MUC -> GRU", "duration": 12.5}
1125899906843185	844424930131978	844424930132005	{"route": "MUC -> LIS", "duration": 3.33}
1125899906843124	844424930131982	844424930131976	{"route": "ATH -> VIE", "duration": 2.3157943925233644}
1125899906843104	844424930131987	844424930131986	{"route": "ZRH -> MAD", "duration": 2.42}
1125899906843182	844424930131978	844424930131976	{"route": "MUC -> VIE", "duration": 1.053011583011583}
1125899906843087	844424930131997	844424930131974	{"route": "ARN -> FRA", "duration": 2.25}
1125899906843067	844424930132005	844424930131978	{"route": "LIS -> MUC", "duration": 3.181002331002331}
1125899906843153	844424930131987	844424930132016	{"route": "ZRH -> WAW", "duration": 1.8963478260869564}
1125899906843082	844424930131998	844424930131978	{"route": "AMS -> MUC", "duration": 1.33}
1125899906843076	844424930131987	844424930131997	{"route": "ZRH -> ARN", "duration": 2.449275362318841}
1125899906843123	844424930132016	844424930131976	{"route": "WAW -> VIE", "duration": 1.3317006802721087}
1125899906843128	844424930132002	844424930131975	{"route": "DUB -> EWR", "duration": 7.816263736263736}
1125899906843072	844424930132021	844424930131976	{"route": "NCE -> VIE", "duration": 1.67}
1125899906843085	844424930132016	844424930131978	{"route": "WAW -> MUC", "duration": 1.6971515151515153}
1125899906843171	844424930131993	844424930131976	{"route": "CDG -> VIE", "duration": 1.92}
1125899906843079	844424930131993	844424930131994	{"route": "CDG -> ORD", "duration": 9.17}
1125899906843100	844424930131984	844424930131987	{"route": "DXB -> ZRH", "duration": 7.25}
1125899906843111	844424930132003	844424930131978	{"route": "PVG -> MUC", "duration": 12.949821428571429}
1125899906842783	844424930132003	844424930132006	{"route": "PVG -> BKK", "duration": 4.910700934579439}
1125899906843186	844424930132006	844424930131987	{"route": "BKK -> ZRH", "duration": 12.25}
1125899906843166	844424930132003	844424930131974	{"route": "PVG -> FRA", "duration": 13.286927710843374}
1125899906843130	844424930132022	844424930131984	{"route": "DMM -> DXB", "duration": 1.415086782376502}
1125899906843097	844424930132017	844424930132022	{"route": "IST -> DMM", "duration": 4}
1125899906843177	844424930132008	844424930132022	{"route": "SAW -> DMM", "duration": 4.0375}
1125899906843093	844424930132008	844424930131995	{"route": "SAW -> CMN", "duration": 5.08}
1125899906843146	844424930132006	844424930131984	{"route": "BKK -> DXB", "duration": 6.932}
1125899906843180	844424930132013	844424930131980	{"route": "HND -> LAX", "duration": 10}
1125899906843133	844424930131988	844424930131969	{"route": "DFW -> GRU", "duration": 10.020520833333332}
1125899906843139	844424930131984	844424930132022	{"route": "DXB -> DMM", "duration": 1.529479305740988}
1125899906843069	844424930132006	844424930132023	{"route": "BKK -> PEK", "duration": 4.6018067226890755}
1125899906843138	844424930131973	844424930131969	{"route": "MCO -> GRU", "duration": 8.591933701657458}
1125899906843078	844424930131991	844424930131974	{"route": "CAI -> FRA", "duration": 4.605466666666667}
1125899906843163	844424930132018	844424930131974	{"route": "CPT -> FRA", "duration": 11.92}
1125899906843095	844424930131991	844424930131978	{"route": "CAI -> MUC", "duration": 4.08}
1125899906843134	844424930131990	844424930132010	{"route": "BOG -> NLU", "duration": 4.83}
1125899906843183	844424930131992	844424930131973	{"route": "MEX -> MCO", "duration": 3.2175084175084177}
1125899906843094	844424930131970	844424930131969	{"route": "ATL -> GRU", "duration": 9.489555555555556}
1125899906843115	844424930131983	844424930131999	{"route": "DEN -> ONT", "duration": 2.455137614678899}
1125899906843189	844424930131988	844424930131972	{"route": "DFW -> JFK", "duration": 3.5187826086956524}
1125899906843122	844424930131999	844424930131983	{"route": "ONT -> DEN", "duration": 2.4204117647058823}
1125899906843164	844424930131999	844424930131979	{"route": "ONT -> SEA", "duration": 2.9366588235294118}
1125899906843073	844424930131979	844424930131975	{"route": "SEA -> EWR", "duration": 5.601017369727047}
1125899906843145	844424930131983	844424930131975	{"route": "DEN -> EWR", "duration": 3.693448275862069}
1125899906843159	844424930131972	844424930131992	{"route": "JFK -> MEX", "duration": 5.757452339688042}
1125899906843084	844424930132019	844424930131991	{"route": "SSH -> CAI", "duration": 1.446102564102564}
1125899906843083	844424930131972	844424930131994	{"route": "JFK -> ORD", "duration": 2.898885542168675}
1125899906843179	844424930131985	844424930131981	{"route": "MIA -> LAS", "duration": 5.68234309623431}
1125899906843109	844424930131995	844424930131974	{"route": "CMN -> FRA", "duration": 3.58}
1125899906843099	844424930131989	844424930132009	{"route": "SFO -> PAE", "duration": 2.255128205128205}
1125899906843112	844424930131973	844424930131979	{"route": "MCO -> SEA", "duration": 6.616209850107066}
1125899906843102	844424930131992	844424930131988	{"route": "MEX -> DFW", "duration": 2.7332851985559565}
1125899906843113	844424930131972	844424930131971	{"route": "JFK -> CLT", "duration": 2.198470012239902}
1125899906843057	844424930131985	844424930131973	{"route": "MIA -> MCO", "duration": 2.782603305785124}
1125899906843091	844424930131974	844424930132017	{"route": "FRA -> IST", "duration": 3.1270327552986514}
1125899906843120	844424930131979	844424930131972	{"route": "SEA -> JFK", "duration": 5.389072164948454}
1125899906843129	844424930131969	844424930131985	{"route": "GRU -> MIA", "duration": 8.425102040816327}
1125899906843086	844424930131979	844424930131973	{"route": "SEA -> MCO", "duration": 5.724784394250514}
1125899906843116	844424930132016	844424930131974	{"route": "WAW -> FRA", "duration": 1.9694285714285713}
1125899906843184	844424930131971	844424930131983	{"route": "CLT -> DEN", "duration": 3.826490963855422}
1125899906843137	844424930131975	844424930131983	{"route": "EWR -> DEN", "duration": 4.450465116279069}
1125899906843058	844424930131987	844424930131976	{"route": "ZRH -> VIE", "duration": 1.34335734870317}
1125899906843170	844424930131989	844424930131970	{"route": "SFO -> ATL", "duration": 4.872038834951456}
1125899906843175	844424930132004	844424930131978	{"route": "BER -> MUC", "duration": 1.17}
1125899906843080	844424930131985	844424930131971	{"route": "MIA -> CLT", "duration": 2.2603158933859824}
1125899906843105	844424930131975	844424930131971	{"route": "EWR -> CLT", "duration": 2.121196120689655}
1125899906843117	844424930131975	844424930131989	{"route": "EWR -> SFO", "duration": 6.42720156555773}
1125899906843161	844424930131971	844424930131994	{"route": "CLT -> ORD", "duration": 2.224351005484461}
1125899906843114	844424930131978	844424930132004	{"route": "MUC -> BER", "duration": 1.17}
1125899906843060	844424930132006	844424930132003	{"route": "BKK -> PVG", "duration": 4.34013013013013}
1125899906843127	844424930131988	844424930131989	{"route": "DFW -> SFO", "duration": 4.129088176352705}
1125899906843081	844424930131975	844424930131980	{"route": "EWR -> LAX", "duration": 6.227320143884892}
1125899906843144	844424930131970	844424930131981	{"route": "ATL -> LAS", "duration": 4.610200573065903}
1125899906843132	844424930131983	844424930131994	{"route": "DEN -> ORD", "duration": 2.566113074204947}
1125899906843151	844424930131979	844424930131983	{"route": "SEA -> DEN", "duration": 2.7448154981549817}
1125899906843125	844424930131975	844424930131985	{"route": "EWR -> MIA", "duration": 3.2838685524126454}
1125899906843064	844424930131979	844424930131981	{"route": "SEA -> LAS", "duration": 2.776547987616099}
1125899906843156	844424930131994	844424930131985	{"route": "ORD -> MIA", "duration": 3.2895093062605754}
1125899906843172	844424930131980	844424930131970	{"route": "LAX -> ATL", "duration": 4.40810888252149}
1125899906843090	844424930131981	844424930131979	{"route": "LAS -> SEA", "duration": 2.9859723289777094}
1125899906843107	844424930131973	844424930131994	{"route": "MCO -> ORD", "duration": 3.1348711554447215}
1125899906843174	844424930131989	844424930131980	{"route": "SFO -> LAX", "duration": 1.540037037037037}
1125899906843092	844424930131975	844424930131994	{"route": "EWR -> ORD", "duration": 2.673146944083225}
1125899906842751	844424930131988	844424930131994	{"route": "DFW -> ORD", "duration": 2.431909898477157}
1125899906843066	844424930131994	844424930131988	{"route": "ORD -> DFW", "duration": 2.7367238095238093}
1125899906843135	844424930131994	844424930131975	{"route": "ORD -> EWR", "duration": 2.247715019255456}
1125899906843089	844424930131972	844424930131989	{"route": "JFK -> SFO", "duration": 6.726237373737374}
1125899906843168	844424930131989	844424930131972	{"route": "SFO -> JFK", "duration": 5.571222008957133}
1125899906843206	844424930131969	844424930131988	{"route": "GRU -> DFW", "duration": 10.48}
1125899906843192	844424930132028	844424930131970	{"route": "DAL -> ATL", "duration": 2.0116385542168675}
1125899906843218	844424930131969	844424930131992	{"route": "GRU -> MEX", "duration": 9.306842105263158}
1125899906842797	844424930132006	844424930132013	{"route": "BKK -> HND", "duration": 5.659864864864865}
1125899906843194	844424930132017	844424930132019	{"route": "IST -> SSH", "duration": 2.7085185185185185}
1125899906843190	844424930132014	844424930131974	{"route": "DEL -> FRA", "duration": 9.157142857142857}
1125899906843210	844424930132026	844424930131974	{"route": "ALG -> FRA", "duration": 2.75}
1125899906843205	844424930131987	844424930132005	{"route": "ZRH -> LIS", "duration": 2.99}
1125899906843103	844424930131990	844424930131988	{"route": "BOG -> DFW", "duration": 5.912333333333334}
1125899906843121	844424930131978	844424930131986	{"route": "MUC -> MAD", "duration": 2.75}
1125899906843131	844424930132001	844424930131975	{"route": "FCO -> EWR", "duration": 10.25}
1125899906843004	844424930132006	844424930132014	{"route": "BKK -> DEL", "duration": 4.604840182648402}
1125899906842807	844424930131989	844424930131979	{"route": "SFO -> SEA", "duration": 2.3296702599873176}
1125899906842757	844424930131988	844424930131983	{"route": "DFW -> DEN", "duration": 2.2206116838487975}
1125899906842831	844424930131973	844424930131970	{"route": "MCO -> ATL", "duration": 1.6563529411764706}
1125899906842781	844424930131980	844424930131972	{"route": "LAX -> JFK", "duration": 5.45892274211099}
1125899906842625	844424930131969	844424930131970	{"route": "GRU -> ATL", "duration": 9.932359550561797}
1125899906842966	844424930131972	844424930131983	{"route": "JFK -> DEN", "duration": 4.72168449197861}
1125899906842840	844424930131970	844424930131985	{"route": "ATL -> MIA", "duration": 1.9974302788844622}
1125899906842786	844424930131983	844424930131979	{"route": "DEN -> SEA", "duration": 3.3776850258175557}
1125899906842858	844424930131973	844424930131971	{"route": "MCO -> CLT", "duration": 1.8391206225680934}
1125899906843048	844424930132029	844424930131974	{"route": "QPP -> FRA", "duration": 4.452125603864734}
1125899906843023	844424930132004	844424930131974	{"route": "BER -> FRA", "duration": 1.25}
1125899906842958	844424930131981	844424930131988	{"route": "LAS -> DFW", "duration": 2.7529475833900614}
1125899906842986	844424930131981	844424930132009	{"route": "LAS -> PAE", "duration": 2.8592857142857144}
1125899906843037	844424930131994	844424930131970	{"route": "ORD -> ATL", "duration": 2.0783629343629344}
1125899906842832	844424930131994	844424930131981	{"route": "ORD -> LAS", "duration": 4.443857388316151}
1125899906843009	844424930131984	844424930132006	{"route": "DXB -> BKK", "duration": 6.084}
1125899906842997	844424930132017	844424930131974	{"route": "IST -> FRA", "duration": 3.3772413793103446}
1125899906842822	844424930131980	844424930131979	{"route": "LAX -> SEA", "duration": 3.149793966151582}
1125899906842791	844424930131973	844424930131975	{"route": "MCO -> EWR", "duration": 2.762640134529148}
1125899906842888	844424930131988	844424930131981	{"route": "DFW -> LAS", "duration": 3.0948833922261483}
1125899906842908	844424930131980	844424930131975	{"route": "LAX -> EWR", "duration": 5.269038290293856}
1125899906843047	844424930131970	844424930132028	{"route": "ATL -> DAL", "duration": 2.3154452926208653}
1125899906842818	844424930131970	844424930131988	{"route": "ATL -> DFW", "duration": 2.6835543018335684}
1125899906842839	844424930131987	844424930131975	{"route": "ZRH -> EWR", "duration": 9.25}
1125899906842755	844424930131987	844424930132003	{"route": "ZRH -> PVG", "duration": 12.25}
1125899906842745	844424930131987	844424930132014	{"route": "ZRH -> DEL", "duration": 7.75}
1125899906842842	844424930131987	844424930132006	{"route": "ZRH -> BKK", "duration": 10.67}
1125899906843157	844424930131985	844424930131983	{"route": "MIA -> DEN", "duration": 4.80978947368421}
1125899906843187	844424930131973	844424930131983	{"route": "MCO -> DEN", "duration": 4.514874835309618}
1125899906843059	844424930131975	844424930131988	{"route": "EWR -> DFW", "duration": 4.268974358974359}
1125899906843143	844424930131983	844424930131989	{"route": "DEN -> SFO", "duration": 2.854280408542247}
1125899906843199	844424930131994	844424930131990	{"route": "ORD -> BOG", "duration": 5.83}
1125899906843215	844424930131994	844424930131987	{"route": "ORD -> ZRH", "duration": 8.67}
1125899906843214	844424930131985	844424930131975	{"route": "MIA -> EWR", "duration": 3.192825552825553}
1125899906842741	844424930131988	844424930131999	{"route": "DFW -> ONT", "duration": 3.3835263157894735}
1125899906842913	844424930131970	844424930131983	{"route": "ATL -> DEN", "duration": 3.4861406844106466}
1125899906843196	844424930132017	844424930132003	{"route": "IST -> PVG", "duration": 10.375}
1125899906843197	844424930132021	844424930132004	{"route": "NCE -> BER", "duration": 2}
1125899906843198	844424930132010	844424930131985	{"route": "NLU -> MIA", "duration": 3.08}
1125899906842904	844424930131988	844424930131980	{"route": "DFW -> LAX", "duration": 3.507924791086351}
1125899906843221	844424930131997	844424930131978	{"route": "ARN -> MUC", "duration": 2.25}
1125899906842948	844424930131985	844424930131990	{"route": "MIA -> BOG", "duration": 3.70638928067701}
1125899906842815	844424930131980	844424930131981	{"route": "LAX -> LAS", "duration": 1.259891435464415}
1125899906843195	844424930131980	844424930131978	{"route": "LAX -> MUC", "duration": 11.215581395348837}
1125899906843224	844424930131980	844424930131977	{"route": "LAX -> LHR", "duration": 10.5}
1125899906843213	844424930131976	844424930131978	{"route": "VIE -> MUC", "duration": 1.0011196911196911}
1125899906843220	844424930131993	844424930131989	{"route": "CDG -> SFO", "duration": 11.42}
1125899906843191	844424930131988	844424930131985	{"route": "DFW -> MIA", "duration": 2.894580216126351}
1125899906843227	844424930131970	844424930131980	{"route": "ATL -> LAX", "duration": 5.1269184741959615}
1125899906843209	844424930131976	844424930131977	{"route": "VIE -> LHR", "duration": 2.4456521739130435}
1125899906843201	844424930131987	844424930131980	{"route": "ZRH -> LAX", "duration": 12.33}
1125899906843223	844424930131971	844424930131973	{"route": "CLT -> MCO", "duration": 1.7783049535603714}
1125899906842865	844424930131983	844424930131981	{"route": "DEN -> LAS", "duration": 2.113772511848341}
1125899906843216	844424930131992	844424930131994	{"route": "MEX -> ORD", "duration": 4.2091666666666665}
1125899906843219	844424930131979	844424930131970	{"route": "SEA -> ATL", "duration": 4.805320056899005}
1125899906843208	844424930131979	844424930132028	{"route": "SEA -> DAL", "duration": 3.943076923076923}
1125899906843222	844424930131979	844424930131994	{"route": "SEA -> ORD", "duration": 4.424413793103448}
1125899906843225	844424930131979	844424930131999	{"route": "SEA -> ONT", "duration": 2.63879679144385}
1125899906842753	844424930131987	844424930131972	{"route": "ZRH -> JFK", "duration": 9.335464480874316}
1125899906842771	844424930131987	844424930132019	{"route": "ZRH -> SSH", "duration": 5.195925925925926}
1125899906842804	844424930131987	844424930132001	{"route": "ZRH -> FCO", "duration": 1.559746835443038}
1125899906842734	844424930131987	844424930132011	{"route": "ZRH -> MAN", "duration": 2.0929556650246304}
1125899906842800	844424930132002	844424930131978	{"route": "DUB -> MUC", "duration": 2.25}
1125899906843211	844424930131974	844424930131978	{"route": "FRA -> MUC", "duration": 0.92}
1125899906843203	844424930131994	844424930131989	{"route": "ORD -> SFO", "duration": 4.876177285318559}
1125899906843207	844424930131974	844424930131996	{"route": "FRA -> OSL", "duration": 2.08}
1125899906843226	844424930131978	844424930131991	{"route": "MUC -> CAI", "duration": 3.70013698630137}
1125899906843200	844424930131978	844424930131989	{"route": "MUC -> SFO", "duration": 11.960718562874252}
1125899906843212	844424930131978	844424930131996	{"route": "MUC -> OSL", "duration": 2.33}
1125899906843217	844424930132004	844424930131984	{"route": "BER -> DXB", "duration": 6.33}
1125899906843193	844424930131998	844424930131976	{"route": "AMS -> VIE", "duration": 1.83}
1125899906843202	844424930131970	844424930131973	{"route": "ATL -> MCO", "duration": 1.534153577661431}
1125899906843204	844424930132009	844424930131980	{"route": "PAE -> LAX", "duration": 2.823030303030303}
1125899906842933	844424930131992	844424930131974	{"route": "MEX -> FRA", "duration": 10.67}
1125899906843003	844424930131990	844424930131974	{"route": "BOG -> FRA", "duration": 10.42}
1125899906843017	844424930131979	844424930131974	{"route": "SEA -> FRA", "duration": 10.17}
1125899906842967	844424930131994	844424930131999	{"route": "ORD -> ONT", "duration": 8.76}
1125899906842952	844424930131992	844424930131979	{"route": "MEX -> SEA", "duration": 6.0553333333333335}
1125899906842980	844424930131992	844424930131981	{"route": "MEX -> LAS", "duration": 4.1324302788844625}
1125899906843010	844424930132022	844424930132017	{"route": "DMM -> IST", "duration": 4.5}
1125899906842975	844424930131992	844424930132017	{"route": "MEX -> IST", "duration": 15.911794871794871}
1125899906843051	844424930132010	844424930131983	{"route": "NLU -> DEN", "duration": 3.58}
1125899906842942	844424930132018	844424930131987	{"route": "CPT -> ZRH", "duration": 11.5}
1125899906842911	844424930132017	844424930131995	{"route": "IST -> CMN", "duration": 5}
1125899906843006	844424930131975	844424930131993	{"route": "EWR -> CDG", "duration": 7.2781756756756755}
1125899906843011	844424930131980	844424930131969	{"route": "LAX -> GRU", "duration": 11.83}
1125899906842974	844424930131980	844424930132013	{"route": "LAX -> HND", "duration": 12.293181818181818}
1125899906842954	844424930131972	844424930131987	{"route": "JFK -> ZRH", "duration": 7.709781420765028}
1125899906842921	844424930132006	844424930131978	{"route": "BKK -> MUC", "duration": 12.33}
1125899906842981	844424930132023	844424930131978	{"route": "PEK -> MUC", "duration": 11.224421768707483}
1125899906842976	844424930132013	844424930131979	{"route": "HND -> SEA", "duration": 9.205403726708074}
1125899906843052	844424930131981	844424930131973	{"route": "LAS -> MCO", "duration": 5.701845493562232}
1125899906842949	844424930131975	844424930131979	{"route": "EWR -> SEA", "duration": 6.963738095238095}
1125899906842995	844424930131974	844424930132007	{"route": "FRA -> AGY", "duration": 2.9553333333333334}
1125899906842961	844424930131999	844424930131981	{"route": "ONT -> LAS", "duration": 1.1898666666666666}
1125899906842684	844424930131976	844424930132006	{"route": "VIE -> BKK", "duration": 10.08}
1125899906842686	844424930131976	844424930131975	{"route": "VIE -> EWR", "duration": 9.75}
1125899906842710	844424930131998	844424930131974	{"route": "AMS -> FRA", "duration": 1.17}
1125899906842646	844424930131993	844424930131978	{"route": "CDG -> MUC", "duration": 1.42}
1125899906842691	844424930131977	844424930131994	{"route": "LHR -> ORD", "duration": 9.42}
1125899906842690	844424930131987	844424930131991	{"route": "ZRH -> CAI", "duration": 4.001910112359551}
1125899906842707	844424930131970	844424930131990	{"route": "ATL -> BOG", "duration": 4.673598820058997}
1125899906842627	844424930131973	844424930131974	{"route": "MCO -> FRA", "duration": 9.08}
1125899906842703	844424930131986	844424930131974	{"route": "MAD -> FRA", "duration": 2.58}
1125899906842672	844424930131988	844424930131971	{"route": "DFW -> CLT", "duration": 2.53982276119403}
1125899906842649	844424930131987	844424930131993	{"route": "ZRH -> CDG", "duration": 1.3636827195467423}
1125899906842637	844424930131986	844424930131987	{"route": "MAD -> ZRH", "duration": 2.2885185185185186}
1125899906842659	844424930132001	844424930131987	{"route": "FCO -> ZRH", "duration": 1.6115189873417721}
1125899906842695	844424930132004	844424930131987	{"route": "BER -> ZRH", "duration": 1.4755414012738854}
\.


--
-- Data for Name: _ag_label_edge; Type: TABLE DATA; Schema: flight_routes; Owner: dst_graph_designer
--

COPY flight_routes._ag_label_edge (id, start_id, end_id, properties) FROM stdin;
\.


--
-- Data for Name: _ag_label_vertex; Type: TABLE DATA; Schema: flight_routes; Owner: dst_graph_designer
--

COPY flight_routes._ag_label_vertex (id, properties) FROM stdin;
\.


--
-- Data for Name: scheduled_routes; Type: TABLE DATA; Schema: l3; Owner: dst_graph_designer
--

COPY l3.scheduled_routes (departure_airport_code, arrival_airport_code, avg_flight_duration_hours) FROM stdin;
\.


--
-- Data for Name: scheduled_routes; Type: TABLE DATA; Schema: public; Owner: dst_graph_designer
--

COPY public.scheduled_routes (departure_airport_code, arrival_airport_code, avg_flight_duration_hours) FROM stdin;
ZRH	ORD	10.0800000000000000
MUC	DXB	5.8300000000000000
LHR	MUC	1.8300000000000000
ZRH	MUC	0.93352941176470588235
LAX	DEN	2.4549400141143260
PAE	LAS	2.5426490066225166
ATL	MEX	3.8900873362445415
HND	FRA	14.6740298507462687
DEL	MUC	8.9200000000000000
GRU	LAX	12.3300000000000000
SEA	CLT	4.9950988142292490
MIA	GRU	8.3235559006211180
CLT	ATL	1.3943222308288149
SFO	LAS	1.8370466717674063
ORD	NLU	4.2500000000000000
NLU	ORD	4.0800000000000000
DFW	CLT	2.5398227611940299
FRA	SAW	3.1175766871165644
SFO	CLT	5.0776826196473552
LAS	LAX	1.3313852813852814
DEN	MEX	3.9513432835820896
SEA	MEX	5.5520879120879121
EWR	GRU	9.5000000000000000
MEX	CLT	3.7551111111111111
EWR	AMS	7.1700000000000000
VIE	PVG	11.0800000000000000
FCO	ORD	10.3300000000000000
LIS	MAD	1.4111363636363636
EWR	MUC	7.7134722222222222
MCO	NLU	3.4200000000000000
ONT	ORD	6.1715789473684211
DEN	NLU	3.5800000000000000
LAX	NLU	3.6700000000000000
EWR	FRA	7.4604500000000000
EWR	MEX	5.6596336996336996
LAS	FRA	11.0000000000000000
MIA	NLU	3.4200000000000000
ORD	FCO	8.9200000000000000
NLU	MCO	3.0800000000000000
ORD	VIE	8.7500000000000000
LAX	FRA	10.9200000000000000
JFK	MUC	7.5000000000000000
CLT	ONT	5.2092307692307692
AMS	EWR	8.4200000000000000
MUC	PEK	9.9157931034482759
MUC	DUB	2.5800000000000000
MUC	LAX	12.2151764705882353
MUC	MAN	2.2500000000000000
MUC	SEA	10.6700000000000000
VIE	ATH	2.1540186915887850
ARN	ZRH	2.4440579710144928
ATL	FRA	8.7500000000000000
MIA	ZRH	9.0779166666666667
CLT	MEX	4.4419780219780220
MRU	VIE	10.8300000000000000
MRU	ZRH	12.3066666666666667
CLT	SEA	5.9299209486166008
LAX	CLT	4.8182525697503671
MCO	AVT	3.0738645418326693
ZRH	BER	1.4722842639593909
DFW	EWR	3.3736060279870829
EWR	LAS	5.7372078720787208
MCO	EKW	3.4790393013100437
CLT	EWR	1.9078017241379310
SFO	ORD	4.3521973929236499
SFO	DEN	2.6737804878048780
VIE	FRA	1.4924826904055391
FRA	BER	1.1700000000000000
ORD	CLT	2.0695652173913043
LAS	ATL	3.9378449905482042
ORD	SEA	4.8413326446280992
MIA	ORD	3.6398909395973154
SEA	DFW	3.9503293172690763
MCO	DFW	3.1469192751235585
MCO	JFK	2.6905689789555729
DFW	NLU	2.6700000000000000
MEX	FRA	10.6700000000000000
MEX	MUC	10.7500000000000000
MEX	DEN	3.9518045112781955
BOG	FRA	10.4200000000000000
EWR	ATH	9.5000000000000000
SFO	CDG	10.7500000000000000
BER	NCE	2.0000000000000000
ORD	ONT	8.7600000000000000
MEX	SEA	6.0553333333333333
MEX	LAS	4.1324302788844622
EWR	ZRH	7.5800000000000000
SFO	MUC	11.1272455089820359
DMM	IST	4.5000000000000000
MEX	IST	15.9117948717948718
NLU	DEN	3.5800000000000000
CPT	ZRH	11.5000000000000000
IST	CMN	5.0000000000000000
ALG	CMN	2.0000000000000000
MIA	MUC	9.0000000000000000
SSH	ZRH	4.8766666666666667
NBO	FRA	9.0800000000000000
ORD	MUC	8.4587878787878788
EWR	CDG	7.2781756756756757
DAL	SEA	4.5068354430379747
JFK	FRA	7.6933846153846154
MIA	FRA	9.0000000000000000
LAX	HND	12.2931818181818182
JFK	ZRH	7.7097814207650273
LAS	MEX	3.8032015810276680
MUC	DEL	7.4200000000000000
FRA	EWR	8.7540500000000000
FRA	GRU	12.0000000000000000
FRA	MAD	2.7500000000000000
MUC	HND	12.5078160919540230
MUC	MEX	13.0000000000000000
BER	EWR	9.3300000000000000
MUC	EWR	9.1040277777777778
LHR	SFO	11.1700000000000000
OSL	ZRH	2.5972093023255814
MUC	NCE	1.5000000000000000
BER	ARN	1.6966666666666667
PEK	MUC	11.2244217687074830
HND	SEA	9.2054037267080745
CPT	MUC	11.2500000000000000
ORD	AMS	8.4200000000000000
ORD	LHR	8.0800000000000000
ONT	ATL	4.1377777777777778
EWR	SEA	6.9637380952380952
FRA	FCO	1.8300000000000000
MEX	JFK	4.7557793345008757
FRA	AMS	1.2500000000000000
FRA	QPP	4.4180617495711835
MUC	LHR	2.0800000000000000
MIA	LAX	6.1904994192799071
MCO	LAX	6.0137158469945355
ONT	LAS	1.1898666666666667
MIA	DFW	3.5133389261744966
OSL	ARN	1.1348979591836735
DEL	HND	7.5000000000000000
NLU	DFW	2.7500000000000000
AMS	ORD	9.4200000000000000
NLU	LAX	3.9200000000000000
DMM	SAW	4.3600000000000000
FRA	ATL	10.5000000000000000
CLT	MUC	8.4200000000000000
MEX	EWR	4.7723443223443223
DEN	MUC	9.6578504672897196
PAE	SFO	2.2039240506329114
GRU	ORD	10.6700000000000000
DEN	FRA	9.6176923076923077
GRU	EWR	9.8300000000000000
MUC	CPT	11.2500000000000000
MUC	DEN	10.7500000000000000
SFO	FRA	10.9807177033492823
MRU	FRA	12.0000000000000000
LHR	LAX	11.3300000000000000
GRU	FRA	11.5000000000000000
MUC	JFK	8.8300000000000000
MUC	MIA	11.0800000000000000
FRA	SFO	11.6028095238095238
OSL	VIE	2.3300000000000000
BOG	DFW	5.9123333333333333
MUC	CLT	10.0000000000000000
BOG	ORD	6.2500000000000000
MUC	MAD	2.7500000000000000
SFO	MCO	5.3566412213740458
LIS	ZRH	2.8015841584158416
FCO	EWR	10.2500000000000000
FRA	ARN	2.1700000000000000
MUC	GRU	12.5000000000000000
MUC	LIS	3.3300000000000000
MUC	VIE	1.0530115830115830
AMS	MUC	1.3300000000000000
SEA	FRA	10.1700000000000000
LHR	DEN	9.8300000000000000
DUB	EWR	7.8162637362637363
ATL	GRU	9.4895555555555556
DEN	ONT	2.4551376146788991
DFW	JFK	3.5187826086956522
ONT	DEN	2.4204117647058824
ONT	SEA	2.9366588235294118
SEA	EWR	5.6010173697270471
DEN	EWR	3.6934482758620690
JFK	MEX	5.7574523396880416
SSH	CAI	1.4461025641025641
JFK	ORD	2.8988855421686747
SFO	PAE	2.2551282051282051
MEX	DFW	2.7332851985559567
JFK	CLT	2.1984700122399021
MIA	MCO	2.7826033057851240
FRA	IST	3.1270327552986513
SEA	JFK	5.3890721649484536
WAW	FRA	1.9694285714285714
ZRH	VIE	1.3433573487031700
ORD	SFO	4.8761772853185596
ORD	BOG	5.8300000000000000
ORD	ZRH	8.6700000000000000
MIA	EWR	3.1928255528255528
DFW	ONT	3.3835263157894737
ATL	DEN	3.4861406844106464
IST	PVG	10.3750000000000000
NCE	BER	2.0000000000000000
NLU	MIA	3.0800000000000000
DFW	LAX	3.5079247910863510
ZRH	LIS	2.9900000000000000
BKK	DEL	4.6048401826484018
SFO	SEA	2.3296702599873177
DFW	DEN	2.2206116838487973
MCO	ATL	1.6563529411764706
LAX	JFK	5.4589227421109902
GRU	ATL	9.9323595505617978
JFK	DEN	4.7216844919786096
ATL	MIA	1.9974302788844622
DEN	SEA	3.3776850258175559
QPP	FRA	4.4521256038647343
BER	FRA	1.2500000000000000
LAS	DFW	2.7529475833900613
ORD	ATL	2.0783629343629344
DXB	BKK	6.0840000000000000
IST	FRA	3.3772413793103448
LAX	SEA	3.1497939661515820
MCO	EWR	2.7626401345291480
DFW	LAS	3.0948833922261484
ATL	DAL	2.3154452926208651
ATL	DFW	2.6835543018335684
ORD	MCO	2.9314285714285714
ATL	CLT	1.2756091954022989
JFK	LAX	6.3792651061513337
CAI	VIE	3.7500000000000000
LAX	ORD	4.1480859128237524
EWR	BER	8.0800000000000000
MCO	MIA	2.7102674418604651
EWR	VIE	8.1007692307692308
MUC	BKK	10.5000000000000000
MUC	ORD	9.7885365853658537
DEN	DFW	2.0707340720221607
MAN	VIE	2.4200000000000000
LAX	SFO	1.5081373172282263
CMN	IST	4.5688596491228070
MAN	FRA	1.7500000000000000
VIE	MAN	2.5800000000000000
MUC	FCO	1.5000000000000000
FCO	MUC	1.5800000000000000
AMS	ZRH	1.4702608695652174
MUC	CDG	1.6700000000000000
ATH	VIE	2.3157943925233645
ZRH	MAD	2.4200000000000000
ARN	FRA	2.2500000000000000
LIS	MUC	3.1810023310023310
ZRH	WAW	1.8963478260869565
ZRH	ARN	2.4492753623188406
WAW	VIE	1.3317006802721088
NCE	VIE	1.6700000000000000
WAW	MUC	1.6971515151515152
CDG	VIE	1.9200000000000000
CDG	ORD	9.1700000000000000
DXB	ZRH	7.2500000000000000
PVG	MUC	12.9498214285714286
PVG	BKK	4.9107009345794393
BKK	ZRH	12.2500000000000000
PVG	FRA	13.2869277108433735
DMM	DXB	1.4150867823765020
IST	DMM	4.0000000000000000
SAW	DMM	4.0375000000000000
SAW	CMN	5.0800000000000000
BKK	DXB	6.9320000000000000
HND	LAX	10.0000000000000000
DFW	GRU	10.0205208333333333
DXB	DMM	1.5294793057409880
BKK	PEK	4.6018067226890756
MCO	GRU	8.5919337016574586
CAI	FRA	4.6054666666666667
CPT	FRA	11.9200000000000000
CAI	MUC	4.0800000000000000
BOG	NLU	4.8300000000000000
CMN	FRA	3.5800000000000000
VIE	BKK	10.0800000000000000
LAS	ORD	3.8196250000000000
VIE	ORD	10.1700000000000000
VIE	EWR	9.7500000000000000
CDG	MUC	1.4200000000000000
ATL	ORD	2.1616730917501928
CLT	LAS	5.0206394316163410
LAX	PAE	2.9669642857142857
ONT	DFW	2.9681663113006397
ATL	SEA	5.7477106741573034
MCO	MEX	3.9314141414141414
MEX	GRU	9.5758947368421053
BOG	MCO	4.2709883720930233
CDG	ZRH	1.3112464589235127
ATL	BOG	4.6735988200589971
MCO	BOG	3.9893798449612403
ATH	EWR	11.1700000000000000
DEN	JFK	3.7522794117647059
LHR	VIE	2.2326086956521739
MIA	JFK	3.0710708898944193
MCO	FRA	9.0800000000000000
EWR	ATL	2.5506363636363636
MAN	ZRH	1.9637438423645320
MUC	FRA	1.0800000000000000
BOG	MIA	3.9487801516195727
ORD	DEN	2.8322968197879859
DEN	ATL	2.9507809523809524
ZRH	LHR	1.8671428571428571
AGY	FRA	3.1956756756756757
MUC	AMS	1.6700000000000000
FRA	PVG	11.4692682926829268
MAD	FRA	2.5800000000000000
ZRH	CDG	1.3636827195467422
MAD	ZRH	2.2885185185185185
FCO	ZRH	1.6115189873417722
DEN	MCO	3.9404830287206266
JFK	MCO	3.0755913173652695
GRU	MIA	8.4251020408163265
MIA	DEN	4.8097894736842105
SEA	MCO	5.7247843942505133
CLT	DEN	3.8264909638554217
EWR	DEN	4.4504651162790698
SFO	ATL	4.8720388349514563
EWR	DFW	4.2689743589743590
BER	MUC	1.1700000000000000
MUC	BER	1.1700000000000000
BKK	PVG	4.3401301301301301
DFW	SFO	4.1290881763527054
EWR	LAX	6.2273201438848921
DEN	SFO	2.8542804085422470
ATL	LAS	4.6102005730659026
DEN	ORD	2.5661130742049470
SEA	DEN	2.7448154981549815
EWR	MIA	3.2838685524126456
SEA	LAS	2.7765479876160991
ORD	MIA	3.2895093062605753
LAX	ATL	4.4081088825214900
LAS	SEA	2.9859723289777095
MCO	ORD	3.1348711554447215
SFO	LAX	1.5400370370370370
EWR	ORD	2.6731469440832250
DFW	ORD	2.4319098984771574
ORD	DFW	2.7367238095238095
ORD	EWR	2.2477150192554557
JFK	SFO	6.7262373737373737
SFO	JFK	5.5712220089571337
GRU	DFW	10.4800000000000000
DAL	ATL	2.0116385542168675
GRU	MEX	9.3068421052631579
BKK	HND	5.6598648648648649
IST	SSH	2.7085185185185185
DEL	FRA	9.1571428571428571
ALG	FRA	2.7500000000000000
LAS	PAE	2.8592857142857143
LAX	EWR	5.2690382902938557
LAS	SFO	1.7617019607843137
ORD	CDG	8.0800000000000000
FRA	MIA	10.4200000000000000
JFK	BOG	5.8960000000000000
BOG	ATL	5.1461077844311377
AMS	FRA	1.1700000000000000
ORD	LAX	4.6387484276729560
FRA	LAS	11.7500000000000000
LHR	ORD	9.4200000000000000
DEN	LHR	9.0800000000000000
FRA	LIS	3.2201265822784810
MUC	PVG	11.4345945945945946
DFW	SEA	4.5017576243980738
DFW	BOG	5.3348913043478261
VIE	BER	1.2521649484536082
VIE	ARN	2.2500000000000000
LAS	JFK	5.0053936170212766
ZRH	CAI	4.0019101123595506
JFK	MIA	3.3296728624535316
DFW	ATL	2.2104571428571429
LAS	DEN	2.0038709677419355
ATL	JFK	2.2662425447316103
SAW	FRA	3.3775379939209726
SEA	LAX	2.9830579710144928
FRA	CMN	3.7500000000000000
SFO	ZRH	11.0800000000000000
EWR	FCO	8.5800000000000000
EWR	LIS	6.5800000000000000
GRU	MUC	11.5800000000000000
GRU	MCO	9.0000000000000000
FRA	CPT	11.6700000000000000
FRA	DMM	7.5800000000000000
BOG	EWR	6.0350909090909091
DFW	FRA	9.8300000000000000
FRA	MCO	10.7500000000000000
LAX	ZRH	11.0800000000000000
ZRH	SSH	5.1959259259259259
PVG	VIE	12.9200000000000000
IST	LOS	7.2500000000000000
DEL	ZRH	9.0800000000000000
CAI	ZRH	4.1700000000000000
MRU	NBO	4.2548484848484848
ORD	FRA	8.4362199312714777
ONT	SFO	1.5743820224719101
MIA	SEA	6.9291695501730104
JFK	DFW	4.2348801742919390
LAX	MEX	3.7379644588045234
SEA	MIA	6.0059090909090909
SFO	ONT	1.4939000000000000
MIA	SFO	6.7852473118279570
JFK	VIE	8.2500000000000000
JFK	SEA	6.4790847457627119
JFK	GRU	9.5742914979757085
MEX	ATL	3.4096909492273731
SFO	MEX	4.3925416666666667
MEX	LAX	4.3203921568627451
LAS	CLT	4.2483098591549296
MEX	MIA	3.2480910683012259
ONT	CLT	4.8865671641791045
ATL	SFO	5.4449566473988439
DEN	MIA	4.1113010590015129
NLU	BOG	4.5000000000000000
MAD	EWR	8.9200000000000000
VIE	OSL	2.3300000000000000
VIE	CAI	3.4200000000000000
LIS	EWR	8.1700000000000000
VIE	NCE	1.7500000000000000
VIE	MRU	10.2500000000000000
ZRH	DXB	6.1943478260869565
FRA	BOG	11.5000000000000000
FRA	DFW	11.3300000000000000
LAX	GRU	11.8300000000000000
FRA	LAX	11.6700000000000000
FCO	VIE	1.6595238095238095
ATH	ZRH	2.9072413793103448
ZRH	CPT	11.4592452830188679
ZRH	SFO	12.1700000000000000
VIE	AMS	1.9200000000000000
ZRH	MIA	10.7434117647058824
OSL	FRA	2.3300000000000000
ZRH	GRU	11.9646739130434783
VIE	WAW	1.2514285714285714
VIE	CDG	2.0800000000000000
ZRH	OSL	2.5000000000000000
CDG	EWR	8.5476000000000000
ZRH	ATH	2.6331034482758621
ZRH	BOG	11.9200000000000000
ZRH	AMS	1.6860000000000000
NCE	FRA	1.6700000000000000
DMM	FRA	8.5000000000000000
NCE	MUC	1.4200000000000000
NCE	ZRH	1.2458974358974359
DXB	FRA	7.2500000000000000
DXB	BER	7.0000000000000000
CDG	FRA	1.3300000000000000
PVG	DMK	4.7575182481751825
ATH	FRA	3.1816179775280899
BKK	VIE	11.5800000000000000
SAW	SSH	2.5800000000000000
PEK	FRA	10.5199095022624434
ATL	ONT	4.8405381165919283
ORD	MEX	4.6365360824742268
DFW	MEX	2.8475000000000000
LAS	MCO	5.7018454935622318
MCO	SFO	6.5020873786407767
MIA	MEX	3.8449122807017544
CLT	LAX	5.4967220543806647
MUC	ZRH	0.93546961325966850829
MUC	WAW	1.5683030303030303
LHR	ZRH	1.7963354037267081
VIE	ZRH	1.3844668587896254
LAX	MIA	4.9364719358533792
LAX	MCO	5.4727541827541828
FRA	MUC	0.92000000000000000000
FRA	OSL	2.0800000000000000
MUC	CAI	3.7001369863013699
MIA	BOG	3.7063892806770099
LAX	LAS	1.2598914354644150
LAX	MUC	11.2155813953488372
LAX	LHR	10.5000000000000000
CDG	SFO	11.4200000000000000
DFW	MIA	2.8945802161263508
ATL	LAX	5.1269184741959611
CLT	MCO	1.7783049535603715
DEN	LAS	2.1137725118483412
ZRH	EWR	9.2500000000000000
ZRH	JFK	9.3354644808743169
VIE	JFK	9.7500000000000000
FRA	DEN	10.5886524822695035
ZRH	PVG	12.2500000000000000
PVG	ZRH	14.3300000000000000
ZRH	DEL	7.7500000000000000
FRA	MRU	11.2500000000000000
FRA	MEX	12.3300000000000000
FRA	HND	13.0133962264150943
FRA	SEA	10.8300000000000000
FRA	CAI	4.1526457399103139
FRA	JFK	8.9764341085271318
FRA	NCE	1.5800000000000000
MAD	MUC	2.5800000000000000
ARN	BER	1.5800000000000000
ZRH	BKK	10.6700000000000000
MAN	MUC	1.9200000000000000
MUC	ARN	2.2500000000000000
MUC	ATH	2.4573614775725594
VIE	FCO	1.5824489795918367
WAW	ZRH	2.0850869565217391
ARN	OSL	1.0254814814814815
ATH	MUC	2.7126385224274406
FCO	FRA	2.0000000000000000
ZRH	FCO	1.5597468354430380
ZRH	MAN	2.0929556650246305
DUB	MUC	2.2500000000000000
ZRH	NCE	1.1969597069597070
DUB	ZRH	2.1700000000000000
DUB	FRA	2.0000000000000000
FRA	DUB	2.1700000000000000
DMK	PVG	4.0800000000000000
HND	MUC	14.6813636363636364
DEL	BKK	3.9745328719723183
CMN	SAW	4.7764566929133858
FRA	MAN	1.8300000000000000
FRA	CDG	1.2500000000000000
BER	VIE	1.2525773195876289
FRA	ORD	9.4952249134948097
GRU	JFK	9.9602263374485597
FRA	WAW	1.6998532494758910
FRA	ATH	2.7821818181818182
LIS	FRA	3.1329583333333333
MEX	BOG	4.5564315352697095
FRA	ZRH	0.95106685633001422475
ZRH	FRA	1.0916455696202532
FRA	LOS	6.5000000000000000
GRU	ZRH	11.2271428571428571
BOG	ZRH	12.9600000000000000
SFO	LHR	10.5800000000000000
FRA	DXB	6.4200000000000000
FRA	ALG	2.5800000000000000
FRA	DEL	7.8643352601156069
FRA	NBO	8.5000000000000000
BKK	MUC	12.3300000000000000
FRA	PEK	9.3869863013698630
CLT	SFO	5.8569712793733681
MEX	SFO	5.0126875000000000
SFO	MIA	5.5085219399538106
BOG	JFK	5.8480000000000000
EWR	LHR	7.2747916666666667
BOG	MEX	4.8725449515905947
LHR	EWR	8.5102060221870048
FRA	ZMU	3.4773594132029340
ZMU	FRA	3.4778381795195954
FRA	AGY	2.9553333333333333
SFO	EWR	5.4585909980430528
EKW	MCO	3.4636496350364964
CLT	MIA	2.1812252964426877
AVT	MCO	3.1438095238095238
CLT	DFW	3.0476836158192090
FRA	VIE	1.4050250250250250
FRA	LHR	1.7500000000000000
LHR	FRA	1.5800000000000000
LAS	EWR	5.0187234042553191
MUC	SFO	11.9607185628742515
MUC	OSL	2.3300000000000000
BER	DXB	6.3300000000000000
AMS	VIE	1.8300000000000000
ARN	MUC	2.2500000000000000
VIE	MUC	1.00111969111969111969
VIE	LHR	2.4456521739130435
ZRH	LAX	12.3300000000000000
MEX	ORD	4.2091666666666667
SEA	ATL	4.8053200568990043
ATL	MCO	1.5341535776614311
SEA	DAL	3.9430769230769231
PAE	LAX	2.8230303030303030
SEA	ORD	4.4244137931034483
SEA	ONT	2.6387967914438503
LAS	MIA	4.7164316239316239
LAS	ONT	1.1335678391959799
EWR	BOG	5.8300000000000000
EWR	MAD	7.4200000000000000
EWR	DUB	6.7361111111111111
MEX	MCO	3.2175084175084175
MIA	LAS	5.6823430962343096
MCO	SEA	6.6162098501070664
MCO	DEN	4.5148748353096179
MIA	CLT	2.2603158933859822
EWR	CLT	2.1211961206896552
EWR	SFO	6.4272015655577299
CLT	ORD	2.2243510054844607
MCO	CLT	1.8391206225680934
ORD	LAS	4.4438573883161512
DXB	DEL	3.2168214285714286
PEK	BKK	5.3197641509433962
DFW	MCO	2.6568064516129032
LAX	DFW	3.0950366568914956
SEA	SFO	2.2987723785166240
MIA	ATL	2.1084358288770053
ATL	EWR	2.2208773045136682
CLT	JFK	1.9640993788819876
JFK	ATL	2.6396708615682478
DEN	LAX	2.6327361791462561
JFK	LAS	5.9974024640657084
ORD	GRU	10.2500000000000000
SFO	DFW	3.6001009081735621
EWR	MCO	3.0698824188129899
DEN	CLT	3.2365573770491803
ORD	JFK	2.3617617449664430
DXB	MUC	6.7500000000000000
SEA	MUC	10.0800000000000000
OSL	MUC	2.4080933852140078
ZRH	DUB	2.4169767441860465
ARN	VIE	2.2500000000000000
LOS	FRA	6.5800000000000000
MCO	LAS	6.4204814814814815
ZRH	MRU	11.7500000000000000
BER	ZRH	1.4755414012738854
\.


--
-- Name: Airport_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes."Airport_id_seq"', 61, true);


--
-- Name: ROUTE_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes."ROUTE_id_seq"', 603, true);


--
-- Name: _ag_label_edge_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes._ag_label_edge_id_seq', 1, false);


--
-- Name: _ag_label_vertex_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes._ag_label_vertex_id_seq', 1, false);


--
-- Name: _label_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes._label_id_seq', 4, true);


--
-- Name: _ag_label_edge _ag_label_edge_pkey; Type: CONSTRAINT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes._ag_label_edge
    ADD CONSTRAINT _ag_label_edge_pkey PRIMARY KEY (id);


--
-- Name: _ag_label_vertex _ag_label_vertex_pkey; Type: CONSTRAINT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes._ag_label_vertex
    ADD CONSTRAINT _ag_label_vertex_pkey PRIMARY KEY (id);


--
-- Name: scheduled_routes scheduled_routes_pkey; Type: CONSTRAINT; Schema: l3; Owner: dst_graph_designer
--

ALTER TABLE ONLY l3.scheduled_routes
    ADD CONSTRAINT scheduled_routes_pkey PRIMARY KEY (departure_airport_code, arrival_airport_code);


--
-- Name: scheduled_routes scheduled_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: dst_graph_designer
--

ALTER TABLE ONLY public.scheduled_routes
    ADD CONSTRAINT scheduled_routes_pkey PRIMARY KEY (departure_airport_code, arrival_airport_code);


--
-- Name: scheduled_routes trigger_autoload_scheduled_routes; Type: TRIGGER; Schema: public; Owner: dst_graph_designer
--

CREATE TRIGGER trigger_autoload_scheduled_routes AFTER INSERT OR UPDATE ON public.scheduled_routes FOR EACH ROW EXECUTE FUNCTION flight_routes.autoload_scheduled_routes();


--
-- PostgreSQL database dump complete
--

