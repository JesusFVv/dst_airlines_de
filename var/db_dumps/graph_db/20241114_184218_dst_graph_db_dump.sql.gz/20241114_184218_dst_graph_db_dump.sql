--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Debian 16.3-1.pgdg120+1)
-- Dumped by pg_dump version 16.3 (Debian 16.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ag_catalog; Type: SCHEMA; Schema: -; Owner: dst_graph_designer
--

CREATE SCHEMA ag_catalog;


ALTER SCHEMA ag_catalog OWNER TO dst_graph_designer;

--
-- Name: flight_routes; Type: SCHEMA; Schema: -; Owner: dst_graph_designer
--

CREATE SCHEMA flight_routes;


ALTER SCHEMA flight_routes OWNER TO dst_graph_designer;

--
-- Name: l3; Type: SCHEMA; Schema: -; Owner: dst_graph_designer
--

CREATE SCHEMA l3;


ALTER SCHEMA l3 OWNER TO dst_graph_designer;

--
-- Name: age; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS age WITH SCHEMA ag_catalog;


--
-- Name: EXTENSION age; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION age IS 'AGE database extension';


--
-- Name: autoload_scheduled_routes(); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.autoload_scheduled_routes() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
	airport_code varchar;
	vertex int := 0;
	edge int := 0;
BEGIN
	LOAD 'age';
	SET search_path = ag_catalog, "$user", public;

	FOREACH airport_code IN ARRAY ARRAY[NEW.departure_airport_code, NEW.arrival_airport_code]
	LOOP
		vertex := 0;
		select count(*) INTO vertex FROM flight_routes.query_vertex_in_graph_db(airport_code);
		IF vertex = 0 THEN
			PERFORM flight_routes.create_vertex(airport_code);
		END IF;
	END LOOP;
	SELECT count(*) INTO edge FROM flight_routes.query_routes_in_graph_db(NEW.departure_airport_code, NEW.arrival_airport_code, 1);
	IF edge = 0 THEN
		PERFORM flight_routes.create_edge(NEW.departure_airport_code, NEW.arrival_airport_code, NEW.avg_flight_duration_hours);
	ELSE
		PERFORM flight_routes.update_edge_property(NEW.departure_airport_code, NEW.arrival_airport_code, NEW.avg_flight_duration_hours);
	END IF;
	RETURN NULL;
END;
$_$;


ALTER FUNCTION flight_routes.autoload_scheduled_routes() OWNER TO dst_graph_designer;

--
-- Name: create_edges(text, text, double precision); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.create_edges(departure_code text, arrival_code text, duration_hours double precision) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
    load 'age';
    SET search_path TO ag_catalog;
	sql := format('
		SELECT *
		FROM cypher(''flight_routes'', $$
			    MATCH (a:Airport), (b:Airport)
			    WHERE a.code = "%1$s" AND b.code = "%2$s"
			    CREATE (a)-[:ROUTE {duration: %3$s, route:"%1$s -> %2$s"}]->(b)
		$$) AS (e agtype);
	', departure_code, arrival_code, duration_hours);
	EXECUTE sql;
END
$_$;


ALTER FUNCTION flight_routes.create_edges(departure_code text, arrival_code text, duration_hours double precision) OWNER TO dst_graph_designer;

--
-- Name: create_vertex(text); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.create_vertex(airport_code text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
    load 'age';
    SET search_path TO ag_catalog;
	sql := format('
		SELECT *
		FROM cypher(''flight_routes'', $$
			CREATE (:Airport {code:"%1$s"})
		$$) AS (v agtype);
	', airport_code);
	EXECUTE sql;
END
$_$;


ALTER FUNCTION flight_routes.create_vertex(airport_code text) OWNER TO dst_graph_designer;

--
-- Name: query_routes_between_airports(character varying, character varying, integer); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.query_routes_between_airports(departure_code character varying, arrival_code character varying, number_flights integer) RETURNS TABLE(num_flights integer, route character varying, duration_hours double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN
	RETURN QUERY 
		with graph_query as (
			SELECT * FROM flight_routes.query_routes_in_graph_db(departure_code, arrival_code, number_flights)
		),
		routes_text as (
			select
				row_number() over(order by routes) as idx,
				cast(routes as varchar) as routes
				from graph_query
		),
		nodes_splitted as (
			select idx, regexp_matches(routes, '(?:{\"route\": \"([A-Z\->\s]*))', 'g') as node,
				regexp_matches(routes, '(?:\"duration\": ([0-9\.]*))', 'g') as duration_hours
				from routes_text
		),
		routes_formatted as (
			select  count(*)::int as num_flights, 
				string_agg(node[1], ' || ') as route,
				sum(cast(a.duration_hours[1] as float)) as duration_hours
				from nodes_splitted as a
				group by idx
		)
		select distinct a.num_flights::int, a.route::varchar, a.duration_hours::float
			from routes_formatted as a
			where regexp_count(a.route, departure_code) = 1 and regexp_count(a.route, arrival_code) = 1
			order by a.duration_hours asc, a.num_flights asc;
END
$$;


ALTER FUNCTION flight_routes.query_routes_between_airports(departure_code character varying, arrival_code character varying, number_flights integer) OWNER TO dst_graph_designer;

--
-- Name: query_routes_in_graph_db(character varying, character varying, integer); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.query_routes_in_graph_db(departure_code character varying, arrival_code character varying, number_flights integer) RETURNS TABLE(routes ag_catalog.agtype)
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
        load 'age';
        SET search_path TO ag_catalog;
        sql := format('
			SELECT *
			FROM cypher(''flight_routes'', $$
			    MATCH p = (:Airport {code: "%1$s"})-[*..%3$s]->(:Airport {code: "%2$s"})
			    RETURN relationships(p)
			$$) as (routes agtype);
		', departure_code, arrival_code, number_flights);
        RETURN QUERY EXECUTE sql;

END
$_$;


ALTER FUNCTION flight_routes.query_routes_in_graph_db(departure_code character varying, arrival_code character varying, number_flights integer) OWNER TO dst_graph_designer;

--
-- Name: query_vertex_in_graph_db(character varying); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.query_vertex_in_graph_db(airport_code character varying) RETURNS TABLE(code ag_catalog.agtype)
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
        load 'age';
        SET search_path TO ag_catalog;
        sql := format('
			SELECT *
			FROM cypher(''flight_routes'', $$
			    MATCH (n:Airport {code: "%1$s"})
			    RETURN n
			$$) as (code agtype);
		', airport_code);
        RETURN QUERY EXECUTE sql;
END
$_$;


ALTER FUNCTION flight_routes.query_vertex_in_graph_db(airport_code character varying) OWNER TO dst_graph_designer;

--
-- Name: update_edge_property(text, text, double precision); Type: FUNCTION; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE FUNCTION flight_routes.update_edge_property(departure_code text, arrival_code text, duration_hours double precision) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE sql VARCHAR;
BEGIN
    load 'age';
    SET search_path TO ag_catalog;
	sql := format('
		SELECT * 
			FROM cypher(''flight_routes'', $$
				MATCH (:Airport {code: "%1$s"})-[e:ROUTE]->(:Airport {code: "%2$s"})
				SET e.duration = %3$s
				RETURN e
				$$) as (e agtype);
	', departure_code, arrival_code, duration_hours);
	EXECUTE sql;
END
$_$;


ALTER FUNCTION flight_routes.update_edge_property(departure_code text, arrival_code text, duration_hours double precision) OWNER TO dst_graph_designer;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _ag_label_vertex; Type: TABLE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE TABLE flight_routes._ag_label_vertex (
    id ag_catalog.graphid NOT NULL,
    properties ag_catalog.agtype DEFAULT ag_catalog.agtype_build_map() NOT NULL
);


ALTER TABLE flight_routes._ag_label_vertex OWNER TO dst_graph_designer;

--
-- Name: Airport; Type: TABLE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE TABLE flight_routes."Airport" (
)
INHERITS (flight_routes._ag_label_vertex);


ALTER TABLE flight_routes."Airport" OWNER TO dst_graph_designer;

--
-- Name: Airport_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes."Airport_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 281474976710655
    CACHE 1;


ALTER SEQUENCE flight_routes."Airport_id_seq" OWNER TO dst_graph_designer;

--
-- Name: Airport_id_seq; Type: SEQUENCE OWNED BY; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER SEQUENCE flight_routes."Airport_id_seq" OWNED BY flight_routes."Airport".id;


--
-- Name: _ag_label_edge; Type: TABLE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE TABLE flight_routes._ag_label_edge (
    id ag_catalog.graphid NOT NULL,
    start_id ag_catalog.graphid NOT NULL,
    end_id ag_catalog.graphid NOT NULL,
    properties ag_catalog.agtype DEFAULT ag_catalog.agtype_build_map() NOT NULL
);


ALTER TABLE flight_routes._ag_label_edge OWNER TO dst_graph_designer;

--
-- Name: ROUTE; Type: TABLE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE TABLE flight_routes."ROUTE" (
)
INHERITS (flight_routes._ag_label_edge);


ALTER TABLE flight_routes."ROUTE" OWNER TO dst_graph_designer;

--
-- Name: ROUTE_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes."ROUTE_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 281474976710655
    CACHE 1;


ALTER SEQUENCE flight_routes."ROUTE_id_seq" OWNER TO dst_graph_designer;

--
-- Name: ROUTE_id_seq; Type: SEQUENCE OWNED BY; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER SEQUENCE flight_routes."ROUTE_id_seq" OWNED BY flight_routes."ROUTE".id;


--
-- Name: _ag_label_edge_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes._ag_label_edge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 281474976710655
    CACHE 1;


ALTER SEQUENCE flight_routes._ag_label_edge_id_seq OWNER TO dst_graph_designer;

--
-- Name: _ag_label_edge_id_seq; Type: SEQUENCE OWNED BY; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER SEQUENCE flight_routes._ag_label_edge_id_seq OWNED BY flight_routes._ag_label_edge.id;


--
-- Name: _ag_label_vertex_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes._ag_label_vertex_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 281474976710655
    CACHE 1;


ALTER SEQUENCE flight_routes._ag_label_vertex_id_seq OWNER TO dst_graph_designer;

--
-- Name: _ag_label_vertex_id_seq; Type: SEQUENCE OWNED BY; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER SEQUENCE flight_routes._ag_label_vertex_id_seq OWNED BY flight_routes._ag_label_vertex.id;


--
-- Name: _label_id_seq; Type: SEQUENCE; Schema: flight_routes; Owner: dst_graph_designer
--

CREATE SEQUENCE flight_routes._label_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 65535
    CACHE 1
    CYCLE;


ALTER SEQUENCE flight_routes._label_id_seq OWNER TO dst_graph_designer;

--
-- Name: scheduled_routes; Type: TABLE; Schema: l3; Owner: dst_graph_designer
--

CREATE TABLE l3.scheduled_routes (
    departure_airport_code character varying(50) NOT NULL,
    arrival_airport_code character varying(50) NOT NULL,
    avg_flight_duration_hours numeric
);


ALTER TABLE l3.scheduled_routes OWNER TO dst_graph_designer;

--
-- Name: scheduled_routes; Type: TABLE; Schema: public; Owner: dst_graph_designer
--

CREATE TABLE public.scheduled_routes (
    departure_airport_code character varying(50) NOT NULL,
    arrival_airport_code character varying(50) NOT NULL,
    avg_flight_duration_hours numeric
);


ALTER TABLE public.scheduled_routes OWNER TO dst_graph_designer;

--
-- Name: Airport id; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes."Airport" ALTER COLUMN id SET DEFAULT ag_catalog._graphid((ag_catalog._label_id('flight_routes'::name, 'Airport'::name))::integer, nextval('flight_routes."Airport_id_seq"'::regclass));


--
-- Name: Airport properties; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes."Airport" ALTER COLUMN properties SET DEFAULT ag_catalog.agtype_build_map();


--
-- Name: ROUTE id; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes."ROUTE" ALTER COLUMN id SET DEFAULT ag_catalog._graphid((ag_catalog._label_id('flight_routes'::name, 'ROUTE'::name))::integer, nextval('flight_routes."ROUTE_id_seq"'::regclass));


--
-- Name: ROUTE properties; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes."ROUTE" ALTER COLUMN properties SET DEFAULT ag_catalog.agtype_build_map();


--
-- Name: _ag_label_edge id; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes._ag_label_edge ALTER COLUMN id SET DEFAULT ag_catalog._graphid((ag_catalog._label_id('flight_routes'::name, '_ag_label_edge'::name))::integer, nextval('flight_routes._ag_label_edge_id_seq'::regclass));


--
-- Name: _ag_label_vertex id; Type: DEFAULT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes._ag_label_vertex ALTER COLUMN id SET DEFAULT ag_catalog._graphid((ag_catalog._label_id('flight_routes'::name, '_ag_label_vertex'::name))::integer, nextval('flight_routes._ag_label_vertex_id_seq'::regclass));


--
-- Data for Name: ag_graph; Type: TABLE DATA; Schema: ag_catalog; Owner: dst_graph_designer
--

COPY ag_catalog.ag_graph (graphid, name, namespace) FROM stdin;
17040	flight_routes	flight_routes
\.


--
-- Data for Name: ag_label; Type: TABLE DATA; Schema: ag_catalog; Owner: dst_graph_designer
--

COPY ag_catalog.ag_label (name, graph, id, kind, relation, seq_name) FROM stdin;
_ag_label_vertex	17040	1	v	flight_routes._ag_label_vertex	_ag_label_vertex_id_seq
_ag_label_edge	17040	2	e	flight_routes._ag_label_edge	_ag_label_edge_id_seq
Airport	17040	3	v	flight_routes."Airport"	Airport_id_seq
ROUTE	17040	4	e	flight_routes."ROUTE"	ROUTE_id_seq
\.


--
-- Data for Name: Airport; Type: TABLE DATA; Schema: flight_routes; Owner: dst_graph_designer
--

COPY flight_routes."Airport" (id, properties) FROM stdin;
844424930131969	{"code": "GRU"}
844424930131970	{"code": "ATL"}
844424930131971	{"code": "CLT"}
844424930131972	{"code": "JFK"}
844424930131973	{"code": "MCO"}
844424930131974	{"code": "FRA"}
844424930131975	{"code": "EWR"}
844424930131976	{"code": "VIE"}
844424930131977	{"code": "LHR"}
844424930131978	{"code": "MUC"}
844424930131979	{"code": "SEA"}
844424930131980	{"code": "LAX"}
844424930131981	{"code": "LAS"}
844424930131982	{"code": "ATH"}
844424930131983	{"code": "DEN"}
844424930131984	{"code": "DXB"}
844424930131985	{"code": "MIA"}
844424930131986	{"code": "MAD"}
844424930131987	{"code": "ZRH"}
844424930131988	{"code": "DFW"}
844424930131989	{"code": "SFO"}
844424930131990	{"code": "BOG"}
844424930131991	{"code": "CAI"}
844424930131992	{"code": "MEX"}
844424930131993	{"code": "CDG"}
844424930131994	{"code": "ORD"}
844424930131995	{"code": "CMN"}
844424930131996	{"code": "OSL"}
844424930131997	{"code": "ARN"}
844424930131998	{"code": "AMS"}
844424930131999	{"code": "ONT"}
844424930132000	{"code": "LOS"}
844424930132001	{"code": "FCO"}
844424930132002	{"code": "DUB"}
844424930132003	{"code": "PVG"}
844424930132004	{"code": "BER"}
844424930132005	{"code": "LIS"}
844424930132006	{"code": "BKK"}
844424930132007	{"code": "AGY"}
844424930132008	{"code": "SAW"}
844424930132009	{"code": "PAE"}
844424930132010	{"code": "NLU"}
844424930132011	{"code": "MAN"}
844424930132012	{"code": "MRU"}
844424930132013	{"code": "HND"}
844424930132014	{"code": "DEL"}
844424930132015	{"code": "DMK"}
844424930132016	{"code": "WAW"}
844424930132017	{"code": "IST"}
844424930132018	{"code": "CPT"}
844424930132019	{"code": "SSH"}
844424930132020	{"code": "NBO"}
844424930132021	{"code": "NCE"}
844424930132022	{"code": "DMM"}
844424930132023	{"code": "PEK"}
844424930132024	{"code": "EKW"}
844424930132025	{"code": "AVT"}
844424930132026	{"code": "ALG"}
844424930132027	{"code": "ZMU"}
844424930132028	{"code": "DAL"}
844424930132029	{"code": "QPP"}
\.


--
-- Data for Name: ROUTE; Type: TABLE DATA; Schema: flight_routes; Owner: dst_graph_designer
--

COPY flight_routes."ROUTE" (id, start_id, end_id, properties) FROM stdin;
1125899906842807	844424930131989	844424930131979	{"route": "SFO -> SEA", "duration": 2.331026845637584}
1125899906842781	844424930131980	844424930131972	{"route": "LAX -> JFK", "duration": 5.465949367088608}
1125899906842822	844424930131980	844424930131979	{"route": "LAX -> SEA", "duration": 3.151409657320872}
1125899906843047	844424930131970	844424930132028	{"route": "ATL -> DAL", "duration": 2.3139142091152816}
1125899906842818	844424930131970	844424930131988	{"route": "ATL -> DFW", "duration": 2.6727877428998505}
1125899906842899	844424930131983	844424930131980	{"route": "DEN -> LAX", "duration": 2.627176644493718}
1125899906843022	844424930131972	844424930131970	{"route": "JFK -> ATL", "duration": 2.638634496919918}
1125899906842765	844424930131975	844424930131973	{"route": "EWR -> MCO", "duration": 3.0773784104389086}
1125899906842711	844424930131987	844424930132012	{"route": "ZRH -> MRU", "duration": 11.72972972972973}
1125899906842714	844424930131975	844424930132004	{"route": "EWR -> BER", "duration": 8.08}
1125899906842628	844424930131975	844424930131976	{"route": "EWR -> VIE", "duration": 8.098837209302326}
1125899906842643	844424930131973	844424930131981	{"route": "MCO -> LAS", "duration": 6.443843137254902}
1125899906842722	844424930131994	844424930131972	{"route": "ORD -> JFK", "duration": 2.361190053285968}
1125899906842667	844424930131974	844424930132003	{"route": "FRA -> PVG", "duration": 11.470193548387098}
1125899906842654	844424930131978	844424930131998	{"route": "MUC -> AMS", "duration": 1.67}
1125899906842656	844424930131979	844424930131978	{"route": "SEA -> MUC", "duration": 10.08}
1125899906842715	844424930131989	844424930131981	{"route": "SFO -> LAS", "duration": 1.8310858995137762}
1125899906842698	844424930131983	844424930131971	{"route": "DEN -> CLT", "duration": 3.241514195583596}
1125899906842786	844424930131983	844424930131979	{"route": "DEN -> SEA", "duration": 3.3827879341864717}
1125899906842831	844424930131973	844424930131970	{"route": "MCO -> ATL", "duration": 1.6547253433208489}
1125899906842625	844424930131969	844424930131970	{"route": "GRU -> ATL", "duration": 9.933095238095238}
1125899906843037	844424930131994	844424930131970	{"route": "ORD -> ATL", "duration": 2.0779803761242843}
1125899906843004	844424930132006	844424930132014	{"route": "BKK -> DEL", "duration": 4.604927536231884}
1125899906843048	844424930132029	844424930131974	{"route": "QPP -> FRA", "duration": 4.451969309462916}
1125899906843023	844424930132004	844424930131974	{"route": "BER -> FRA", "duration": 1.25}
1125899906842840	844424930131970	844424930131985	{"route": "ATL -> MIA", "duration": 1.9985080928923293}
1125899906842966	844424930131972	844424930131983	{"route": "JFK -> DEN", "duration": 4.7187186629526465}
1125899906842757	844424930131988	844424930131983	{"route": "DFW -> DEN", "duration": 2.217904761904762}
1125899906843009	844424930131984	844424930132006	{"route": "DXB -> BKK", "duration": 6.084}
1125899906842997	844424930132017	844424930131974	{"route": "IST -> FRA", "duration": 3.3772819472616633}
1125899906842934	844424930131994	844424930131973	{"route": "ORD -> MCO", "duration": 2.920269097222222}
1125899906842726	844424930131972	844424930131980	{"route": "JFK -> LAX", "duration": 6.375517836593786}
1125899906842791	844424930131973	844424930131975	{"route": "MCO -> EWR", "duration": 2.758681710213777}
1125899906842999	844424930131970	844424930131971	{"route": "ATL -> CLT", "duration": 1.2751012145748988}
1125899906842629	844424930131977	844424930131978	{"route": "LHR -> MUC", "duration": 1.83}
1125899906842673	844424930131987	844424930131994	{"route": "ZRH -> ORD", "duration": 10.08}
1125899906842873	844424930131995	844424930132017	{"route": "CMN -> IST", "duration": 4.571111111111111}
1125899906842642	844424930131970	844424930131979	{"route": "ATL -> SEA", "duration": 5.750221238938053}
1125899906842633	844424930131983	844424930131977	{"route": "DEN -> LHR", "duration": 9.08}
1125899906842660	844424930131994	844424930131969	{"route": "ORD -> GRU", "duration": 10.25}
1125899906842687	844424930131994	844424930131993	{"route": "ORD -> CDG", "duration": 8.08}
1125899906842662	844424930131987	844424930131978	{"route": "ZRH -> MUC", "duration": 0.9335433070866141}
1125899906842707	844424930131970	844424930131990	{"route": "ATL -> BOG", "duration": 4.673009404388715}
1125899906842688	844424930131974	844424930132008	{"route": "FRA -> SAW", "duration": 3.1199022801302934}
1125899906842681	844424930131989	844424930131971	{"route": "SFO -> CLT", "duration": 5.088632707774799}
1125899906842639	844424930131989	844424930131988	{"route": "SFO -> DFW", "duration": 3.5874113856068743}
1125899906842651	844424930131974	844424930131985	{"route": "FRA -> MIA", "duration": 10.42}
1125899906842677	844424930131981	844424930131994	{"route": "LAS -> ORD", "duration": 3.813965517241379}
1125899906842663	844424930131980	844424930131983	{"route": "LAX -> DEN", "duration": 2.45542069992554}
1125899906842717	844424930131977	844424930131976	{"route": "LHR -> VIE", "duration": 2.2325192802056555}
1125899906842709	844424930132011	844424930131976	{"route": "MAN -> VIE", "duration": 2.42}
1125899906842721	844424930132011	844424930131987	{"route": "MAN -> ZRH", "duration": 1.96375}
1125899906842671	844424930131987	844424930131977	{"route": "ZRH -> LHR", "duration": 1.867142857142857}
1125899906842692	844424930131975	844424930131970	{"route": "EWR -> ATL", "duration": 2.5518831615120274}
1125899906842706	844424930131980	844424930132009	{"route": "LAX -> PAE", "duration": 2.9694545454545453}
1125899906842664	844424930131969	844424930131980	{"route": "GRU -> LAX", "duration": 12.33}
1125899906842645	844424930131978	844424930131974	{"route": "MUC -> FRA", "duration": 1.08}
1125899906842661	844424930131987	844424930132002	{"route": "ZRH -> DUB", "duration": 2.417125}
1125899906842652	844424930131996	844424930131978	{"route": "OSL -> MUC", "duration": 2.4092857142857143}
1125899906842632	844424930131982	844424930131975	{"route": "ATH -> EWR", "duration": 11.17}
1125899906842700	844424930131990	844424930131970	{"route": "BOG -> ATL", "duration": 5.145222929936305}
1125899906842649	844424930131987	844424930131993	{"route": "ZRH -> CDG", "duration": 1.3630395136778115}
1125899906842679	844424930131970	844424930131994	{"route": "ATL -> ORD", "duration": 2.161077551020408}
1125899906842635	844424930131978	844424930131984	{"route": "MUC -> DXB", "duration": 5.83}
1125899906842694	844424930131997	844424930131976	{"route": "ARN -> VIE", "duration": 2.25}
1125899906842682	844424930131973	844424930131992	{"route": "MCO -> MEX", "duration": 3.9300709219858154}
1125899906842646	844424930131993	844424930131978	{"route": "CDG -> MUC", "duration": 1.42}
1125899906842697	844424930131978	844424930132003	{"route": "MUC -> PVG", "duration": 11.433904761904762}
1125899906842712	844424930131978	844424930132006	{"route": "MUC -> BKK", "duration": 10.5}
1125899906842809	844424930131972	844424930131985	{"route": "JFK -> MIA", "duration": 3.3310380348652933}
1125899906842637	844424930131986	844424930131987	{"route": "MAD -> ZRH", "duration": 2.2886754966887417}
1125899906842648	844424930131974	844424930131995	{"route": "FRA -> CMN", "duration": 3.75}
1125899906842670	844424930131981	844424930131972	{"route": "LAS -> JFK", "duration": 5.009284903518728}
1125899906842666	844424930131990	844424930131973	{"route": "BOG -> MCO", "duration": 4.271124744376278}
1125899906842630	844424930131979	844424930131980	{"route": "SEA -> LAX", "duration": 2.9775287797390635}
1125899906842716	844424930131973	844424930131990	{"route": "MCO -> BOG", "duration": 3.9902249488752557}
1125899906842627	844424930131973	844424930131974	{"route": "MCO -> FRA", "duration": 9.08}
1125899906842846	844424930131983	844424930131988	{"route": "DEN -> DFW", "duration": 2.0705539143279172}
1125899906842659	844424930132001	844424930131987	{"route": "FCO -> ZRH", "duration": 1.6116216216216217}
1125899906842701	844424930132009	844424930131981	{"route": "PAE -> LAS", "duration": 2.542887323943662}
1125899906842680	844424930131981	844424930131983	{"route": "LAS -> DEN", "duration": 2.0039655172413795}
1125899906842951	844424930131980	844424930131994	{"route": "LAX -> ORD", "duration": 4.1538}
1125899906842703	844424930131986	844424930131974	{"route": "MAD -> FRA", "duration": 2.58}
1125899906842708	844424930131993	844424930131987	{"route": "CDG -> ZRH", "duration": 1.3108814589665654}
1125899906842675	844424930131978	844424930131994	{"route": "MUC -> ORD", "duration": 9.788441558441558}
1125899906842686	844424930131976	844424930131975	{"route": "VIE -> EWR", "duration": 9.75}
1125899906842668	844424930131970	844424930131972	{"route": "ATL -> JFK", "duration": 2.2651531151003166}
1125899906842674	844424930131974	844424930131981	{"route": "FRA -> LAS", "duration": 11.75}
1125899906842693	844424930131979	844424930131971	{"route": "SEA -> CLT", "duration": 5.0010041841004185}
1125899906842634	844424930131983	844424930131972	{"route": "DEN -> JFK", "duration": 3.7502798982188295}
1125899906842695	844424930132004	844424930131987	{"route": "BER -> ZRH", "duration": 1.4754838709677418}
1125899906842685	844424930132007	844424930131974	{"route": "AGY -> FRA", "duration": 3.204}
1125899906842657	844424930131994	844424930131980	{"route": "ORD -> LAX", "duration": 4.634107498341075}
1125899906842989	844424930131972	844424930131973	{"route": "JFK -> MCO", "duration": 3.0768575974542562}
1125899906842641	844424930131991	844424930131976	{"route": "CAI -> VIE", "duration": 3.75}
1125899906842696	844424930131970	844424930131992	{"route": "ATL -> MEX", "duration": 3.8884526558891457}
1125899906842704	844424930131994	844424930132010	{"route": "ORD -> NLU", "duration": 4.25}
1125899906842719	844424930132010	844424930131994	{"route": "NLU -> ORD", "duration": 4.08}
1125899906842669	844424930131976	844424930132004	{"route": "VIE -> BER", "duration": 1.2523161764705881}
1125899906842705	844424930131971	844424930131970	{"route": "CLT -> ATL", "duration": 1.3937919737919737}
1125899906842653	844424930131976	844424930131997	{"route": "VIE -> ARN", "duration": 2.25}
1125899906842723	844424930131972	844424930131990	{"route": "JFK -> BOG", "duration": 5.896}
1125899906842690	844424930131987	844424930131991	{"route": "ZRH -> CAI", "duration": 4.002023809523809}
1125899906842636	844424930131985	844424930131969	{"route": "MIA -> GRU", "duration": 8.320876033057852}
1125899906842838	844424930132012	844424930131976	{"route": "MRU -> VIE", "duration": 10.83}
1125899906842847	844424930131998	844424930131975	{"route": "AMS -> EWR", "duration": 8.42}
1125899906842731	844424930132003	844424930131976	{"route": "PVG -> VIE", "duration": 12.92}
1125899906842834	844424930131980	844424930131987	{"route": "LAX -> ZRH", "duration": 11.08}
1125899906842735	844424930131972	844424930131978	{"route": "JFK -> MUC", "duration": 7.5}
1125899906842869	844424930131980	844424930131974	{"route": "LAX -> FRA", "duration": 10.92}
1125899906842782	844424930131972	844424930131976	{"route": "JFK -> VIE", "duration": 8.25}
1125899906842743	844424930131978	844424930131979	{"route": "MUC -> SEA", "duration": 10.67}
1125899906842769	844424930132001	844424930131994	{"route": "FCO -> ORD", "duration": 10.33}
1125899906842785	844424930131978	844424930131980	{"route": "MUC -> LAX", "duration": 12.218}
1125899906842816	844424930131978	844424930132023	{"route": "MUC -> PEK", "duration": 9.915693430656935}
1125899906842864	844424930131992	844424930131971	{"route": "MEX -> CLT", "duration": 3.756588235294118}
1125899906842841	844424930131971	844424930131992	{"route": "CLT -> MEX", "duration": 4.443255813953488}
1125899906842790	844424930131973	844424930132010	{"route": "MCO -> NLU", "duration": 3.42}
1125899906842821	844424930131978	844424930132002	{"route": "MUC -> DUB", "duration": 2.58}
1125899906842794	844424930131999	844424930131994	{"route": "ONT -> ORD", "duration": 6.171578947368421}
1125899906842796	844424930131979	844424930131992	{"route": "SEA -> MEX", "duration": 5.549302325581396}
1125899906842798	844424930131983	844424930132010	{"route": "DEN -> NLU", "duration": 3.58}
1125899906842799	844424930132012	844424930132020	{"route": "MRU -> NBO", "duration": 4.255333333333334}
1125899906842802	844424930131980	844424930132010	{"route": "LAX -> NLU", "duration": 3.67}
1125899906842778	844424930131983	844424930131992	{"route": "DEN -> MEX", "duration": 3.95062015503876}
1125899906842872	844424930131978	844424930132011	{"route": "MUC -> MAN", "duration": 2.25}
1125899906842883	844424930131985	844424930131987	{"route": "MIA -> ZRH", "duration": 9.07746835443038}
1125899906842820	844424930131976	844424930132003	{"route": "VIE -> PVG", "duration": 11.08}
1125899906842752	844424930131975	844424930131969	{"route": "EWR -> GRU", "duration": 9.5}
1125899906842744	844424930131997	844424930131987	{"route": "ARN -> ZRH", "duration": 2.444}
1125899906842828	844424930131975	844424930131978	{"route": "EWR -> MUC", "duration": 7.7077611940298505}
1125899906842843	844424930131999	844424930131971	{"route": "ONT -> CLT", "duration": 4.925079365079365}
1125899906842870	844424930131985	844424930131989	{"route": "MIA -> SFO", "duration": 6.7974772727272725}
1125899906842748	844424930131979	844424930131985	{"route": "SEA -> MIA", "duration": 6.017849829351536}
1125899906842730	844424930131994	844424930131976	{"route": "ORD -> VIE", "duration": 8.75}
1125899906842860	844424930131971	844424930131999	{"route": "CLT -> ONT", "duration": 5.193333333333333}
1125899906842863	844424930131985	844424930132010	{"route": "MIA -> NLU", "duration": 3.42}
1125899906842808	844424930131985	844424930131979	{"route": "MIA -> SEA", "duration": 6.924270072992701}
1125899906842866	844424930131994	844424930132001	{"route": "ORD -> FCO", "duration": 8.92}
1125899906842867	844424930132010	844424930131973	{"route": "NLU -> MCO", "duration": 3.08}
1125899906842779	844424930131971	844424930131979	{"route": "CLT -> SEA", "duration": 5.924979079497908}
1125899906842887	844424930131981	844424930131974	{"route": "LAS -> FRA", "duration": 11}
1125899906842776	844424930131975	844424930131992	{"route": "EWR -> MEX", "duration": 5.6576744186046515}
1125899906842750	844424930132017	844424930132000	{"route": "IST -> LOS", "duration": 7.25}
1125899906842850	844424930132014	844424930131987	{"route": "DEL -> ZRH", "duration": 9.08}
1125899906842767	844424930131991	844424930131987	{"route": "CAI -> ZRH", "duration": 4.17}
1125899906842793	844424930132012	844424930131987	{"route": "MRU -> ZRH", "duration": 12.284864864864865}
1125899906842739	844424930131970	844424930131974	{"route": "ATL -> FRA", "duration": 8.75}
1125899906842868	844424930131999	844424930131989	{"route": "ONT -> SFO", "duration": 1.5734387351778656}
1125899906842811	844424930131988	844424930131974	{"route": "DFW -> FRA", "duration": 9.83}
1125899906842763	844424930131975	844424930131974	{"route": "EWR -> FRA", "duration": 7.4628421052631575}
1125899906842758	844424930131992	844424930131970	{"route": "MEX -> ATL", "duration": 3.409392523364486}
1125899906842829	844424930131981	844424930131971	{"route": "LAS -> CLT", "duration": 4.252659176029963}
1125899906842774	844424930131975	844424930131998	{"route": "EWR -> AMS", "duration": 7.17}
1125899906842878	844424930131975	844424930132005	{"route": "EWR -> LIS", "duration": 6.58}
1125899906842833	844424930131975	844424930132001	{"route": "EWR -> FCO", "duration": 8.58}
1125899906842837	844424930131972	844424930131979	{"route": "JFK -> SEA", "duration": 6.480178571428572}
1125899906842725	844424930131992	844424930131980	{"route": "MEX -> LAX", "duration": 4.319226804123711}
1125899906842773	844424930131989	844424930131999	{"route": "SFO -> ONT", "duration": 1.4951063829787234}
1125899906842737	844424930131992	844424930131985	{"route": "MEX -> MIA", "duration": 3.2490018484288354}
1125899906842784	844424930131989	844424930131987	{"route": "SFO -> ZRH", "duration": 11.08}
1125899906842824	844424930131990	844424930131975	{"route": "BOG -> EWR", "duration": 6.032952380952381}
1125899906842876	844424930131969	844424930131978	{"route": "GRU -> MUC", "duration": 11.58}
1125899906842826	844424930131969	844424930131973	{"route": "GRU -> MCO", "duration": 9}
1125899906842792	844424930131989	844424930131992	{"route": "SFO -> MEX", "duration": 4.393120879120879}
1125899906842806	844424930131974	844424930132022	{"route": "FRA -> DMM", "duration": 7.58}
1125899906842760	844424930131974	844424930132018	{"route": "FRA -> CPT", "duration": 11.67}
1125899906842886	844424930131974	844424930131983	{"route": "FRA -> DEN", "duration": 10.58955223880597}
1125899906842728	844424930131992	844424930131990	{"route": "MEX -> BOG", "duration": 4.556295754026355}
1125899906842859	844424930131969	844424930131972	{"route": "GRU -> JFK", "duration": 9.962105263157895}
1125899906842875	844424930131989	844424930131994	{"route": "SFO -> ORD", "duration": 4.355492125984252}
1125899906842762	844424930131974	844424930132013	{"route": "FRA -> HND", "duration": 13.014}
1125899906842852	844424930131975	844424930131981	{"route": "EWR -> LAS", "duration": 5.725354330708662}
1125899906842766	844424930131974	844424930131991	{"route": "FRA -> CAI", "duration": 4.152952380952381}
1125899906842862	844424930131974	844424930131994	{"route": "FRA -> ORD", "duration": 9.496145454545454}
1125899906842756	844424930131974	844424930131972	{"route": "FRA -> JFK", "duration": 8.976859504132232}
1125899906842856	844424930131974	844424930131973	{"route": "FRA -> MCO", "duration": 10.75}
1125899906842881	844424930131974	844424930131992	{"route": "FRA -> MEX", "duration": 12.33}
1125899906842788	844424930131989	844424930131983	{"route": "SFO -> DEN", "duration": 2.67304865938431}
1125899906842889	844424930131974	844424930132021	{"route": "FRA -> NCE", "duration": 1.58}
1125899906842787	844424930131978	844424930131997	{"route": "MUC -> ARN", "duration": 2.25}
1125899906842830	844424930132011	844424930131978	{"route": "MAN -> MUC", "duration": 1.92}
1125899906842845	844424930131974	844424930132011	{"route": "FRA -> MAN", "duration": 1.83}
1125899906842823	844424930131974	844424930131982	{"route": "FRA -> ATH", "duration": 2.7821153846153845}
1125899906842844	844424930131974	844424930132012	{"route": "FRA -> MRU", "duration": 11.25}
1125899906842805	844424930131974	844424930132002	{"route": "FRA -> DUB", "duration": 2.17}
1125899906842812	844424930131978	844424930131982	{"route": "MUC -> ATH", "duration": 2.4575280898876404}
1125899906842817	844424930131974	844424930132016	{"route": "FRA -> WAW", "duration": 1.6999778270509978}
1125899906842780	844424930131974	844424930131993	{"route": "FRA -> CDG", "duration": 1.25}
1125899906842772	844424930131997	844424930132004	{"route": "ARN -> BER", "duration": 1.58}
1125899906842814	844424930131997	844424930131996	{"route": "ARN -> OSL", "duration": 1.0259288537549407}
1125899906842874	844424930131974	844424930131987	{"route": "FRA -> ZRH", "duration": 0.951131221719457}
1125899906842746	844424930132004	844424930131976	{"route": "BER -> VIE", "duration": 1.2527223230490019}
1125899906842740	844424930131976	844424930131972	{"route": "VIE -> JFK", "duration": 9.75}
1125899906842789	844424930132005	844424930131986	{"route": "LIS -> MAD", "duration": 1.4110743801652894}
1125899906842825	844424930131974	844424930131979	{"route": "FRA -> SEA", "duration": 10.83}
1125899906842884	844424930131986	844424930131978	{"route": "MAD -> MUC", "duration": 2.58}
1125899906842749	844424930131976	844424930131982	{"route": "VIE -> ATH", "duration": 2.153069306930693}
1125899906842732	844424930132016	844424930131987	{"route": "WAW -> ZRH", "duration": 2.0854166666666667}
1125899906842835	844424930132005	844424930131974	{"route": "LIS -> FRA", "duration": 3.1328285077951}
1125899906842733	844424930132001	844424930131974	{"route": "FCO -> FRA", "duration": 2}
1125899906842759	844424930131982	844424930131978	{"route": "ATH -> MUC", "duration": 2.7125}
1125899906842854	844424930131976	844424930132001	{"route": "VIE -> FCO", "duration": 1.5826277372262774}
1125899906842755	844424930131987	844424930132003	{"route": "ZRH -> PVG", "duration": 12.25}
1125899906842842	844424930131987	844424930132006	{"route": "ZRH -> BKK", "duration": 10.67}
1125899906842745	844424930131987	844424930132014	{"route": "ZRH -> DEL", "duration": 7.75}
1125899906842839	844424930131987	844424930131975	{"route": "ZRH -> EWR", "duration": 9.25}
1125899906842753	844424930131987	844424930131972	{"route": "ZRH -> JFK", "duration": 9.335497076023392}
1125899906842879	844424930132003	844424930131987	{"route": "PVG -> ZRH", "duration": 14.33}
1125899906842734	844424930131987	844424930132011	{"route": "ZRH -> MAN", "duration": 2.0930526315789475}
1125899906842800	844424930132002	844424930131978	{"route": "DUB -> MUC", "duration": 2.25}
1125899906842804	844424930131987	844424930132001	{"route": "ZRH -> FCO", "duration": 1.5595515695067266}
1125899906842801	844424930131987	844424930132021	{"route": "ZRH -> NCE", "duration": 1.1969803921568627}
1125899906842819	844424930132002	844424930131974	{"route": "DUB -> FRA", "duration": 2}
1125899906842827	844424930132002	844424930131987	{"route": "DUB -> ZRH", "duration": 2.17}
1125899906842738	844424930131987	844424930131974	{"route": "ZRH -> FRA", "duration": 1.0916742081447963}
1125899906842724	844424930132015	844424930132003	{"route": "DMK -> PVG", "duration": 4.08}
1125899906842771	844424930131987	844424930132019	{"route": "ZRH -> SSH", "duration": 5.165}
1125899906842848	844424930132013	844424930131978	{"route": "HND -> MUC", "duration": 14.682048192771084}
1125899906842803	844424930131987	844424930132004	{"route": "ZRH -> BER", "duration": 1.4724114441416893}
1125899906842853	844424930131995	844424930132008	{"route": "CMN -> SAW", "duration": 4.776666666666666}
1125899906842861	844424930132014	844424930132006	{"route": "DEL -> BKK", "duration": 3.9745054945054945}
1125899906842877	844424930131994	844424930131974	{"route": "ORD -> FRA", "duration": 8.437282608695652}
1125899906842761	844424930131972	844424930131988	{"route": "JFK -> DFW", "duration": 4.229724770642202}
1125899906842795	844424930131972	844424930131969	{"route": "JFK -> GRU", "duration": 9.575538793103448}
1125899906842885	844424930131980	844424930131992	{"route": "LAX -> MEX", "duration": 3.7387436332767403}
1125899906842851	844424930131980	844424930131971	{"route": "LAX -> CLT", "duration": 4.832689335394127}
1125899906842871	844424930131970	844424930131989	{"route": "ATL -> SFO", "duration": 5.439862804878048}
1125899906842727	844424930131983	844424930131985	{"route": "DEN -> MIA", "duration": 4.1230806451612905}
1125899906842813	844424930131971	844424930131975	{"route": "CLT -> EWR", "duration": 1.9072311212814645}
1125899906842882	844424930131973	844424930132025	{"route": "MCO -> AVT", "duration": 3.0736687631027255}
1125899906842747	844424930131994	844424930131979	{"route": "ORD -> SEA", "duration": 4.80579295154185}
1125899906842857	844424930131973	844424930132024	{"route": "MCO -> EKW", "duration": 3.479122401847575}
1125899906842729	844424930131988	844424930131975	{"route": "DFW -> EWR", "duration": 3.3752613636363638}
1125899906842832	844424930131994	844424930131981	{"route": "ORD -> LAS", "duration": 4.421322849213691}
1125899906842836	844424930131973	844424930131988	{"route": "MCO -> DFW", "duration": 3.1519789842381787}
1125899906842880	844424930131979	844424930131988	{"route": "SEA -> DFW", "duration": 3.9535677966101694}
1125899906842775	844424930131981	844424930131970	{"route": "LAS -> ATL", "duration": 3.9391683366733465}
1125899906842770	844424930131974	844424930132004	{"route": "FRA -> BER", "duration": 1.17}
1125899906842810	844424930131976	844424930131974	{"route": "VIE -> FRA", "duration": 1.4925026624068158}
1125899906842964	844424930131973	844424930131972	{"route": "MCO -> JFK", "duration": 2.6897591362126247}
1125899906842768	844424930131994	844424930131971	{"route": "ORD -> CLT", "duration": 2.0741074856046064}
1125899906842742	844424930131985	844424930131994	{"route": "MIA -> ORD", "duration": 3.646972395369546}
1125899906842754	844424930131985	844424930131972	{"route": "MIA -> JFK", "duration": 3.0697184231697507}
1125899906842858	844424930131973	844424930131971	{"route": "MCO -> CLT", "duration": 1.8396505823627287}
1125899906843027	844424930131972	844424930131974	{"route": "JFK -> FRA", "duration": 7.692950819672131}
1125899906842902	844424930131988	844424930132010	{"route": "DFW -> NLU", "duration": 2.67}
1125899906842986	844424930131981	844424930132009	{"route": "LAS -> PAE", "duration": 2.8593793103448277}
1125899906842910	844424930131978	844424930131992	{"route": "MUC -> MEX", "duration": 13}
1125899906843046	844424930131985	844424930131974	{"route": "MIA -> FRA", "duration": 9}
1125899906842959	844424930131999	844424930131970	{"route": "ONT -> ATL", "duration": 4.139116279069768}
1125899906842927	844424930131975	844424930131982	{"route": "EWR -> ATH", "duration": 9.5}
1125899906842944	844424930132004	844424930131975	{"route": "BER -> EWR", "duration": 9.33}
1125899906843029	844424930131977	844424930131983	{"route": "LHR -> DEN", "duration": 9.83}
1125899906842901	844424930131978	844424930132014	{"route": "MUC -> DEL", "duration": 7.42}
1125899906842957	844424930131989	844424930131993	{"route": "SFO -> CDG", "duration": 10.75}
1125899906842943	844424930131978	844424930131975	{"route": "MUC -> EWR", "duration": 9.101481481481482}
1125899906842963	844424930132004	844424930132021	{"route": "BER -> NCE", "duration": 2}
1125899906842952	844424930131992	844424930131979	{"route": "MEX -> SEA", "duration": 6.048588235294118}
1125899906842979	844424930131996	844424930131987	{"route": "OSL -> ZRH", "duration": 2.5935}
1125899906842967	844424930131994	844424930131999	{"route": "ORD -> ONT", "duration": 8.76}
1125899906842946	844424930131992	844424930131983	{"route": "MEX -> DEN", "duration": 3.95109375}
1125899906843016	844424930131994	844424930131998	{"route": "ORD -> AMS", "duration": 8.42}
1125899906842961	844424930131999	844424930131981	{"route": "ONT -> LAS", "duration": 1.1867605633802818}
1125899906842995	844424930131974	844424930132007	{"route": "FRA -> AGY", "duration": 2.9566666666666666}
1125899906842947	844424930131981	844424930131992	{"route": "LAS -> MEX", "duration": 3.803744855967078}
1125899906842954	844424930131972	844424930131987	{"route": "JFK -> ZRH", "duration": 7.709768786127167}
1125899906842975	844424930131992	844424930132017	{"route": "MEX -> IST", "duration": 15.910733944954128}
1125899906843013	844424930131985	844424930131978	{"route": "MIA -> MUC", "duration": 9}
1125899906843010	844424930132022	844424930132017	{"route": "DMM -> IST", "duration": 4.5}
1125899906843021	844424930131987	844424930131990	{"route": "ZRH -> BOG", "duration": 11.92}
1125899906842897	844424930132010	844424930131990	{"route": "NLU -> BOG", "duration": 4.5}
1125899906842974	844424930131980	844424930132013	{"route": "LAX -> HND", "duration": 12.293265306122448}
1125899906843019	844424930131977	844424930131989	{"route": "LHR -> SFO", "duration": 11.17}
1125899906842980	844424930131992	844424930131981	{"route": "MEX -> LAS", "duration": 4.131161825726141}
1125899906842933	844424930131992	844424930131974	{"route": "MEX -> FRA", "duration": 10.67}
1125899906843011	844424930131980	844424930131969	{"route": "LAX -> GRU", "duration": 11.83}
1125899906843051	844424930132010	844424930131983	{"route": "NLU -> DEN", "duration": 3.58}
1125899906842920	844424930131984	844424930132004	{"route": "DXB -> BER", "duration": 7}
1125899906842991	844424930132003	844424930132015	{"route": "PVG -> DMK", "duration": 4.763283582089552}
1125899906842911	844424930132017	844424930131995	{"route": "IST -> CMN", "duration": 5}
1125899906842921	844424930132006	844424930131978	{"route": "BKK -> MUC", "duration": 12.33}
1125899906842898	844424930132008	844424930132019	{"route": "SAW -> SSH", "duration": 2.58}
1125899906842942	844424930132018	844424930131987	{"route": "CPT -> ZRH", "duration": 11.5}
1125899906843036	844424930132018	844424930131978	{"route": "CPT -> MUC", "duration": 11.25}
1125899906842984	844424930132028	844424930131979	{"route": "DAL -> SEA", "duration": 4.5061333333333335}
1125899906842981	844424930132023	844424930131978	{"route": "PEK -> MUC", "duration": 11.223956834532373}
1125899906842950	844424930131970	844424930131999	{"route": "ATL -> ONT", "duration": 4.836760563380282}
1125899906843038	844424930132026	844424930131995	{"route": "ALG -> CMN", "duration": 2}
1125899906843014	844424930131994	844424930131977	{"route": "ORD -> LHR", "duration": 8.08}
1125899906842985	844424930132020	844424930131974	{"route": "NBO -> FRA", "duration": 9.08}
1125899906843031	844424930132019	844424930131987	{"route": "SSH -> ZRH", "duration": 4.875}
1125899906842940	844424930131994	844424930131978	{"route": "ORD -> MUC", "duration": 8.459807692307692}
1125899906842936	844424930131992	844424930131978	{"route": "MEX -> MUC", "duration": 10.75}
1125899906843045	844424930131975	844424930131987	{"route": "EWR -> ZRH", "duration": 7.58}
1125899906842919	844424930131971	844424930131989	{"route": "CLT -> SFO", "duration": 5.843788300835655}
1125899906843034	844424930131973	844424930131989	{"route": "MCO -> SFO", "duration": 6.510918367346939}
1125899906842903	844424930131989	844424930131978	{"route": "SFO -> MUC", "duration": 11.127388535031846}
1125899906842900	844424930131992	844424930131989	{"route": "MEX -> SFO", "duration": 5.0122857142857145}
1125899906843006	844424930131975	844424930131993	{"route": "EWR -> CDG", "duration": 7.279}
1125899906842962	844424930131990	844424930131987	{"route": "BOG -> ZRH", "duration": 12.9616}
1125899906842949	844424930131975	844424930131979	{"route": "EWR -> SEA", "duration": 6.9931592039801}
1125899906842955	844424930131992	844424930131972	{"route": "MEX -> JFK", "duration": 4.756746765249538}
1125899906842992	844424930131989	844424930131977	{"route": "SFO -> LHR", "duration": 10.58}
1125899906842941	844424930131971	844424930131980	{"route": "CLT -> LAX", "duration": 5.492292993630573}
1125899906842945	844424930131989	844424930131985	{"route": "SFO -> MIA", "duration": 5.516642156862745}
1125899906843028	844424930131969	844424930131987	{"route": "GRU -> ZRH", "duration": 11.227674418604652}
1125899906843026	844424930131974	844424930131984	{"route": "FRA -> DXB", "duration": 6.42}
1125899906842932	844424930131974	844424930132000	{"route": "FRA -> LOS", "duration": 6.5}
1125899906843055	844424930131975	844424930131977	{"route": "EWR -> LHR", "duration": 7.274779661016949}
1125899906843007	844424930131990	844424930131972	{"route": "BOG -> JFK", "duration": 5.848}
1125899906843003	844424930131990	844424930131974	{"route": "BOG -> FRA", "duration": 10.42}
1125899906842939	844424930131974	844424930132014	{"route": "FRA -> DEL", "duration": 7.863680981595092}
1125899906842996	844424930131974	844424930132023	{"route": "FRA -> PEK", "duration": 9.386859903381643}
1125899906842926	844424930131985	844424930131992	{"route": "MIA -> MEX", "duration": 3.846203703703704}
1125899906842896	844424930131974	844424930132026	{"route": "FRA -> ALG", "duration": 2.58}
1125899906843041	844424930131990	844424930131992	{"route": "BOG -> MEX", "duration": 4.8718887262079065}
1125899906842983	844424930131974	844424930131969	{"route": "FRA -> GRU", "duration": 12}
1125899906843012	844424930131974	844424930131975	{"route": "FRA -> EWR", "duration": 8.756631578947369}
1125899906842912	844424930132004	844424930131997	{"route": "BER -> ARN", "duration": 1.6971345029239766}
1125899906842977	844424930131989	844424930131975	{"route": "SFO -> EWR", "duration": 5.460010341261634}
1125899906842970	844424930131978	844424930132013	{"route": "MUC -> HND", "duration": 12.508292682926829}
1125899906843017	844424930131979	844424930131974	{"route": "SEA -> FRA", "duration": 10.17}
1125899906843002	844424930131974	844424930131986	{"route": "FRA -> MAD", "duration": 2.75}
1125899906842969	844424930131978	844424930132021	{"route": "MUC -> NCE", "duration": 1.5}
1125899906842988	844424930131974	844424930132001	{"route": "FRA -> FCO", "duration": 1.83}
1125899906842938	844424930131974	844424930132020	{"route": "FRA -> NBO", "duration": 8.5}
1125899906842906	844424930131974	844424930131998	{"route": "FRA -> AMS", "duration": 1.25}
1125899906843020	844424930131974	844424930131980	{"route": "FRA -> LAX", "duration": 11.67}
1125899906842925	844424930131974	844424930131990	{"route": "FRA -> BOG", "duration": 11.5}
1125899906842893	844424930131986	844424930131975	{"route": "MAD -> EWR", "duration": 8.92}
1125899906843032	844424930131974	844424930132029	{"route": "FRA -> QPP", "duration": 4.418127272727273}
1125899906843043	844424930131978	844424930132016	{"route": "MUC -> WAW", "duration": 1.5686909871244634}
1125899906843015	844424930131978	844424930131987	{"route": "MUC -> ZRH", "duration": 0.9354385964912281}
1125899906842931	844424930131974	844424930132027	{"route": "FRA -> ZMU", "duration": 3.4790967741935486}
1125899906842914	844424930131996	844424930131974	{"route": "OSL -> FRA", "duration": 2.33}
1125899906842998	844424930131977	844424930131975	{"route": "LHR -> EWR", "duration": 8.510201005025126}
1125899906842915	844424930132027	844424930131974	{"route": "ZMU -> FRA", "duration": 3.478835341365462}
1125899906843008	844424930131977	844424930131987	{"route": "LHR -> ZRH", "duration": 1.7963382594417077}
1125899906843005	844424930131978	844424930131977	{"route": "MUC -> LHR", "duration": 2.08}
1125899906843049	844424930131974	844424930131988	{"route": "FRA -> DFW", "duration": 11.33}
1125899906843025	844424930132005	844424930131975	{"route": "LIS -> EWR", "duration": 8.17}
1125899906842928	844424930131976	844424930131991	{"route": "VIE -> CAI", "duration": 3.42}
1125899906842924	844424930132001	844424930131976	{"route": "FCO -> VIE", "duration": 1.6587591240875912}
1125899906843044	844424930131982	844424930131987	{"route": "ATH -> ZRH", "duration": 2.9073061224489796}
1125899906842960	844424930131976	844424930132012	{"route": "VIE -> MRU", "duration": 10.25}
1125899906843039	844424930131976	844424930132021	{"route": "VIE -> NCE", "duration": 1.75}
1125899906842937	844424930131982	844424930131974	{"route": "ATH -> FRA", "duration": 3.1819184652278176}
1125899906842892	844424930131987	844424930131984	{"route": "ZRH -> DXB", "duration": 6.194186046511628}
1125899906842978	844424930131976	844424930131998	{"route": "VIE -> AMS", "duration": 1.92}
1125899906842916	844424930131987	844424930131989	{"route": "ZRH -> SFO", "duration": 12.17}
1125899906843054	844424930131976	844424930132016	{"route": "VIE -> WAW", "duration": 1.2515384615384615}
1125899906842973	844424930131976	844424930131993	{"route": "VIE -> CDG", "duration": 2.08}
1125899906842894	844424930131976	844424930131996	{"route": "VIE -> OSL", "duration": 2.33}
1125899906843035	844424930131987	844424930131985	{"route": "ZRH -> MIA", "duration": 10.742911392405063}
1125899906842890	844424930131987	844424930131969	{"route": "ZRH -> GRU", "duration": 11.965116279069768}
1125899906842971	844424930131987	844424930131996	{"route": "ZRH -> OSL", "duration": 2.5}
1125899906842965	844424930131976	844424930131987	{"route": "VIE -> ZRH", "duration": 1.3844992295839753}
1125899906842987	844424930132022	844424930131974	{"route": "DMM -> FRA", "duration": 8.5}
1125899906843018	844424930131987	844424930131982	{"route": "ZRH -> ATH", "duration": 2.6328979591836736}
1125899906843056	844424930132021	844424930131974	{"route": "NCE -> FRA", "duration": 1.67}
1125899906843000	844424930131987	844424930131998	{"route": "ZRH -> AMS", "duration": 1.686}
1125899906842929	844424930131993	844424930131975	{"route": "CDG -> EWR", "duration": 8.54872340425532}
1125899906842968	844424930132021	844424930131978	{"route": "NCE -> MUC", "duration": 1.42}
1125899906842993	844424930131987	844424930132018	{"route": "ZRH -> CPT", "duration": 11.459183673469388}
1125899906843042	844424930132021	844424930131987	{"route": "NCE -> ZRH", "duration": 1.245921568627451}
1125899906842895	844424930131984	844424930131974	{"route": "DXB -> FRA", "duration": 7.25}
1125899906842909	844424930132006	844424930131976	{"route": "BKK -> VIE", "duration": 11.58}
1125899906842976	844424930132013	844424930131979	{"route": "HND -> SEA", "duration": 9.20476821192053}
1125899906842953	844424930131993	844424930131974	{"route": "CDG -> FRA", "duration": 1.33}
1125899906843040	844424930132023	844424930131974	{"route": "PEK -> FRA", "duration": 10.519904306220095}
1125899906843052	844424930131981	844424930131973	{"route": "LAS -> MCO", "duration": 5.570651162790698}
1125899906843050	844424930131973	844424930131980	{"route": "MCO -> LAX", "duration": 5.979635568513119}
1125899906842935	844424930131994	844424930131992	{"route": "ORD -> MEX", "duration": 4.636021739130435}
1125899906843024	844424930131988	844424930131992	{"route": "DFW -> MEX", "duration": 2.8482931354359926}
1125899906843001	844424930131971	844424930131985	{"route": "CLT -> MIA", "duration": 2.1818992654774396}
1125899906842891	844424930131977	844424930131974	{"route": "LHR -> FRA", "duration": 1.58}
1125899906843033	844424930131971	844424930131988	{"route": "CLT -> DFW", "duration": 3.05046812749004}
1125899906843030	844424930131980	844424930131973	{"route": "LAX -> MCO", "duration": 5.465821917808219}
1125899906842956	844424930131985	844424930131980	{"route": "MIA -> LAX", "duration": 6.169544334975369}
1125899906842972	844424930131980	844424930131985	{"route": "LAX -> MIA", "duration": 4.940880579010856}
1125899906842923	844424930131974	844424930131976	{"route": "FRA -> VIE", "duration": 1.405122470713525}
1125899906842918	844424930132024	844424930131973	{"route": "EKW -> MCO", "duration": 3.4635521235521236}
1125899906842908	844424930131980	844424930131975	{"route": "LAX -> EWR", "duration": 5.273477443609023}
1125899906842922	844424930131981	844424930131975	{"route": "LAS -> EWR", "duration": 4.974247448979591}
1125899906842982	844424930132025	844424930131973	{"route": "AVT -> MCO", "duration": 3.143720930232558}
1125899906842930	844424930131981	844424930131989	{"route": "LAS -> SFO", "duration": 1.7539152119700747}
1125899906842917	844424930131985	844424930131988	{"route": "MIA -> DFW", "duration": 3.520721282279608}
1125899906843053	844424930131974	844424930131977	{"route": "FRA -> LHR", "duration": 1.75}
1125899906843061	844424930131996	844424930131997	{"route": "OSL -> ARN", "duration": 1.1348979591836734}
1125899906843062	844424930132014	844424930132013	{"route": "DEL -> HND", "duration": 7.5}
1125899906843071	844424930132010	844424930131988	{"route": "NLU -> DFW", "duration": 2.75}
1125899906843108	844424930132010	844424930131980	{"route": "NLU -> LAX", "duration": 3.92}
1125899906843110	844424930132022	844424930132008	{"route": "DMM -> SAW", "duration": 4.36}
1125899906843126	844424930131975	844424930131986	{"route": "EWR -> MAD", "duration": 7.42}
1125899906843186	844424930132006	844424930131987	{"route": "BKK -> ZRH", "duration": 12.25}
1125899906843180	844424930132013	844424930131980	{"route": "HND -> LAX", "duration": 10}
1125899906843177	844424930132008	844424930132022	{"route": "SAW -> DMM", "duration": 4.042197802197802}
1125899906843093	844424930132008	844424930131995	{"route": "SAW -> CMN", "duration": 5.08}
1125899906843078	844424930131991	844424930131974	{"route": "CAI -> FRA", "duration": 4.605896226415094}
1125899906843150	844424930132012	844424930131974	{"route": "MRU -> FRA", "duration": 12}
1125899906843097	844424930132017	844424930132022	{"route": "IST -> DMM", "duration": 4}
1125899906843133	844424930131988	844424930131969	{"route": "DFW -> GRU", "duration": 10.009887640449438}
1125899906843095	844424930131991	844424930131978	{"route": "CAI -> MUC", "duration": 4.08}
1125899906843109	844424930131995	844424930131974	{"route": "CMN -> FRA", "duration": 3.58}
1125899906843176	844424930131983	844424930131974	{"route": "DEN -> FRA", "duration": 9.61889705882353}
1125899906843160	844424930131971	844424930131978	{"route": "CLT -> MUC", "duration": 8.42}
1125899906843096	844424930131975	844424930131990	{"route": "EWR -> BOG", "duration": 5.83}
1125899906843173	844424930131983	844424930131978	{"route": "DEN -> MUC", "duration": 9.660096153846153}
1125899906843101	844424930131990	844424930131994	{"route": "BOG -> ORD", "duration": 6.25}
1125899906843136	844424930131981	844424930131999	{"route": "LAS -> ONT", "duration": 1.1341052631578947}
1125899906843138	844424930131973	844424930131969	{"route": "MCO -> GRU", "duration": 8.592631578947369}
1125899906843147	844424930131975	844424930132002	{"route": "EWR -> DUB", "duration": 6.75}
1125899906843183	844424930131992	844424930131973	{"route": "MEX -> MCO", "duration": 3.2186170212765957}
1125899906843122	844424930131999	844424930131983	{"route": "ONT -> DEN", "duration": 2.3404430379746834}
1125899906843112	844424930131973	844424930131979	{"route": "MCO -> SEA", "duration": 6.617191780821917}
1125899906843179	844424930131985	844424930131981	{"route": "MIA -> LAS", "duration": 5.689094922737307}
1125899906843164	844424930131999	844424930131979	{"route": "ONT -> SEA", "duration": 2.941122194513716}
1125899906843187	844424930131973	844424930131983	{"route": "MCO -> DEN", "duration": 4.489929577464789}
1125899906843178	844424930131981	844424930131985	{"route": "LAS -> MIA", "duration": 4.723972911963883}
1125899906843098	844424930131992	844424930131975	{"route": "MEX -> EWR", "duration": 4.774031007751938}
1125899906843073	844424930131979	844424930131975	{"route": "SEA -> EWR", "duration": 5.618727272727273}
1125899906843159	844424930131972	844424930131992	{"route": "JFK -> MEX", "duration": 5.7560877513711155}
1125899906843152	844424930131989	844424930131974	{"route": "SFO -> FRA", "duration": 10.982010050251256}
1125899906843120	844424930131979	844424930131972	{"route": "SEA -> JFK", "duration": 5.392463768115942}
1125899906843157	844424930131985	844424930131983	{"route": "MIA -> DEN", "duration": 4.7961873990306945}
1125899906843102	844424930131992	844424930131988	{"route": "MEX -> DFW", "duration": 2.733695238095238}
1125899906843103	844424930131990	844424930131988	{"route": "BOG -> DFW", "duration": 5.911882352941176}
1125899906843184	844424930131971	844424930131983	{"route": "CLT -> DEN", "duration": 3.823827751196172}
1125899906843057	844424930131985	844424930131973	{"route": "MIA -> MCO", "duration": 2.795451895043732}
1125899906843083	844424930131972	844424930131994	{"route": "JFK -> ORD", "duration": 2.8991917591125196}
1125899906843086	844424930131979	844424930131973	{"route": "SEA -> MCO", "duration": 5.6768432671081674}
1125899906843140	844424930131989	844424930131973	{"route": "SFO -> MCO", "duration": 5.362139037433155}
1125899906843134	844424930131990	844424930132010	{"route": "BOG -> NLU", "duration": 4.83}
1125899906843170	844424930131989	844424930131970	{"route": "SFO -> ATL", "duration": 4.886248175182482}
1125899906843188	844424930132009	844424930131989	{"route": "PAE -> SFO", "duration": 2.213}
1125899906843137	844424930131975	844424930131983	{"route": "EWR -> DEN", "duration": 4.440544959128065}
1125899906843113	844424930131972	844424930131971	{"route": "JFK -> CLT", "duration": 2.1984346701164297}
1125899906843080	844424930131985	844424930131971	{"route": "MIA -> CLT", "duration": 2.258604407135362}
1125899906843068	844424930131969	844424930131994	{"route": "GRU -> ORD", "duration": 10.67}
1125899906843107	844424930131973	844424930131994	{"route": "MCO -> ORD", "duration": 3.1067857142857145}
1125899906843059	844424930131975	844424930131988	{"route": "EWR -> DFW", "duration": 4.254813137032842}
1125899906843151	844424930131979	844424930131983	{"route": "SEA -> DEN", "duration": 2.7309153543307088}
1125899906843090	844424930131981	844424930131979	{"route": "LAS -> SEA", "duration": 2.984089795918367}
1125899906843119	844424930131969	844424930131975	{"route": "GRU -> EWR", "duration": 9.83}
1125899906843161	844424930131971	844424930131994	{"route": "CLT -> ORD", "duration": 2.2250968992248064}
1125899906843064	844424930131979	844424930131981	{"route": "SEA -> LAS", "duration": 2.756702302631579}
1125899906843154	844424930131969	844424930131974	{"route": "GRU -> FRA", "duration": 11.5}
1125899906843169	844424930131978	844424930132018	{"route": "MUC -> CPT", "duration": 11.25}
1125899906843065	844424930131974	844424930131989	{"route": "FRA -> SFO", "duration": 11.6037}
1125899906843088	844424930131978	844424930131983	{"route": "MUC -> DEN", "duration": 10.75}
1125899906843063	844424930131978	844424930131972	{"route": "MUC -> JFK", "duration": 8.83}
1125899906843081	844424930131975	844424930131980	{"route": "EWR -> LAX", "duration": 6.219639126305793}
1125899906843129	844424930131969	844424930131985	{"route": "GRU -> MIA", "duration": 8.425398671096346}
1125899906843167	844424930131978	844424930131985	{"route": "MUC -> MIA", "duration": 11.08}
1125899906843105	844424930131975	844424930131971	{"route": "EWR -> CLT", "duration": 2.124862700228833}
1125899906843117	844424930131975	844424930131989	{"route": "EWR -> SFO", "duration": 6.419172699069287}
1125899906843091	844424930131974	844424930132017	{"route": "FRA -> IST", "duration": 3.127061224489796}
1125899906843075	844424930131974	844424930131997	{"route": "FRA -> ARN", "duration": 2.17}
1125899906843165	844424930131978	844424930131971	{"route": "MUC -> CLT", "duration": 10}
1125899906843118	844424930131978	844424930131969	{"route": "MUC -> GRU", "duration": 12.5}
1125899906843181	844424930131998	844424930131994	{"route": "AMS -> ORD", "duration": 9.42}
1125899906843142	844424930131977	844424930131980	{"route": "LHR -> LAX", "duration": 11.33}
1125899906843121	844424930131978	844424930131986	{"route": "MUC -> MAD", "duration": 2.75}
1125899906843148	844424930131974	844424930131970	{"route": "FRA -> ATL", "duration": 10.5}
1125899906843070	844424930131996	844424930131976	{"route": "OSL -> VIE", "duration": 2.33}
1125899906843099	844424930131989	844424930132009	{"route": "SFO -> PAE", "duration": 2.2594202898550724}
1125899906843149	844424930131978	844424930132001	{"route": "MUC -> FCO", "duration": 1.5}
1125899906843185	844424930131978	844424930132005	{"route": "MUC -> LIS", "duration": 3.33}
1125899906843141	844424930131978	844424930131993	{"route": "MUC -> CDG", "duration": 1.67}
1125899906843125	844424930131975	844424930131985	{"route": "EWR -> MIA", "duration": 3.286294326241135}
1125899906843074	844424930132011	844424930131974	{"route": "MAN -> FRA", "duration": 1.75}
1125899906843182	844424930131978	844424930131976	{"route": "MUC -> VIE", "duration": 1.0531568228105905}
1125899906843162	844424930131998	844424930131987	{"route": "AMS -> ZRH", "duration": 1.470390804597701}
1125899906843124	844424930131982	844424930131976	{"route": "ATH -> VIE", "duration": 2.314950495049505}
1125899906843082	844424930131998	844424930131978	{"route": "AMS -> MUC", "duration": 1.33}
1125899906843106	844424930132005	844424930131987	{"route": "LIS -> ZRH", "duration": 2.8023157894736843}
1125899906843131	844424930132001	844424930131975	{"route": "FCO -> EWR", "duration": 10.25}
1125899906843175	844424930132004	844424930131978	{"route": "BER -> MUC", "duration": 1.17}
1125899906843114	844424930131978	844424930132004	{"route": "MUC -> BER", "duration": 1.17}
1125899906843079	844424930131993	844424930131994	{"route": "CDG -> ORD", "duration": 9.17}
1125899906843100	844424930131984	844424930131987	{"route": "DXB -> ZRH", "duration": 7.25}
1125899906843111	844424930132003	844424930131978	{"route": "PVG -> MUC", "duration": 12.948490566037735}
1125899906843171	844424930131993	844424930131976	{"route": "CDG -> VIE", "duration": 1.92}
1125899906842783	844424930132003	844424930132006	{"route": "PVG -> BKK", "duration": 4.912009803921569}
1125899906843158	844424930131976	844424930132011	{"route": "VIE -> MAN", "duration": 2.58}
1125899906843058	844424930131987	844424930131976	{"route": "ZRH -> VIE", "duration": 1.3433127889060092}
1125899906843163	844424930132018	844424930131974	{"route": "CPT -> FRA", "duration": 11.92}
1125899906843094	844424930131970	844424930131969	{"route": "ATL -> GRU", "duration": 9.488941176470588}
1125899906843146	844424930132006	844424930131984	{"route": "BKK -> DXB", "duration": 6.932}
1125899906843069	844424930132006	844424930132023	{"route": "BKK -> PEK", "duration": 4.599349775784753}
1125899906843130	844424930132022	844424930131984	{"route": "DMM -> DXB", "duration": 1.4150847457627118}
1125899906843139	844424930131984	844424930132022	{"route": "DXB -> DMM", "duration": 1.529491525423729}
1125899906843189	844424930131988	844424930131972	{"route": "DFW -> JFK", "duration": 3.5212814645308925}
1125899906843077	844424930131985	844424930131970	{"route": "MIA -> ATL", "duration": 2.1085896527285612}
1125899906843084	844424930132019	844424930131991	{"route": "SSH -> CAI", "duration": 1.4486612021857923}
1125899906843145	844424930131983	844424930131975	{"route": "DEN -> EWR", "duration": 3.6949798115746972}
1125899906843060	844424930132006	844424930132003	{"route": "BKK -> PVG", "duration": 4.338572938689218}
1125899906843127	844424930131988	844424930131989	{"route": "DFW -> SFO", "duration": 4.134835630965005}
1125899906843132	844424930131983	844424930131994	{"route": "DEN -> ORD", "duration": 2.5684205607476636}
1125899906843144	844424930131970	844424930131981	{"route": "ATL -> LAS", "duration": 4.611636178861788}
1125899906842958	844424930131981	844424930131988	{"route": "LAS -> DFW", "duration": 2.756765988372093}
1125899906843143	844424930131983	844424930131989	{"route": "DEN -> SFO", "duration": 2.8509135559921415}
1125899906843172	844424930131980	844424930131970	{"route": "LAX -> ATL", "duration": 4.405797430083145}
1125899906843156	844424930131994	844424930131985	{"route": "ORD -> MIA", "duration": 3.2939712488769093}
1125899906843168	844424930131989	844424930131972	{"route": "SFO -> JFK", "duration": 5.574079568442347}
1125899906842751	844424930131988	844424930131994	{"route": "DFW -> ORD", "duration": 2.433995983935743}
1125899906843092	844424930131975	844424930131994	{"route": "EWR -> ORD", "duration": 2.670874655647383}
1125899906843066	844424930131994	844424930131988	{"route": "ORD -> DFW", "duration": 2.74165327978581}
1125899906843089	844424930131972	844424930131989	{"route": "JFK -> SFO", "duration": 6.721675531914894}
1125899906843135	844424930131994	844424930131975	{"route": "ORD -> EWR", "duration": 2.2505502717391304}
1125899906843174	844424930131989	844424930131980	{"route": "SFO -> LAX", "duration": 1.5393342036553526}
1125899906843206	844424930131969	844424930131988	{"route": "GRU -> DFW", "duration": 10.482325581395349}
1125899906843218	844424930131969	844424930131992	{"route": "GRU -> MEX", "duration": 9.307777777777778}
1125899906842913	844424930131970	844424930131983	{"route": "ATL -> DEN", "duration": 3.486002004008016}
1125899906843214	844424930131985	844424930131975	{"route": "MIA -> EWR", "duration": 3.197027027027027}
1125899906843211	844424930131974	844424930131978	{"route": "FRA -> MUC", "duration": 0.92}
1125899906842865	844424930131983	844424930131981	{"route": "DEN -> LAS", "duration": 2.111155015197568}
1125899906843227	844424930131970	844424930131980	{"route": "ATL -> LAX", "duration": 5.117488151658768}
1125899906843207	844424930131974	844424930131996	{"route": "FRA -> OSL", "duration": 2.08}
1125899906843226	844424930131978	844424930131991	{"route": "MUC -> CAI", "duration": 3.7001449275362317}
1125899906843212	844424930131978	844424930131996	{"route": "MUC -> OSL", "duration": 2.33}
1125899906843217	844424930132004	844424930131984	{"route": "BER -> DXB", "duration": 6.33}
1125899906843203	844424930131994	844424930131989	{"route": "ORD -> SFO", "duration": 4.868965853658537}
1125899906843199	844424930131994	844424930131990	{"route": "ORD -> BOG", "duration": 5.83}
1125899906843215	844424930131994	844424930131987	{"route": "ORD -> ZRH", "duration": 8.67}
1125899906843193	844424930131998	844424930131976	{"route": "AMS -> VIE", "duration": 1.83}
1125899906843221	844424930131997	844424930131978	{"route": "ARN -> MUC", "duration": 2.25}
1125899906842948	844424930131985	844424930131990	{"route": "MIA -> BOG", "duration": 3.706816143497758}
1125899906843196	844424930132017	844424930132003	{"route": "IST -> PVG", "duration": 10.375}
1125899906843197	844424930132021	844424930132004	{"route": "NCE -> BER", "duration": 2}
1125899906843198	844424930132010	844424930131985	{"route": "NLU -> MIA", "duration": 3.08}
1125899906843202	844424930131970	844424930131973	{"route": "ATL -> MCO", "duration": 1.5333497840838988}
1125899906843192	844424930132028	844424930131970	{"route": "DAL -> ATL", "duration": 2.0114683544303795}
1125899906842815	844424930131980	844424930131981	{"route": "LAX -> LAS", "duration": 1.258544061302682}
1125899906843195	844424930131980	844424930131978	{"route": "LAX -> MUC", "duration": 11.218395061728396}
1125899906843220	844424930131993	844424930131989	{"route": "CDG -> SFO", "duration": 11.42}
1125899906843224	844424930131980	844424930131977	{"route": "LAX -> LHR", "duration": 10.5}
1125899906843223	844424930131971	844424930131973	{"route": "CLT -> MCO", "duration": 1.7807609594706368}
1125899906843216	844424930131992	844424930131994	{"route": "MEX -> ORD", "duration": 4.209670329670329}
1125899906843219	844424930131979	844424930131970	{"route": "SEA -> ATL", "duration": 4.805994020926756}
1125899906843208	844424930131979	844424930132028	{"route": "SEA -> DAL", "duration": 3.9524324324324325}
1125899906842741	844424930131988	844424930131999	{"route": "DFW -> ONT", "duration": 3.384958217270195}
1125899906842904	844424930131988	844424930131980	{"route": "DFW -> LAX", "duration": 3.5082756079587325}
1125899906843200	844424930131978	844424930131989	{"route": "MUC -> SFO", "duration": 11.960764331210191}
1125899906843222	844424930131979	844424930131994	{"route": "SEA -> ORD", "duration": 4.401464435146443}
1125899906843204	844424930132009	844424930131980	{"route": "PAE -> LAX", "duration": 2.823030303030303}
1125899906843225	844424930131979	844424930131999	{"route": "SEA -> ONT", "duration": 2.641965811965812}
1125899906843191	844424930131988	844424930131985	{"route": "DFW -> MIA", "duration": 2.9001675485008818}
1125899906843213	844424930131976	844424930131978	{"route": "VIE -> MUC", "duration": 1.0011958762886597}
1125899906843209	844424930131976	844424930131977	{"route": "VIE -> LHR", "duration": 2.4453125}
1125899906843201	844424930131987	844424930131980	{"route": "ZRH -> LAX", "duration": 12.33}
1125899906843205	844424930131987	844424930132005	{"route": "ZRH -> LIS", "duration": 2.988947368421053}
1125899906842797	844424930132006	844424930132013	{"route": "BKK -> HND", "duration": 5.659407540394973}
1125899906843194	844424930132017	844424930132019	{"route": "IST -> SSH", "duration": 2.7076470588235293}
1125899906843190	844424930132014	844424930131974	{"route": "DEL -> FRA", "duration": 9.156363636363636}
1125899906843210	844424930132026	844424930131974	{"route": "ALG -> FRA", "duration": 2.75}
1125899906842672	844424930131988	844424930131971	{"route": "DFW -> CLT", "duration": 2.542199211045365}
1125899906842888	844424930131988	844424930131981	{"route": "DFW -> LAS", "duration": 3.094769114307343}
1125899906842764	844424930131972	844424930131981	{"route": "JFK -> LAS", "duration": 5.995967213114754}
1125899906842905	844424930131979	844424930131989	{"route": "SEA -> SFO", "duration": 2.3009140148950573}
1125899906842626	844424930131971	844424930131972	{"route": "CLT -> JFK", "duration": 1.9645597897503284}
1125899906842777	844424930131980	844424930131988	{"route": "LAX -> DFW", "duration": 3.0983760683760684}
1125899906842994	844424930131984	844424930132014	{"route": "DXB -> DEL", "duration": 3.2189513108614234}
1125899906842849	844424930132023	844424930132006	{"route": "PEK -> BKK", "duration": 5.322406015037594}
1125899906842736	844424930131970	844424930131975	{"route": "ATL -> EWR", "duration": 2.2223655913978493}
1125899906842907	844424930131988	844424930131973	{"route": "DFW -> MCO", "duration": 2.66}
1125899906842631	844424930131971	844424930131981	{"route": "CLT -> LAS", "duration": 5.024735849056603}
1125899906842640	844424930131990	844424930131985	{"route": "BOG -> MIA", "duration": 3.947587719298246}
1125899906842647	844424930131976	844424930131994	{"route": "VIE -> ORD", "duration": 10.17}
1125899906842658	844424930132000	844424930131974	{"route": "LOS -> FRA", "duration": 6.58}
1125899906842644	844424930131992	844424930131969	{"route": "MEX -> GRU", "duration": 9.57788888888889}
1125899906842713	844424930131981	844424930131980	{"route": "LAS -> LAX", "duration": 1.3320052424639581}
1125899906842699	844424930131983	844424930131970	{"route": "DEN -> ATL", "duration": 2.951144578313253}
1125899906842655	844424930131999	844424930131988	{"route": "ONT -> DFW", "duration": 2.971748878923767}
1125899906842683	844424930131974	844424930132005	{"route": "FRA -> LIS", "duration": 3.2202449888641427}
1125899906842638	844424930131988	844424930131979	{"route": "DFW -> SEA", "duration": 4.500838272650296}
1125899906842678	844424930131988	844424930131990	{"route": "DFW -> BOG", "duration": 5.33}
1125899906842702	844424930131973	844424930131985	{"route": "MCO -> MIA", "duration": 2.7176543209876542}
1125899906842665	844424930131994	844424930131983	{"route": "ORD -> DEN", "duration": 2.8278691588785048}
1125899906842990	844424930131988	844424930131970	{"route": "DFW -> ATL", "duration": 2.178818181818182}
1125899906842855	844424930131984	844424930131978	{"route": "DXB -> MUC", "duration": 6.75}
1125899906842684	844424930131976	844424930132006	{"route": "VIE -> BKK", "duration": 10.08}
1125899906842689	844424930132008	844424930131974	{"route": "SAW -> FRA", "duration": 3.3777096774193547}
1125899906842718	844424930132013	844424930131974	{"route": "HND -> FRA", "duration": 14.674466403162056}
1125899906842720	844424930132014	844424930131978	{"route": "DEL -> MUC", "duration": 8.92}
1125899906842676	844424930131980	844424930131989	{"route": "LAX -> SFO", "duration": 1.5073705447209147}
1125899906842650	844424930131983	844424930131973	{"route": "DEN -> MCO", "duration": 3.9198885793871865}
1125899906842710	844424930131998	844424930131974	{"route": "AMS -> FRA", "duration": 1.17}
1125899906842691	844424930131977	844424930131994	{"route": "LHR -> ORD", "duration": 9.42}
1125899906843166	844424930132003	844424930131974	{"route": "PVG -> FRA", "duration": 13.288407643312102}
1125899906843115	844424930131983	844424930131999	{"route": "DEN -> ONT", "duration": 2.454090909090909}
1125899906843087	844424930131997	844424930131974	{"route": "ARN -> FRA", "duration": 2.25}
1125899906843128	844424930132002	844424930131975	{"route": "DUB -> EWR", "duration": 7.83}
1125899906843067	844424930132005	844424930131978	{"route": "LIS -> MUC", "duration": 3.1815}
1125899906843104	844424930131987	844424930131986	{"route": "ZRH -> MAD", "duration": 2.42}
1125899906843155	844424930132001	844424930131978	{"route": "FCO -> MUC", "duration": 1.58}
1125899906843076	844424930131987	844424930131997	{"route": "ZRH -> ARN", "duration": 2.449260700389105}
1125899906843123	844424930132016	844424930131976	{"route": "WAW -> VIE", "duration": 1.331831501831502}
1125899906843085	844424930132016	844424930131978	{"route": "WAW -> MUC", "duration": 1.6972451193058569}
1125899906843116	844424930132016	844424930131974	{"route": "WAW -> FRA", "duration": 1.9695019157088123}
1125899906843072	844424930132021	844424930131976	{"route": "NCE -> VIE", "duration": 1.67}
1125899906843153	844424930131987	844424930132016	{"route": "ZRH -> WAW", "duration": 1.895787037037037}
\.


--
-- Data for Name: _ag_label_edge; Type: TABLE DATA; Schema: flight_routes; Owner: dst_graph_designer
--

COPY flight_routes._ag_label_edge (id, start_id, end_id, properties) FROM stdin;
\.


--
-- Data for Name: _ag_label_vertex; Type: TABLE DATA; Schema: flight_routes; Owner: dst_graph_designer
--

COPY flight_routes._ag_label_vertex (id, properties) FROM stdin;
\.


--
-- Data for Name: scheduled_routes; Type: TABLE DATA; Schema: l3; Owner: dst_graph_designer
--

COPY l3.scheduled_routes (departure_airport_code, arrival_airport_code, avg_flight_duration_hours) FROM stdin;
\.


--
-- Data for Name: scheduled_routes; Type: TABLE DATA; Schema: public; Owner: dst_graph_designer
--

COPY public.scheduled_routes (departure_airport_code, arrival_airport_code, avg_flight_duration_hours) FROM stdin;
DEN	LHR	9.0800000000000000
LHR	ORD	9.4200000000000000
SFO	SEA	2.3310268456375839
LAX	JFK	5.4659493670886076
LAX	SEA	3.1514096573208723
ATL	DAL	2.3139142091152815
ATL	DFW	2.6727877428998505
DEN	LAX	2.6271766444937177
JFK	ATL	2.6386344969199179
ZRH	MRU	11.7297297297297297
ORD	JFK	2.3611900532859680
MUC	AMS	1.6700000000000000
ORD	GRU	10.2500000000000000
ORD	CDG	8.0800000000000000
ZRH	MUC	0.93354330708661417323
ATL	BOG	4.6730094043887147
FRA	SAW	3.1199022801302932
FRA	MIA	10.4200000000000000
MAN	ZRH	1.9637500000000000
ONT	DFW	2.9717488789237668
ZRH	LHR	1.8671428571428571
LAX	PAE	2.9694545454545455
ZRH	DUB	2.4171250000000000
OSL	MUC	2.4092857142857143
ATL	ORD	2.1610775510204082
ARN	VIE	2.2500000000000000
MAD	ZRH	2.2886754966887417
DEN	DFW	2.0705539143279173
LAX	ORD	4.1538000000000000
MAD	FRA	2.5800000000000000
FRA	LAS	11.7500000000000000
BER	ZRH	1.4754838709677419
AGY	FRA	3.2040000000000000
ORD	LAX	4.6341074983410750
JFK	MCO	3.0768575974542562
ORD	NLU	4.2500000000000000
NLU	ORD	4.0800000000000000
AMS	FRA	1.1700000000000000
MRU	VIE	10.8300000000000000
AMS	EWR	8.4200000000000000
PVG	VIE	12.9200000000000000
LAX	ZRH	11.0800000000000000
JFK	MUC	7.5000000000000000
LAX	FRA	10.9200000000000000
JFK	VIE	8.2500000000000000
MUC	SEA	10.6700000000000000
FCO	ORD	10.3300000000000000
MUC	LAX	12.2180000000000000
MUC	PEK	9.9156934306569343
MEX	CLT	3.7565882352941176
CLT	MEX	4.4432558139534884
MCO	NLU	3.4200000000000000
MUC	DUB	2.5800000000000000
ONT	ORD	6.1715789473684211
SEA	MEX	5.5493023255813953
DEN	NLU	3.5800000000000000
MRU	NBO	4.2553333333333333
LAX	NLU	3.6700000000000000
DEN	MEX	3.9506201550387597
MUC	MAN	2.2500000000000000
MIA	ZRH	9.0774683544303797
VIE	PVG	11.0800000000000000
EWR	GRU	9.5000000000000000
EWR	MUC	7.7077611940298507
ONT	CLT	4.9250793650793651
MIA	SFO	6.7974772727272727
SEA	MIA	6.0178498293515358
ORD	VIE	8.7500000000000000
CLT	ONT	5.1933333333333333
MIA	NLU	3.4200000000000000
MIA	SEA	6.9242700729927007
ORD	FCO	8.9200000000000000
NLU	MCO	3.0800000000000000
DEN	SEA	3.3827879341864717
MCO	ATL	1.6547253433208489
GRU	ATL	9.9330952380952381
ORD	ATL	2.0779803761242845
BKK	DEL	4.6049275362318841
QPP	FRA	4.4519693094629156
BER	FRA	1.2500000000000000
ATL	MIA	1.9985080928923293
JFK	DEN	4.7187186629526462
DFW	DEN	2.2179047619047619
DXB	BKK	6.0840000000000000
IST	FRA	3.3772819472616633
ORD	MCO	2.9202690972222222
JFK	LAX	6.3755178365937860
MCO	EWR	2.7586817102137767
ATL	CLT	1.2751012145748988
DFW	LAS	3.0947691143073429
JFK	LAS	5.9959672131147541
SEA	SFO	2.3009140148950575
CLT	JFK	1.9645597897503285
LAX	DFW	3.0983760683760684
DXB	DEL	3.2189513108614232
PEK	BKK	5.3224060150375940
ATL	EWR	2.2223655913978495
DFW	MCO	2.6600000000000000
ATL	SEA	5.7502212389380531
DFW	SEA	4.5008382726502964
ZRH	CDG	1.3630395136778116
CDG	MUC	1.4200000000000000
FCO	ZRH	1.6116216216216216
DXB	MUC	6.7500000000000000
SAW	FRA	3.3777096774193548
DEL	MUC	8.9200000000000000
CLT	SEA	5.9249790794979079
LAS	FRA	11.0000000000000000
EWR	MEX	5.6576744186046512
IST	LOS	7.2500000000000000
DEL	ZRH	9.0800000000000000
CAI	ZRH	4.1700000000000000
MRU	ZRH	12.2848648648648649
ATL	FRA	8.7500000000000000
ONT	SFO	1.5734387351778656
DFW	FRA	9.8300000000000000
EWR	FRA	7.4628421052631579
MEX	ATL	3.4093925233644860
LAS	CLT	4.2526591760299625
EWR	AMS	7.1700000000000000
EWR	LIS	6.5800000000000000
EWR	FCO	8.5800000000000000
JFK	SEA	6.4801785714285714
MEX	LAX	4.3192268041237113
SFO	ONT	1.4951063829787234
MEX	MIA	3.2490018484288355
SFO	ZRH	11.0800000000000000
BOG	EWR	6.0329523809523810
GRU	MUC	11.5800000000000000
GRU	MCO	9.0000000000000000
SFO	MEX	4.3931208791208791
FRA	DMM	7.5800000000000000
FRA	CPT	11.6700000000000000
FRA	DEN	10.5895522388059701
MEX	BOG	4.5562957540263543
GRU	JFK	9.9621052631578947
SFO	ORD	4.3554921259842520
FRA	HND	13.0140000000000000
EWR	LAS	5.7253543307086614
FRA	CAI	4.1529523809523810
FRA	ORD	9.4961454545454545
FRA	JFK	8.9768595041322314
FRA	MEX	12.3300000000000000
SFO	DEN	2.6730486593843098
FRA	NCE	1.5800000000000000
MAN	MUC	1.9200000000000000
FRA	MAN	1.8300000000000000
FRA	ATH	2.7821153846153846
FRA	MRU	11.2500000000000000
FRA	DUB	2.1700000000000000
FRA	WAW	1.6999778270509978
FRA	CDG	1.2500000000000000
ARN	BER	1.5800000000000000
ARN	OSL	1.0259288537549407
FRA	SEA	10.8300000000000000
MAD	MUC	2.5800000000000000
VIE	ATH	2.1530693069306931
WAW	ZRH	2.0854166666666667
LIS	FRA	3.1328285077951002
FCO	FRA	2.0000000000000000
ATH	MUC	2.7125000000000000
VIE	FCO	1.5826277372262774
ZRH	PVG	12.2500000000000000
ZRH	BKK	10.6700000000000000
ZRH	DEL	7.7500000000000000
ZRH	EWR	9.2500000000000000
ZRH	JFK	9.3354970760233918
PVG	ZRH	14.3300000000000000
ZRH	MAN	2.0930526315789474
DUB	MUC	2.2500000000000000
ZRH	FCO	1.5595515695067265
ZRH	NCE	1.1969803921568627
DUB	FRA	2.0000000000000000
DUB	ZRH	2.1700000000000000
ZRH	FRA	1.0916742081447964
DMK	PVG	4.0800000000000000
ZRH	SSH	5.1650000000000000
HND	MUC	14.6820481927710843
ZRH	BER	1.4724114441416894
CMN	SAW	4.7766666666666667
DEL	BKK	3.9745054945054945
ORD	FRA	8.4372826086956522
JFK	DFW	4.2297247706422018
JFK	GRU	9.5755387931034483
LAX	MEX	3.7387436332767402
LAX	CLT	4.8326893353941267
ATL	SFO	5.4398628048780488
DEN	MIA	4.1230806451612903
CLT	EWR	1.9072311212814645
MCO	AVT	3.0736687631027254
ORD	SEA	4.8057929515418502
MCO	EKW	3.4791224018475751
DFW	EWR	3.3752613636363636
ORD	LAS	4.4213228492136910
MCO	DFW	3.1519789842381786
SEA	DFW	3.9535677966101695
LAS	ATL	3.9391683366733467
FRA	BER	1.1700000000000000
VIE	FRA	1.4925026624068158
MCO	JFK	2.6897591362126246
ORD	CLT	2.0741074856046065
MIA	ORD	3.6469723953695459
MIA	JFK	3.0697184231697506
MCO	CLT	1.8396505823627288
JFK	FRA	7.6929508196721311
DFW	NLU	2.6700000000000000
LAS	PAE	2.8593793103448276
MUC	MEX	13.0000000000000000
MIA	FRA	9.0000000000000000
ONT	ATL	4.1391162790697674
EWR	ATH	9.5000000000000000
BER	EWR	9.3300000000000000
LHR	DEN	9.8300000000000000
MUC	DEL	7.4200000000000000
SFO	CDG	10.7500000000000000
MUC	EWR	9.1014814814814815
BER	NCE	2.0000000000000000
MEX	SEA	6.0485882352941176
OSL	ZRH	2.5935000000000000
ORD	ONT	8.7600000000000000
MEX	DEN	3.9510937500000000
ORD	AMS	8.4200000000000000
ONT	LAS	1.1867605633802817
FRA	AGY	2.9566666666666667
LAS	MEX	3.8037448559670782
JFK	ZRH	7.7097687861271676
MEX	IST	15.9107339449541284
MIA	MUC	9.0000000000000000
DMM	IST	4.5000000000000000
ZRH	BOG	11.9200000000000000
NLU	BOG	4.5000000000000000
LAX	HND	12.2932653061224490
LHR	SFO	11.1700000000000000
MEX	LAS	4.1311618257261411
MEX	FRA	10.6700000000000000
LAX	GRU	11.8300000000000000
NLU	DEN	3.5800000000000000
DXB	BER	7.0000000000000000
PVG	DMK	4.7632835820895522
IST	CMN	5.0000000000000000
BKK	MUC	12.3300000000000000
SAW	SSH	2.5800000000000000
CPT	ZRH	11.5000000000000000
CPT	MUC	11.2500000000000000
DAL	SEA	4.5061333333333333
PEK	MUC	11.2239568345323741
ALG	CMN	2.0000000000000000
ORD	LHR	8.0800000000000000
NBO	FRA	9.0800000000000000
SSH	ZRH	4.8750000000000000
ORD	MUC	8.4598076923076923
MEX	MUC	10.7500000000000000
EWR	ZRH	7.5800000000000000
CLT	SFO	5.8437883008356546
MCO	SFO	6.5109183673469388
SFO	MUC	11.1273885350318471
MEX	SFO	5.0122857142857143
EWR	CDG	7.2790000000000000
BOG	ZRH	12.9616000000000000
EWR	SEA	6.9931592039800995
MEX	JFK	4.7567467652495379
SFO	LHR	10.5800000000000000
CLT	LAX	5.4922929936305732
SFO	MIA	5.5166421568627451
GRU	ZRH	11.2276744186046512
FRA	DXB	6.4200000000000000
FRA	LOS	6.5000000000000000
EWR	LHR	7.2747796610169492
BOG	JFK	5.8480000000000000
BOG	FRA	10.4200000000000000
FRA	DEL	7.8636809815950920
FRA	PEK	9.3868599033816425
MIA	MEX	3.8462037037037037
FRA	ALG	2.5800000000000000
BOG	MEX	4.8718887262079063
FRA	GRU	12.0000000000000000
FRA	EWR	8.7566315789473684
BER	ARN	1.6971345029239766
SFO	EWR	5.4600103412616339
MUC	HND	12.5082926829268293
SEA	FRA	10.1700000000000000
FRA	MAD	2.7500000000000000
MUC	NCE	1.5000000000000000
FRA	FCO	1.8300000000000000
FRA	NBO	8.5000000000000000
FRA	AMS	1.2500000000000000
FRA	LAX	11.6700000000000000
FRA	BOG	11.5000000000000000
MAD	EWR	8.9200000000000000
FRA	QPP	4.4181272727272727
MUC	WAW	1.5686909871244635
MUC	ZRH	0.93543859649122807018
FRA	ZMU	3.4790967741935484
OSL	FRA	2.3300000000000000
LHR	EWR	8.5102010050251256
ZMU	FRA	3.4788353413654618
LHR	ZRH	1.7963382594417077
MUC	LHR	2.0800000000000000
FRA	DFW	11.3300000000000000
LIS	EWR	8.1700000000000000
VIE	CAI	3.4200000000000000
FCO	VIE	1.6587591240875912
ATH	ZRH	2.9073061224489796
VIE	MRU	10.2500000000000000
VIE	NCE	1.7500000000000000
ATH	FRA	3.1819184652278177
ZRH	DXB	6.1941860465116279
VIE	AMS	1.9200000000000000
ZRH	SFO	12.1700000000000000
VIE	WAW	1.2515384615384615
VIE	CDG	2.0800000000000000
VIE	OSL	2.3300000000000000
ZRH	MIA	10.7429113924050633
ZRH	GRU	11.9651162790697674
ZRH	OSL	2.5000000000000000
DMM	FRA	8.5000000000000000
ZRH	CPT	11.4591836734693878
NCE	ZRH	1.2459215686274510
DXB	FRA	7.2500000000000000
BKK	VIE	11.5800000000000000
HND	SEA	9.2047682119205298
CDG	FRA	1.3300000000000000
PEK	FRA	10.5199043062200957
LAS	MCO	5.5706511627906977
MCO	LAX	5.9796355685131195
DFW	MEX	2.8482931354359926
CLT	MIA	2.1818992654774397
LHR	FRA	1.5800000000000000
CLT	DFW	3.0504681274900398
MIA	LAX	6.1695443349753695
FRA	VIE	1.4051224707135250
EKW	MCO	3.4635521235521236
LAX	EWR	5.2734774436090226
LAS	EWR	4.9742474489795918
AVT	MCO	3.1437209302325581
LAS	SFO	1.7539152119700748
FRA	LHR	1.7500000000000000
BOG	ORD	6.2500000000000000
SFO	FRA	10.9820100502512563
SFO	MCO	5.3621390374331551
BOG	NLU	4.8300000000000000
SFO	ATL	4.8862481751824818
EWR	DEN	4.4405449591280654
GRU	ORD	10.6700000000000000
EWR	DFW	4.2548131370328426
SEA	DEN	2.7309153543307087
GRU	EWR	9.8300000000000000
SEA	LAS	2.7567023026315789
GRU	FRA	11.5000000000000000
MUC	CPT	11.2500000000000000
FRA	SFO	11.6037000000000000
MUC	DEN	10.7500000000000000
MUC	JFK	8.8300000000000000
EWR	LAX	6.2196391263057930
GRU	MIA	8.4253986710963455
MUC	MIA	11.0800000000000000
EWR	CLT	2.1248627002288330
EWR	SFO	6.4191726990692865
FRA	IST	3.1270612244897959
FRA	ARN	2.1700000000000000
MUC	CLT	10.0000000000000000
MUC	GRU	12.5000000000000000
AMS	ORD	9.4200000000000000
LHR	LAX	11.3300000000000000
MUC	MAD	2.7500000000000000
FRA	ATL	10.5000000000000000
OSL	VIE	2.3300000000000000
MUC	FCO	1.5000000000000000
MUC	LIS	3.3300000000000000
MUC	CDG	1.6700000000000000
EWR	MIA	3.2862943262411348
MAN	FRA	1.7500000000000000
ATL	ONT	4.8367605633802817
VIE	ZRH	1.3844992295839753
ZRH	ATH	2.6328979591836735
NCE	FRA	1.6700000000000000
ZRH	AMS	1.6860000000000000
CDG	EWR	8.5487234042553191
NCE	MUC	1.4200000000000000
ORD	MEX	4.6360217391304348
LAX	MCO	5.4658219178082192
MIA	DFW	3.5207212822796082
MUC	VIE	1.0531568228105906
AMS	ZRH	1.4703908045977011
ATH	VIE	2.3149504950495050
AMS	MUC	1.3300000000000000
ARN	FRA	2.2500000000000000
LIS	ZRH	2.8023157894736842
FCO	EWR	10.2500000000000000
BER	MUC	1.1700000000000000
MUC	BER	1.1700000000000000
DUB	EWR	7.8300000000000000
LIS	MUC	3.1815000000000000
ZRH	MAD	2.4200000000000000
FCO	MUC	1.5800000000000000
ZRH	ARN	2.4492607003891051
WAW	VIE	1.3318315018315018
WAW	MUC	1.6972451193058568
WAW	FRA	1.9695019157088123
NCE	VIE	1.6700000000000000
ZRH	WAW	1.8957870370370370
CDG	ORD	9.1700000000000000
DXB	ZRH	7.2500000000000000
PVG	MUC	12.9484905660377358
CDG	VIE	1.9200000000000000
PVG	BKK	4.9120098039215686
VIE	MAN	2.5800000000000000
ZRH	VIE	1.3433127889060092
CPT	FRA	11.9200000000000000
ATL	GRU	9.4889411764705882
BKK	DXB	6.9320000000000000
BKK	PEK	4.5993497757847534
DMM	DXB	1.4150847457627119
DXB	DMM	1.5294915254237288
DFW	JFK	3.5212814645308924
SSH	CAI	1.4486612021857923
DEN	EWR	3.6949798115746972
BKK	PVG	4.3385729386892178
DFW	SFO	4.1348356309650053
DEN	ORD	2.5684205607476636
ATL	LAS	4.6116361788617886
SFO	JFK	5.5740795684423466
DFW	ORD	2.4339959839357430
EWR	ORD	2.6708746556473829
ORD	EWR	2.2505502717391304
SFO	LAX	1.5393342036553525
GRU	DFW	10.4823255813953488
GRU	MEX	9.3077777777777778
ATL	DEN	3.4860020040080160
MIA	EWR	3.1970270270270270
FRA	MUC	0.92000000000000000000
DEN	LAS	2.1111550151975684
ATL	LAX	5.1174881516587678
FRA	OSL	2.0800000000000000
MUC	CAI	3.7001449275362319
MUC	OSL	2.3300000000000000
BER	DXB	6.3300000000000000
ORD	SFO	4.8689658536585366
ORD	BOG	5.8300000000000000
ORD	ZRH	8.6700000000000000
AMS	VIE	1.8300000000000000
ARN	MUC	2.2500000000000000
MIA	BOG	3.7068161434977578
IST	PVG	10.3750000000000000
NCE	BER	2.0000000000000000
NLU	MIA	3.0800000000000000
ATL	MCO	1.5333497840838988
DAL	ATL	2.0114683544303797
LAX	LAS	1.2585440613026820
LAX	MUC	11.2183950617283951
CDG	SFO	11.4200000000000000
LAX	LHR	10.5000000000000000
CLT	MCO	1.7807609594706369
MEX	ORD	4.2096703296703297
SEA	ATL	4.8059940209267564
SEA	DAL	3.9524324324324324
DFW	ONT	3.3849582172701950
DFW	LAX	3.5082756079587325
MUC	SFO	11.9607643312101911
SEA	ORD	4.4014644351464435
PAE	LAX	2.8230303030303030
SEA	ONT	2.6419658119658120
DFW	MIA	2.9001675485008818
VIE	MUC	1.00119587628865979381
VIE	LHR	2.4453125000000000
ZRH	LAX	12.3300000000000000
ZRH	LIS	2.9889473684210526
BKK	HND	5.6594075403949731
IST	SSH	2.7076470588235294
DEL	FRA	9.1563636363636364
ALG	FRA	2.7500000000000000
ARN	ZRH	2.4440000000000000
FRA	MCO	10.7500000000000000
MUC	ARN	2.2500000000000000
MUC	ATH	2.4575280898876404
FRA	ZRH	0.95113122171945701357
BER	VIE	1.2527223230490018
VIE	JFK	9.7500000000000000
LIS	MAD	1.4110743801652893
EWR	MCO	3.0773784104389087
EWR	BER	8.0800000000000000
DFW	CLT	2.5421992110453649
EWR	VIE	8.0988372093023256
MCO	LAS	6.4438431372549020
CLT	LAS	5.0247358490566038
BOG	MIA	3.9475877192982456
FRA	PVG	11.4701935483870968
SEA	MUC	10.0800000000000000
SFO	LAS	1.8310858995137763
DEN	CLT	3.2415141955835962
LHR	MUC	1.8300000000000000
ZRH	ORD	10.0800000000000000
CMN	IST	4.5711111111111111
VIE	ORD	10.1700000000000000
LOS	FRA	6.5800000000000000
MEX	GRU	9.5778888888888889
LAS	LAX	1.3320052424639581
SFO	CLT	5.0886327077747989
SFO	DFW	3.5874113856068743
LAS	ORD	3.8139655172413793
LAX	DEN	2.4554206999255398
LHR	VIE	2.2325192802056555
MAN	VIE	2.4200000000000000
DEN	ATL	2.9511445783132530
EWR	ATL	2.5518831615120275
GRU	LAX	12.3300000000000000
MUC	FRA	1.0800000000000000
FRA	LIS	3.2202449888641425
ATH	EWR	11.1700000000000000
BOG	ATL	5.1452229299363057
DFW	BOG	5.3300000000000000
MCO	MIA	2.7176543209876543
ORD	DEN	2.8278691588785047
MUC	DXB	5.8300000000000000
MCO	MEX	3.9300709219858156
MUC	PVG	11.4339047619047619
MUC	BKK	10.5000000000000000
JFK	MIA	3.3310380348652932
FRA	CMN	3.7500000000000000
LAS	JFK	5.0092849035187287
BOG	MCO	4.2711247443762781
DFW	ATL	2.1788181818181818
SEA	LAX	2.9775287797390637
MCO	BOG	3.9902249488752556
MCO	FRA	9.0800000000000000
PAE	LAS	2.5428873239436620
LAS	DEN	2.0039655172413793
CDG	ZRH	1.3108814589665653
VIE	BKK	10.0800000000000000
MUC	ORD	9.7884415584415584
VIE	EWR	9.7500000000000000
ATL	JFK	2.2651531151003168
SEA	CLT	5.0010041841004184
DEN	JFK	3.7502798982188295
HND	FRA	14.6744664031620553
CAI	VIE	3.7500000000000000
ATL	MEX	3.8884526558891455
LAX	SFO	1.5073705447209146
DEN	MCO	3.9198885793871866
VIE	BER	1.2523161764705882
CLT	ATL	1.3937919737919738
VIE	ARN	2.2500000000000000
JFK	BOG	5.8960000000000000
ZRH	CAI	4.0020238095238095
MIA	GRU	8.3208760330578512
LAX	MIA	4.9408805790108565
OSL	ARN	1.1348979591836735
DEL	HND	7.5000000000000000
NLU	DFW	2.7500000000000000
NLU	LAX	3.9200000000000000
DMM	SAW	4.3600000000000000
BKK	ZRH	12.2500000000000000
HND	LAX	10.0000000000000000
SAW	DMM	4.0421978021978022
SAW	CMN	5.0800000000000000
CAI	FRA	4.6058962264150943
MRU	FRA	12.0000000000000000
IST	DMM	4.0000000000000000
DFW	GRU	10.0098876404494382
CAI	MUC	4.0800000000000000
CMN	FRA	3.5800000000000000
DEN	FRA	9.6188970588235294
CLT	MUC	8.4200000000000000
DEN	MUC	9.6600961538461538
PVG	FRA	13.2884076433121019
MCO	GRU	8.5926315789473684
DEN	ONT	2.4540909090909091
ONT	DEN	2.3404430379746835
ONT	SEA	2.9411221945137157
MEX	EWR	4.7740310077519380
JFK	MEX	5.7560877513711152
PAE	SFO	2.2130000000000000
LAS	DFW	2.7567659883720930
EWR	MAD	7.4200000000000000
EWR	BOG	5.8300000000000000
LAS	ONT	1.1341052631578947
EWR	DUB	6.7500000000000000
MEX	MCO	3.2186170212765957
MCO	SEA	6.6171917808219178
MIA	LAS	5.6890949227373068
MCO	DEN	4.4899295774647887
LAS	MIA	4.7239729119638826
SEA	EWR	5.6187272727272727
SEA	JFK	5.3924637681159420
MIA	DEN	4.7961873990306947
MEX	DFW	2.7336952380952381
BOG	DFW	5.9118823529411765
CLT	DEN	3.8238277511961722
MIA	MCO	2.7954518950437318
JFK	ORD	2.8991917591125198
SEA	MCO	5.6768432671081678
JFK	CLT	2.1984346701164295
MIA	CLT	2.2586044071353620
MCO	ORD	3.1067857142857143
LAS	SEA	2.9840897959183673
CLT	ORD	2.2250968992248062
SFO	PAE	2.2594202898550725
MIA	ATL	2.1085896527285613
DEN	SFO	2.8509135559921415
LAX	ATL	4.4057974300831444
ORD	MIA	3.2939712488769093
ORD	DFW	2.7416532797858099
JFK	SFO	6.7216755319148936
\.


--
-- Name: Airport_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes."Airport_id_seq"', 61, true);


--
-- Name: ROUTE_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes."ROUTE_id_seq"', 603, true);


--
-- Name: _ag_label_edge_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes._ag_label_edge_id_seq', 1, false);


--
-- Name: _ag_label_vertex_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes._ag_label_vertex_id_seq', 1, false);


--
-- Name: _label_id_seq; Type: SEQUENCE SET; Schema: flight_routes; Owner: dst_graph_designer
--

SELECT pg_catalog.setval('flight_routes._label_id_seq', 4, true);


--
-- Name: _ag_label_edge _ag_label_edge_pkey; Type: CONSTRAINT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes._ag_label_edge
    ADD CONSTRAINT _ag_label_edge_pkey PRIMARY KEY (id);


--
-- Name: _ag_label_vertex _ag_label_vertex_pkey; Type: CONSTRAINT; Schema: flight_routes; Owner: dst_graph_designer
--

ALTER TABLE ONLY flight_routes._ag_label_vertex
    ADD CONSTRAINT _ag_label_vertex_pkey PRIMARY KEY (id);


--
-- Name: scheduled_routes scheduled_routes_pkey; Type: CONSTRAINT; Schema: l3; Owner: dst_graph_designer
--

ALTER TABLE ONLY l3.scheduled_routes
    ADD CONSTRAINT scheduled_routes_pkey PRIMARY KEY (departure_airport_code, arrival_airport_code);


--
-- Name: scheduled_routes scheduled_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: dst_graph_designer
--

ALTER TABLE ONLY public.scheduled_routes
    ADD CONSTRAINT scheduled_routes_pkey PRIMARY KEY (departure_airport_code, arrival_airport_code);


--
-- Name: scheduled_routes trigger_autoload_scheduled_routes; Type: TRIGGER; Schema: public; Owner: dst_graph_designer
--

CREATE TRIGGER trigger_autoload_scheduled_routes AFTER INSERT OR UPDATE ON public.scheduled_routes FOR EACH ROW EXECUTE FUNCTION flight_routes.autoload_scheduled_routes();


--
-- PostgreSQL database dump complete
--

